import { Component, signal, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Businesses } from './components/businesses/businesses';
import { Navigation } from './components/navigation/navigation';
import { BusinessData } from './services/business-data';

@Component({
  imports: [RouterOutlet, Businesses, Navigation],
  selector: 'app-root',
  providers: [BusinessData],
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {
  protected readonly title = signal('bizFE');

  //constructor(private businessData: BusinessData) {}
  private businessData = inject(BusinessData);

  ngOnInit() {
    this.businessData.populateReviews();
  }
}
