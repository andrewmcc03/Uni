import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter } from '@angular/router';
import * as core from '@angular/core';
import { provideAuth0 } from '@auth0/auth0-angular';
import { routes } from './app.routes';
import { provideHttpClient } from '@angular/common/http';

export const appConfig: ApplicationConfig = {
  providers: [
    (core as any).provideBrowserGlobalErrorListeners?.() || [],
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    provideHttpClient(),
    provideAuth0({
      domain: "dev-68zvmf3i30tplbdx.us.auth0.com",
      clientId: "0My7Cf08UEJ2LcXoEG75EvFWYZVVW1jM",
      authorizationParams: {
        redirect_uri: window.location.origin
      }
    })
  ]
};
