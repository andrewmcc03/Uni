import { bootstrapApplication } from '@angular/platform-browser';
// import { provideAuth0 } from '@auth0/auth0-angular';
// import { provideHttpClient } from '@angular/common/http';  **Auth0 FOUND IN app.config.ts
import { appConfig } from './app/app.config';
import { App } from './app/app';

bootstrapApplication(App, appConfig)
  .catch((err) => console.error(err));
