import { Cr as inject, U as InjectionToken, W as Injector, ca as ɵɵdefineInjectable, fa as ɵɵinject, la as ɵɵdefineInjector, oi as makeEnvironmentProviders, pt as VERSION } from "./_resource-chunk-CYFtEUrp.js";
import { Ai as setClassMetadata, Ga as ɵɵdefineNgModule, Nn as NgModule, Rn as Optional, bn as Inject, xn as Injectable } from "./core-CrVEmfUQ.js";
import { A as scan, An as throwError, Ct as take, D as shareReplay, H as pluck, Lt as catchError, Mn as from, Qn as Subject, Xn as ReplaySubject, Xt as filter, Zn as BehaviorSubject, b as switchMap, g as takeUntil, gt as distinctUntilChanged, in as iif, jn as of, jt as concatMap, m as tap, mn as mergeMap, r as withLatestFrom, rt as first, tn as merge, un as defer, vn as map, xt as mapTo } from "./esm5-Doa4YBQt.js";
import { jt as Location } from "./common-C4bqsBX-.js";
import { lt as Router } from "./router-CwuGOAFz.js";
// node_modules/@auth0/auth0-spa-js/dist/auth0-spa-js.production.esm.js
function e(e, t) {
	var n = {};
	for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && t.indexOf(o) < 0 && (n[o] = e[o]);
	if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
		var i = 0;
		for (o = Object.getOwnPropertySymbols(e); i < o.length; i++) t.indexOf(o[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, o[i]) && (n[o[i]] = e[o[i]]);
	}
	return n;
}
function t(e, t, n, o) {
	if ("a" === n && !o) throw new TypeError("Private accessor was defined without a getter");
	if ("function" == typeof t ? e !== t || !o : !t.has(e)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
	return "m" === n ? o : "a" === n ? o.call(e) : o ? o.value : t.get(e);
}
function n(e, t, n, o, i) {
	if ("m" === o) throw new TypeError("Private method is not writable");
	if ("a" === o && !i) throw new TypeError("Private accessor was defined without a setter");
	if ("function" == typeof t ? e !== t || !i : !t.has(e)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
	return "a" === o ? i.call(e, n) : i ? i.value = n : t.set(e, n), n;
}
function o(e, t) {
	this.v = e, this.k = t;
}
function i(e, t) {
	(null == t || t > e.length) && (t = e.length);
	for (var n = 0, o = Array(t); n < t; n++) o[n] = e[n];
	return o;
}
function r(e, t, n) {
	if ("function" == typeof e ? e === t : e.has(t)) return arguments.length < 3 ? t : n;
	throw new TypeError("Private element is not present on this object");
}
function s(e) {
	return new o(e, 0);
}
function a(e, t) {
	if (t.has(e)) throw new TypeError("Cannot initialize the same private elements twice on an object");
}
function c(e, t) {
	return e.get(r(e, t));
}
function u(e, t, n) {
	a(e, t), t.set(e, n);
}
function l(e, t, n) {
	return e.set(r(e, t), n), n;
}
function d(e, t) {
	a(e, t), t.add(e);
}
function h(e, t, n) {
	return (t = function(e) {
		var t = function(e, t) {
			if ("object" != typeof e || !e) return e;
			var n = e[Symbol.toPrimitive];
			if (void 0 !== n) {
				var o = n.call(e, t || "default");
				if ("object" != typeof o) return o;
				throw new TypeError("@@toPrimitive must return a primitive value.");
			}
			return ("string" === t ? String : Number)(e);
		}(e, "string");
		return "symbol" == typeof t ? t : t + "";
	}(t)) in e ? Object.defineProperty(e, t, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[t] = n, e;
}
function p(e, t) {
	var n = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		t && (o = o.filter(function(t) {
			return Object.getOwnPropertyDescriptor(e, t).enumerable;
		})), n.push.apply(n, o);
	}
	return n;
}
function f(e) {
	for (var t = 1; t < arguments.length; t++) {
		var n = null != arguments[t] ? arguments[t] : {};
		t % 2 ? p(Object(n), !0).forEach(function(t) {
			h(e, t, n[t]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : p(Object(n)).forEach(function(t) {
			Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
		});
	}
	return e;
}
function m(e, t) {
	if (null == e) return {};
	var n, o, i = function(e, t) {
		if (null == e) return {};
		var n = {};
		for (var o in e) if ({}.hasOwnProperty.call(e, o)) {
			if (-1 !== t.indexOf(o)) continue;
			n[o] = e[o];
		}
		return n;
	}(e, t);
	if (Object.getOwnPropertySymbols) {
		var r = Object.getOwnPropertySymbols(e);
		for (o = 0; o < r.length; o++) n = r[o], -1 === t.indexOf(n) && {}.propertyIsEnumerable.call(e, n) && (i[n] = e[n]);
	}
	return i;
}
function y(e, t) {
	return function(e) {
		if (Array.isArray(e)) return e;
	}(e) || function(e, t) {
		var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
		if (null != n) {
			var o, i, r, s, a = [], c = !0, u = !1;
			try {
				if (r = (n = n.call(e)).next, 0 === t) {
					if (Object(n) !== n) return;
					c = !1;
				} else for (; !(c = (o = r.call(n)).done) && (a.push(o.value), a.length !== t); c = !0);
			} catch (e) {
				u = !0, i = e;
			} finally {
				try {
					if (!c && null != n.return && (s = n.return(), Object(s) !== s)) return;
				} finally {
					if (u) throw i;
				}
			}
			return a;
		}
	}(e, t) || function(e, t) {
		if (e) {
			if ("string" == typeof e) return i(e, t);
			var n = {}.toString.call(e).slice(8, -1);
			return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? i(e, t) : void 0;
		}
	}(e, t) || function() {
		throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
	}();
}
function w(e) {
	return function() {
		return new g(e.apply(this, arguments));
	};
}
function g(e) {
	var t, n;
	function i(t, n) {
		try {
			var s = e[t](n), a = s.value, c = a instanceof o;
			Promise.resolve(c ? a.v : a).then(function(n) {
				if (c) {
					var o = "return" === t && a.k ? t : "next";
					if (!a.k || n.done) return i(o, n);
					n = e[o](n).value;
				}
				r(!!s.done, n);
			}, function(e) {
				i("throw", e);
			});
		} catch (e) {
			r(2, e);
		}
	}
	function r(e, o) {
		2 === e ? t.reject(o) : t.resolve({
			value: o,
			done: e
		}), (t = t.next) ? i(t.key, t.arg) : n = null;
	}
	this._invoke = function(e, o) {
		return new Promise(function(r, s) {
			var a = {
				key: e,
				arg: o,
				resolve: r,
				reject: s,
				next: null
			};
			n ? n = n.next = a : (t = n = a, i(e, o));
		});
	}, "function" != typeof e.return && (this.return = void 0);
}
g.prototype["function" == typeof Symbol && Symbol.asyncIterator || "@@asyncIterator"] = function() {
	return this;
}, g.prototype.next = function(e) {
	return this._invoke("next", e);
}, g.prototype.throw = function(e) {
	return this._invoke("throw", e);
}, g.prototype.return = function(e) {
	return this._invoke("return", e);
};
var v = { timeoutInSeconds: 60 };
var b = 1e4;
var _ = "memory";
var k = "Multifactor authentication required";
var S = "online_access";
var T = {
	name: "auth0-spa-js",
	version: "2.30.0"
};
var P = () => Date.now();
var C = "default";
var E = class E extends Error {
	constructor(e, t, n) {
		super(t), this.error = e, this.error_description = t, this.data = n, Object.setPrototypeOf(this, E.prototype);
	}
	static fromPayload(e) {
		let t = e.error, n = e.error_description;
		return new E(t, n);
	}
};
var R = class R extends E {
	constructor(e, t) {
		super("invalid_configuration", "".concat(e, " ").concat(t)), this.suggestion = t, Object.setPrototypeOf(this, R.prototype);
	}
};
var A = class A extends E {
	constructor(e, t, n) {
		let o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
		super(e, t), this.state = n, this.appState = o, Object.setPrototypeOf(this, A.prototype);
	}
};
var x = class x extends E {
	constructor(e, t, n, o) {
		let i = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
		super(e, t), this.connection = n, this.state = o, this.appState = i, Object.setPrototypeOf(this, x.prototype);
	}
};
var I = class I extends E {
	constructor() {
		super("timeout", "Timeout"), Object.setPrototypeOf(this, I.prototype);
	}
};
var O = class O extends I {
	constructor(e) {
		super(), this.popup = e, Object.setPrototypeOf(this, O.prototype);
	}
};
var j = class j extends E {
	constructor(e) {
		super("cancelled", "Popup closed"), this.popup = e, Object.setPrototypeOf(this, j.prototype);
	}
};
var W = class W extends E {
	constructor() {
		super("popup_open", "Unable to open a popup for loginWithPopup - window.open returned `null`"), Object.setPrototypeOf(this, W.prototype);
	}
};
var N = class N extends E {
	constructor(e, t, n, o) {
		super(e, t), this.mfa_token = n, this.mfa_requirements = o, Object.setPrototypeOf(this, N.prototype);
	}
};
var M = class M extends E {
	constructor(e) {
		super("verification_required", "Identifier verification is required before passkey creation. Collect OTP codes for each identifier and call passkey.continueSignup()."), this.verificationRequired = e, Object.setPrototypeOf(this, M.prototype);
	}
};
var U = class U extends E {
	constructor(e, t) {
		super("missing_refresh_token", "Missing Refresh Token (audience: '".concat(z(e, ["default"]), "', scope: '").concat(z(t), "')")), this.audience = e, this.scope = t, Object.setPrototypeOf(this, U.prototype);
	}
};
var L = class L extends E {
	constructor(e, t) {
		super("missing_scopes", "Missing requested scopes after refresh (audience: '".concat(z(e, ["default"]), "', missing scope: '").concat(z(t), "')")), this.audience = e, this.scope = t, Object.setPrototypeOf(this, L.prototype);
	}
};
var K = class K extends E {
	constructor(e) {
		super("use_dpop_nonce", "Server rejected DPoP proof: wrong nonce"), this.newDpopNonce = e, Object.setPrototypeOf(this, K.prototype);
	}
};
function z(e) {
	return e && !(arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : []).includes(e) ? e : "";
}
var J = () => window.crypto;
var D = () => {
	const e = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_~.";
	let t = "";
	for (; t.length < 43;) {
		const n = J().getRandomValues(new Uint8Array(43 - t.length));
		for (const o of n) t.length < 43 && o < 198 && (t += e[o % 66]);
	}
	return t;
};
var H = (e) => btoa(e);
var Z = [
	{
		key: "name",
		type: ["string"]
	},
	{
		key: "version",
		type: ["string", "number"]
	},
	{
		key: "env",
		type: ["object"]
	}
];
var F = function(e) {
	let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
	return Object.keys(e).reduce((n, o) => {
		if (t && "env" === o) return n;
		const i = Z.find((e) => e.key === o);
		return i && i.type.includes(typeof e[o]) && (n[o] = e[o]), n;
	}, {});
};
var V = (t) => {
	var n = t.clientId, o = e(t, ["clientId"]);
	return new URLSearchParams(((e) => Object.keys(e).filter((t) => void 0 !== e[t]).reduce((t, n) => Object.assign(Object.assign({}, t), { [n]: e[n] }), {}))(Object.assign({ client_id: n }, o))).toString();
};
var X = async (e) => {
	return await J().subtle.digest({ name: "SHA-256" }, new TextEncoder().encode(e));
};
var G = (e) => ((e) => decodeURIComponent(atob(e).split("").map((e) => "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2)).join("")))(e.replace(/_/g, "/").replace(/-/g, "+"));
var q = (e) => {
	const t = new Uint8Array(e);
	return ((e) => {
		const t = {
			"+": "-",
			"/": "_",
			"=": ""
		};
		return e.replace(/[+/=]/g, (e) => t[e]);
	})(window.btoa(String.fromCharCode(...Array.from(t))));
};
var Y = (e) => {
	if ("string" != typeof e) return e;
	const t = parseInt(e, 10);
	return isNaN(t) ? void 0 : t;
};
var B = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
var Q = {};
var $ = {};
Object.defineProperty($, "__esModule", { value: !0 });
var ee = function() {
	function e() {
		var e = this;
		this.locked = /* @__PURE__ */ new Map(), this.addToLocked = function(t, n) {
			var o = e.locked.get(t);
			void 0 === o ? void 0 === n ? e.locked.set(t, []) : e.locked.set(t, [n]) : void 0 !== n && (o.unshift(n), e.locked.set(t, o));
		}, this.isLocked = function(t) {
			return e.locked.has(t);
		}, this.lock = function(t) {
			return new Promise(function(n, o) {
				e.isLocked(t) ? e.addToLocked(t, n) : (e.addToLocked(t), n());
			});
		}, this.unlock = function(t) {
			var n = e.locked.get(t);
			if (void 0 !== n && 0 !== n.length) {
				var o = n.pop();
				e.locked.set(t, n), void 0 !== o && setTimeout(o, 0);
			} else e.locked.delete(t);
		};
	}
	return e.getInstance = function() {
		return void 0 === e.instance && (e.instance = new e()), e.instance;
	}, e;
}();
$.default = function() {
	return ee.getInstance();
};
var te = B && B.__awaiter || function(e, t, n, o) {
	return new (n || (n = Promise))(function(i, r) {
		function s(e) {
			try {
				c(o.next(e));
			} catch (e) {
				r(e);
			}
		}
		function a(e) {
			try {
				c(o.throw(e));
			} catch (e) {
				r(e);
			}
		}
		function c(e) {
			e.done ? i(e.value) : new n(function(t) {
				t(e.value);
			}).then(s, a);
		}
		c((o = o.apply(e, t || [])).next());
	});
};
var ne = B && B.__generator || function(e, t) {
	var n, o, i, r, s = {
		label: 0,
		sent: function() {
			if (1 & i[0]) throw i[1];
			return i[1];
		},
		trys: [],
		ops: []
	};
	return r = {
		next: a(0),
		throw: a(1),
		return: a(2)
	}, "function" == typeof Symbol && (r[Symbol.iterator] = function() {
		return this;
	}), r;
	function a(r) {
		return function(a) {
			return function(r) {
				if (n) throw new TypeError("Generator is already executing.");
				for (; s;) try {
					if (n = 1, o && (i = 2 & r[0] ? o.return : r[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, r[1])).done) return i;
					switch (o = 0, i && (r = [2 & r[0], i.value]), r[0]) {
						case 0:
						case 1:
							i = r;
							break;
						case 4: return s.label++, {
							value: r[1],
							done: !1
						};
						case 5:
							s.label++, o = r[1], r = [0];
							continue;
						case 7:
							r = s.ops.pop(), s.trys.pop();
							continue;
						default:
							if (!(i = s.trys, (i = i.length > 0 && i[i.length - 1]) || 6 !== r[0] && 2 !== r[0])) {
								s = 0;
								continue;
							}
							if (3 === r[0] && (!i || r[1] > i[0] && r[1] < i[3])) {
								s.label = r[1];
								break;
							}
							if (6 === r[0] && s.label < i[1]) {
								s.label = i[1], i = r;
								break;
							}
							if (i && s.label < i[2]) {
								s.label = i[2], s.ops.push(r);
								break;
							}
							i[2] && s.ops.pop(), s.trys.pop();
							continue;
					}
					r = t.call(e, s);
				} catch (e) {
					r = [6, e], o = 0;
				} finally {
					n = i = 0;
				}
				if (5 & r[0]) throw r[1];
				return {
					value: r[0] ? r[1] : void 0,
					done: !0
				};
			}([r, a]);
		};
	}
};
var oe = B;
Object.defineProperty(Q, "__esModule", { value: !0 });
var ie = $;
var re = "browser-tabs-lock-key";
var se = {
	key: function(e) {
		return te(oe, void 0, void 0, function() {
			return ne(this, function(e) {
				throw new Error("Unsupported");
			});
		});
	},
	getItem: function(e) {
		return te(oe, void 0, void 0, function() {
			return ne(this, function(e) {
				throw new Error("Unsupported");
			});
		});
	},
	clear: function() {
		return te(oe, void 0, void 0, function() {
			return ne(this, function(e) {
				return [2, window.localStorage.clear()];
			});
		});
	},
	removeItem: function(e) {
		return te(oe, void 0, void 0, function() {
			return ne(this, function(e) {
				throw new Error("Unsupported");
			});
		});
	},
	setItem: function(e, t) {
		return te(oe, void 0, void 0, function() {
			return ne(this, function(e) {
				throw new Error("Unsupported");
			});
		});
	},
	keySync: function(e) {
		return window.localStorage.key(e);
	},
	getItemSync: function(e) {
		return window.localStorage.getItem(e);
	},
	clearSync: function() {
		return window.localStorage.clear();
	},
	removeItemSync: function(e) {
		return window.localStorage.removeItem(e);
	},
	setItemSync: function(e, t) {
		return window.localStorage.setItem(e, t);
	}
};
function ae(e) {
	return new Promise(function(t) {
		return setTimeout(t, e);
	});
}
function ce(e) {
	for (var t = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz", n = "", o = 0; o < e; o++) n += t[Math.floor(61 * Math.random())];
	return n;
}
var le = Q.default = function() {
	function e(t) {
		this.acquiredIatSet = /* @__PURE__ */ new Set(), this.storageHandler = void 0, this.id = Date.now().toString() + ce(15), this.acquireLock = this.acquireLock.bind(this), this.releaseLock = this.releaseLock.bind(this), this.releaseLock__private__ = this.releaseLock__private__.bind(this), this.waitForSomethingToChange = this.waitForSomethingToChange.bind(this), this.refreshLockWhileAcquired = this.refreshLockWhileAcquired.bind(this), this.storageHandler = t, void 0 === e.waiters && (e.waiters = []);
	}
	return e.prototype.acquireLock = function(t, n) {
		return void 0 === n && (n = 5e3), te(this, void 0, void 0, function() {
			var o, i, r, s, a, c, u;
			return ne(this, function(l) {
				switch (l.label) {
					case 0: o = Date.now() + ce(4), i = Date.now() + n, r = re + "-" + t, s = void 0 === this.storageHandler ? se : this.storageHandler, l.label = 1;
					case 1: return Date.now() < i ? [4, ae(30)] : [3, 8];
					case 2: return l.sent(), null !== s.getItemSync(r) ? [3, 5] : (a = this.id + "-" + t + "-" + o, [4, ae(Math.floor(25 * Math.random()))]);
					case 3: return l.sent(), s.setItemSync(r, JSON.stringify({
						id: this.id,
						iat: o,
						timeoutKey: a,
						timeAcquired: Date.now(),
						timeRefreshed: Date.now()
					})), [4, ae(30)];
					case 4: return l.sent(), null !== (c = s.getItemSync(r)) && (u = JSON.parse(c)).id === this.id && u.iat === o ? (this.acquiredIatSet.add(o), this.refreshLockWhileAcquired(r, o), [2, !0]) : [3, 7];
					case 5: return e.lockCorrector(void 0 === this.storageHandler ? se : this.storageHandler), [4, this.waitForSomethingToChange(i)];
					case 6: l.sent(), l.label = 7;
					case 7: return o = Date.now() + ce(4), [3, 1];
					case 8: return [2, !1];
				}
			});
		});
	}, e.prototype.refreshLockWhileAcquired = function(e, t) {
		return te(this, void 0, void 0, function() {
			var n = this;
			return ne(this, function(o) {
				return setTimeout(function() {
					return te(n, void 0, void 0, function() {
						var n, o, i;
						return ne(this, function(r) {
							switch (r.label) {
								case 0: return [4, ie.default().lock(t)];
								case 1: return r.sent(), this.acquiredIatSet.has(t) ? (n = void 0 === this.storageHandler ? se : this.storageHandler, null === (o = n.getItemSync(e)) ? (ie.default().unlock(t), [2]) : ((i = JSON.parse(o)).timeRefreshed = Date.now(), n.setItemSync(e, JSON.stringify(i)), ie.default().unlock(t), this.refreshLockWhileAcquired(e, t), [2])) : (ie.default().unlock(t), [2]);
							}
						});
					});
				}, 1e3), [2];
			});
		});
	}, e.prototype.waitForSomethingToChange = function(t) {
		return te(this, void 0, void 0, function() {
			return ne(this, function(n) {
				switch (n.label) {
					case 0: return [4, new Promise(function(n) {
						var o = !1, i = Date.now(), r = !1;
						function s() {
							if (r || (window.removeEventListener("storage", s), e.removeFromWaiting(s), clearTimeout(a), r = !0), !o) {
								o = !0;
								var t = 50 - (Date.now() - i);
								t > 0 ? setTimeout(n, t) : n(null);
							}
						}
						window.addEventListener("storage", s), e.addToWaiting(s);
						var a = setTimeout(s, Math.max(0, t - Date.now()));
					})];
					case 1: return n.sent(), [2];
				}
			});
		});
	}, e.addToWaiting = function(t) {
		this.removeFromWaiting(t), void 0 !== e.waiters && e.waiters.push(t);
	}, e.removeFromWaiting = function(t) {
		void 0 !== e.waiters && (e.waiters = e.waiters.filter(function(e) {
			return e !== t;
		}));
	}, e.notifyWaiters = function() {
		void 0 !== e.waiters && e.waiters.slice().forEach(function(e) {
			return e();
		});
	}, e.prototype.releaseLock = function(e) {
		return te(this, void 0, void 0, function() {
			return ne(this, function(t) {
				switch (t.label) {
					case 0: return [4, this.releaseLock__private__(e)];
					case 1: return [2, t.sent()];
				}
			});
		});
	}, e.prototype.releaseLock__private__ = function(t) {
		return te(this, void 0, void 0, function() {
			var n, o, i, r;
			return ne(this, function(s) {
				switch (s.label) {
					case 0: return n = void 0 === this.storageHandler ? se : this.storageHandler, o = re + "-" + t, null === (i = n.getItemSync(o)) ? [2] : (r = JSON.parse(i)).id !== this.id ? [3, 2] : [4, ie.default().lock(r.iat)];
					case 1: s.sent(), this.acquiredIatSet.delete(r.iat), n.removeItemSync(o), ie.default().unlock(r.iat), e.notifyWaiters(), s.label = 2;
					case 2: return [2];
				}
			});
		});
	}, e.lockCorrector = function(t) {
		for (var n = Date.now() - 5e3, o = t, i = [], r = 0;;) {
			var s = o.keySync(r);
			if (null === s) break;
			i.push(s), r++;
		}
		for (var a = !1, c = 0; c < i.length; c++) {
			var u = i[c];
			if (u.includes(re)) {
				var l = o.getItemSync(u);
				if (null !== l) {
					var d = JSON.parse(l);
					(void 0 === d.timeRefreshed && d.timeAcquired < n || void 0 !== d.timeRefreshed && d.timeRefreshed < n) && (o.removeItemSync(u), a = !0);
				}
			}
		}
		a && e.notifyWaiters();
	}, e.waiters = void 0, e;
}();
var de = class {
	async runWithLock(e, t, n) {
		const o = new AbortController(), i = setTimeout(() => o.abort(), t);
		try {
			return await navigator.locks.request(e, {
				mode: "exclusive",
				signal: o.signal
			}, async (e) => {
				if (clearTimeout(i), !e) throw new Error("Lock not available");
				return await n();
			});
		} catch (e) {
			if (clearTimeout(i), o.signal.aborted && "AbortError" === (null == e ? void 0 : e.name)) throw new I();
			throw e;
		}
	}
};
var he = class {
	constructor() {
		this.activeLocks = /* @__PURE__ */ new Set(), this.lock = new le(), this.pagehideHandler = () => {
			this.activeLocks.forEach((e) => this.lock.releaseLock(e)), this.activeLocks.clear();
		};
	}
	async runWithLock(e, t, n) {
		let o = !1;
		for (let n = 0; n < 10 && !o; n++) o = await this.lock.acquireLock(e, t);
		if (!o) throw new I();
		this.activeLocks.add(e), 1 === this.activeLocks.size && "undefined" != typeof window && window.addEventListener("pagehide", this.pagehideHandler);
		try {
			return await n();
		} finally {
			this.activeLocks.delete(e), await this.lock.releaseLock(e), 0 === this.activeLocks.size && "undefined" != typeof window && window.removeEventListener("pagehide", this.pagehideHandler);
		}
	}
};
function pe() {
	return "undefined" != typeof navigator && "function" == typeof (null === (e = navigator.locks) || void 0 === e ? void 0 : e.request) ? new de() : new he();
	var e;
}
var fe = null;
function me() {
	return fe || (fe = pe()), fe;
}
var ye = {};
var we = new TextEncoder();
var ge = new TextDecoder();
function ve(e) {
	return "string" == typeof e ? we.encode(e) : ge.decode(e);
}
function be(e) {
	if ("number" != typeof e.modulusLength || e.modulusLength < 2048) throw new Pe(`${e.name} modulusLength must be at least 2048 bits`);
}
async function _e(e, t, n) {
	if (!1 === n.usages.includes("sign")) throw new TypeError("private CryptoKey instances used for signing assertions must include \"sign\" in their \"usages\"");
	const o = `${Se(ve(JSON.stringify(e)))}.${Se(ve(JSON.stringify(t)))}`;
	return `${o}.${Se(await crypto.subtle.sign(function(e) {
		switch (e.algorithm.name) {
			case "ECDSA": return {
				name: e.algorithm.name,
				hash: "SHA-256"
			};
			case "RSA-PSS": return be(e.algorithm), {
				name: e.algorithm.name,
				saltLength: 32
			};
			case "RSASSA-PKCS1-v1_5": return be(e.algorithm), { name: e.algorithm.name };
			case "Ed25519": return { name: e.algorithm.name };
		}
		throw new Te();
	}(n), n, ve(o)))}`;
}
var ke;
if (Uint8Array.prototype.toBase64) ke = (e) => (e instanceof ArrayBuffer && (e = new Uint8Array(e)), e.toBase64({
	alphabet: "base64url",
	omitPadding: !0
}));
else {
	const e = 32768;
	ke = (t) => {
		t instanceof ArrayBuffer && (t = new Uint8Array(t));
		const n = [];
		for (let o = 0; o < t.byteLength; o += e) n.push(String.fromCharCode.apply(null, t.subarray(o, o + e)));
		return btoa(n.join("")).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
	};
}
function Se(e) {
	return ke(e);
}
var Te = class extends Error {
	constructor(e) {
		var t;
		super(null != e ? e : "operation not supported"), this.name = this.constructor.name, null === (t = Error.captureStackTrace) || void 0 === t || t.call(Error, this, this.constructor);
	}
};
var Pe = class extends Error {
	constructor(e) {
		var t;
		super(e), this.name = this.constructor.name, null === (t = Error.captureStackTrace) || void 0 === t || t.call(Error, this, this.constructor);
	}
};
function Ce(e) {
	switch (e.algorithm.name) {
		case "RSA-PSS": return function(e) {
			if ("SHA-256" === e.algorithm.hash.name) return "PS256";
			throw new Te("unsupported RsaHashedKeyAlgorithm hash name");
		}(e);
		case "RSASSA-PKCS1-v1_5": return function(e) {
			if ("SHA-256" === e.algorithm.hash.name) return "RS256";
			throw new Te("unsupported RsaHashedKeyAlgorithm hash name");
		}(e);
		case "ECDSA": return function(e) {
			if ("P-256" === e.algorithm.namedCurve) return "ES256";
			throw new Te("unsupported EcKeyAlgorithm namedCurve");
		}(e);
		case "Ed25519": return "Ed25519";
		default: throw new Te("unsupported CryptoKey algorithm name");
	}
}
function Ee(e) {
	return e instanceof CryptoKey;
}
function Re(e) {
	return Ee(e) && "public" === e.type;
}
async function Ae(e, t, n, o, i, r) {
	const s = null == e ? void 0 : e.privateKey, a = null == e ? void 0 : e.publicKey;
	if (!Ee(c = s) || "private" !== c.type) throw new TypeError("\"keypair.privateKey\" must be a private CryptoKey");
	var c;
	if (!Re(a)) throw new TypeError("\"keypair.publicKey\" must be a public CryptoKey");
	if (!0 !== a.extractable) throw new TypeError("\"keypair.publicKey.extractable\" must be true");
	if ("string" != typeof t) throw new TypeError("\"htu\" must be a string");
	if ("string" != typeof n) throw new TypeError("\"htm\" must be a string");
	if (void 0 !== o && "string" != typeof o) throw new TypeError("\"nonce\" must be a string or undefined");
	if (void 0 !== i && "string" != typeof i) throw new TypeError("\"accessToken\" must be a string or undefined");
	if (void 0 !== r && ("object" != typeof r || null === r || Array.isArray(r))) throw new TypeError("\"additional\" must be an object");
	const u = Object.assign(Object.create(null), r, {
		iat: Math.floor(Date.now() / 1e3),
		jti: crypto.randomUUID(),
		htm: n,
		nonce: o,
		htu: t,
		ath: i ? Se(await crypto.subtle.digest("SHA-256", ve(i))) : void 0
	});
	return _e({
		alg: Ce(s),
		typ: "dpop+jwt",
		jwk: await xe(a)
	}, u, s);
}
async function xe(e) {
	const { kty: t, e: n, n: o, x: i, y: r, crv: s } = await crypto.subtle.exportKey("jwk", e);
	return {
		kty: t,
		crv: s,
		e: n,
		n: o,
		x: i,
		y: r
	};
}
var Ie = "dpop-nonce";
var Oe = [
	"authorization_code",
	"refresh_token",
	"urn:ietf:params:oauth:grant-type:token-exchange",
	"urn:okta:params:oauth:grant-type:webauthn",
	"http://auth0.com/oauth/grant-type/mfa-oob",
	"http://auth0.com/oauth/grant-type/mfa-otp",
	"http://auth0.com/oauth/grant-type/mfa-recovery-code"
];
function je() {
	return async function(e, t) {
		var n;
		let o;
		if ("string" != typeof e || 0 === e.length) throw new TypeError("\"alg\" must be a non-empty string");
		switch (e) {
			case "PS256":
				o = {
					name: "RSA-PSS",
					hash: "SHA-256",
					modulusLength: 2048,
					publicExponent: new Uint8Array([
						1,
						0,
						1
					])
				};
				break;
			case "RS256":
				o = {
					name: "RSASSA-PKCS1-v1_5",
					hash: "SHA-256",
					modulusLength: 2048,
					publicExponent: new Uint8Array([
						1,
						0,
						1
					])
				};
				break;
			case "ES256":
				o = {
					name: "ECDSA",
					namedCurve: "P-256"
				};
				break;
			case "Ed25519":
				o = { name: "Ed25519" };
				break;
			default: throw new Te();
		}
		return crypto.subtle.generateKey(o, null !== (n = null == t ? void 0 : t.extractable) && void 0 !== n && n, ["sign", "verify"]);
	}("ES256", { extractable: !1 });
}
function We(e) {
	return async function(e) {
		if (!Re(e)) throw new TypeError("\"publicKey\" must be a public CryptoKey");
		if (!0 !== e.extractable) throw new TypeError("\"publicKey.extractable\" must be true");
		const t = await xe(e);
		let n;
		switch (t.kty) {
			case "EC":
				n = {
					crv: t.crv,
					kty: t.kty,
					x: t.x,
					y: t.y
				};
				break;
			case "OKP":
				n = {
					crv: t.crv,
					kty: t.kty,
					x: t.x
				};
				break;
			case "RSA":
				n = {
					e: t.e,
					kty: t.kty,
					n: t.n
				};
				break;
			default: throw new Te("unsupported JWK kty");
		}
		return Se(await crypto.subtle.digest({ name: "SHA-256" }, ve(JSON.stringify(n))));
	}(e.publicKey);
}
function Ne(e) {
	let t = e.keyPair, n = e.url, o = e.method, i = e.nonce, r = e.accessToken;
	return Ae(t, function(e) {
		const t = new URL(e);
		return t.search = "", t.hash = "", t.href;
	}(n), o, i, r);
}
var Me = (e, t) => new Promise(function(n, o) {
	const i = new MessageChannel();
	i.port1.onmessage = function(e) {
		e.data.error ? o(new Error(e.data.error)) : n(e.data), i.port1.close();
	}, t.postMessage(e, [i.port2]);
});
var Ue = (e, t, n) => {
	const o = new AbortController();
	let i;
	return t.signal = o.signal, Promise.race([fetch(e, t), new Promise((e, t) => {
		i = setTimeout(() => {
			o.abort(), t(/* @__PURE__ */ new Error("Timeout when executing 'fetch'"));
		}, n);
	})]).finally(() => {
		clearTimeout(i);
	});
};
var Le = async function(e, t, n, o, i, r) {
	let s = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : b;
	return i ? (async (e, t, n, o, i, r, s, a, c, u) => Me({
		type: "refresh",
		auth: {
			audience: t,
			scope: n
		},
		timeout: i,
		fetchUrl: e,
		fetchOptions: o,
		useFormData: s,
		useMrrt: a,
		skipTokenStorage: c,
		preserveRefreshToken: u
	}, r))(e, t, n, o, s, i, r, arguments.length > 7 ? arguments[7] : void 0, arguments.length > 8 ? arguments[8] : void 0, arguments.length > 9 ? arguments[9] : void 0) : (async (e, t, n) => {
		const o = await Ue(e, t, n);
		return {
			ok: o.ok,
			json: await o.json(),
			headers: (i = o.headers, [...i].reduce((e, t) => {
				let n = y(t, 2), o = n[0];
				return e[o] = n[1], e;
			}, {}))
		};
		var i;
	})(e, o, s);
};
async function Ke(t, n, o, i, r, s, a, c, u, l, d, h) {
	if (u) {
		const e = await u.generateProof({
			url: t,
			method: r.method || "GET",
			nonce: await u.getNonce()
		});
		r.headers = Object.assign(Object.assign({}, r.headers), { dpop: e });
	}
	let p, f = null;
	for (let e = 0; e < 3; e++) try {
		p = await Le(t, o, i, r, s, a, n, c, d, h), f = null;
		break;
	} catch (e) {
		f = e;
	}
	if (f) throw f;
	const m = p.json, y = m.error, w = m.error_description, g = e(m, ["error", "error_description"]), v = p, b = v.headers, _ = v.ok;
	let k;
	if (u && (k = b[Ie], k && await u.setNonce(k)), !_) {
		const e = w || "HTTP error. Unable to fetch ".concat(t);
		if ("mfa_required" === y) throw new N(y, e, g.mfa_token, g.mfa_requirements);
		if ("missing_refresh_token" === y) throw new U(o, i);
		if ("use_dpop_nonce" === y) {
			if (!u || !k || l) throw new K(k);
			return Ke(t, n, o, i, r, s, a, c, u, !0, d, h);
		}
		throw new E(y || "request_error", e, g);
	}
	return g;
}
async function ze(t, n, o) {
	var i = t.baseUrl, r = t.timeout, s = t.audience, a = t.scope, c = t.auth0Client, u = t.useFormData, l = t.useMrrt, d = t.dpop, h = t.preserveRefreshToken, p = e(t, [
		"baseUrl",
		"timeout",
		"audience",
		"scope",
		"auth0Client",
		"useFormData",
		"useMrrt",
		"dpop",
		"preserveRefreshToken"
	]);
	const f = "urn:ietf:params:oauth:grant-type:token-exchange" === p.grant_type, m = "urn:okta:params:oauth:grant-type:webauthn" === p.grant_type, y = "refresh_token" === p.grant_type && l, w = f || m || y, g = Object.assign(Object.assign(Object.assign({}, p), w && s && { audience: s }), w && a && { scope: a }), v = m || !u, b = v ? JSON.stringify(g) : V(g), _ = (k = p.grant_type, Oe.includes(k));
	var k;
	return await Ke("".concat(i, "/oauth/token"), r, s || C, a, {
		method: "POST",
		body: b,
		headers: {
			"Content-Type": v ? "application/json" : "application/x-www-form-urlencoded",
			"Auth0-Client": btoa(JSON.stringify(F(c || T)))
		}
	}, n, u, l, _ ? d : void 0, void 0, o, h);
}
var Je = function() {
	for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
	return (o = t.filter(Boolean).join(" ").trim().split(/\s+/), Array.from(new Set(o))).join(" ");
	var o;
};
var De = (e, t, n) => {
	let o;
	return n && (o = e[n]), o || (o = e[C]), Je(o, t);
};
var He = "@@auth0spajs@@";
var Ze = "@@user@@";
var Fe = class Fe {
	constructor(e) {
		let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : He, n = arguments.length > 2 ? arguments[2] : void 0;
		this.prefix = t, this.suffix = n, this.clientId = e.clientId, this.scope = e.scope, this.audience = e.audience;
	}
	toKey() {
		return [
			this.prefix,
			this.clientId,
			this.audience,
			this.scope,
			this.suffix
		].filter(Boolean).join("::");
	}
	static fromKey(e) {
		const t = y(e.split("::"), 4), n = t[0], o = t[1], i = t[2], r = t[3];
		return new Fe({
			clientId: o,
			scope: r,
			audience: i
		}, n);
	}
	static fromCacheEntry(e) {
		const t = e.scope, n = e.audience, o = e.client_id;
		return new Fe({
			scope: t,
			audience: n,
			clientId: o
		});
	}
};
var Ve = class {
	set(e, t) {
		localStorage.setItem(e, JSON.stringify(t));
	}
	get(e) {
		const t = window.localStorage.getItem(e);
		if (t) try {
			return JSON.parse(t);
		} catch (e) {
			return;
		}
	}
	remove(e) {
		localStorage.removeItem(e);
	}
	allKeys() {
		return Object.keys(window.localStorage).filter((e) => e.startsWith(He));
	}
};
var Xe = class {
	constructor() {
		this.enclosedCache = function() {
			let e = {};
			return {
				set(t, n) {
					e[t] = n;
				},
				get(t) {
					const n = e[t];
					if (n) return n;
				},
				remove(t) {
					delete e[t];
				},
				allKeys: () => Object.keys(e)
			};
		}();
	}
};
var Ge = class {
	constructor(e, t, n) {
		this.cache = e, this.keyManifest = t, this.nowProvider = n || P;
	}
	async setIdToken(e, t, n) {
		var o;
		const i = this.getIdTokenCacheKey(e);
		await this.cache.set(i, {
			id_token: t,
			decodedToken: n
		}), await (null === (o = this.keyManifest) || void 0 === o ? void 0 : o.add(i));
	}
	async getIdToken(e) {
		const t = await this.cache.get(this.getIdTokenCacheKey(e.clientId));
		if (!t && e.scope && e.audience) {
			const t = await this.get(e);
			if (!t) return;
			if (!t.id_token || !t.decodedToken) return;
			return {
				id_token: t.id_token,
				decodedToken: t.decodedToken
			};
		}
		if (t) return {
			id_token: t.id_token,
			decodedToken: t.decodedToken
		};
	}
	async get(e) {
		let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], o = arguments.length > 3 ? arguments[3] : void 0;
		var i;
		let r = await this.cache.get(e.toKey()), s = e;
		if (!r) {
			const t = await this.getCacheKeys();
			if (!t) return;
			const i = this.matchExistingCacheKey(e, t);
			if (i && (r = await this.cache.get(i), s = Fe.fromKey(i)), !r && n && "cache-only" !== o) return this.getEntryWithRefreshToken(e, t);
		}
		if (!r) return;
		const a = await this.nowProvider(), c = Math.floor(a / 1e3);
		return r.expiresAt - t < c ? r.body.refresh_token ? this.modifiedCachedEntry(r, s) : (await this.cache.remove(s.toKey()), void await (null === (i = this.keyManifest) || void 0 === i ? void 0 : i.remove(s.toKey()))) : r.body;
	}
	async modifiedCachedEntry(e, t) {
		const n = {
			refresh_token: e.body.refresh_token,
			audience: e.body.audience,
			scope: e.body.scope
		}, o = {
			body: n,
			expiresAt: e.expiresAt
		};
		return await this.cache.set(t.toKey(), o), {
			refresh_token: n.refresh_token,
			audience: n.audience,
			scope: n.scope
		};
	}
	async set(e) {
		var t;
		const n = new Fe({
			clientId: e.client_id,
			scope: e.scope,
			audience: e.audience
		}), o = await this.wrapCacheEntry(e);
		await this.cache.set(n.toKey(), o), await (null === (t = this.keyManifest) || void 0 === t ? void 0 : t.add(n.toKey()));
	}
	async remove(e, t, n) {
		const o = new Fe({
			clientId: e,
			scope: n,
			audience: t
		});
		await this.cache.remove(o.toKey());
	}
	async stripRefreshToken(e) {
		var t;
		const n = await this.getCacheKeys();
		if (n) for (const o of n) {
			const n = await this.cache.get(o);
			(null === (t = null == n ? void 0 : n.body) || void 0 === t ? void 0 : t.refresh_token) === e && (delete n.body.refresh_token, await this.cache.set(o, n));
		}
	}
	async clear(e) {
		var t;
		const n = await this.getCacheKeys();
		n && (await n.filter((t) => !e || t.includes(e)).reduce(async (e, t) => {
			await e, await this.cache.remove(t);
		}, Promise.resolve()), await (null === (t = this.keyManifest) || void 0 === t ? void 0 : t.clear()));
	}
	async wrapCacheEntry(e) {
		const t = await this.nowProvider();
		return {
			body: e,
			expiresAt: Math.floor(t / 1e3) + e.expires_in
		};
	}
	async getCacheKeys() {
		var e;
		return this.keyManifest ? null === (e = await this.keyManifest.get()) || void 0 === e ? void 0 : e.keys : this.cache.allKeys ? this.cache.allKeys() : void 0;
	}
	getIdTokenCacheKey(e) {
		return new Fe({ clientId: e }, He, Ze).toKey();
	}
	matchExistingCacheKey(e, t) {
		return t.filter((t) => {
			var n;
			const o = Fe.fromKey(t), i = new Set(o.scope && o.scope.split(" ")), r = (null === (n = e.scope) || void 0 === n ? void 0 : n.split(" ")) || [], s = o.scope && r.reduce((e, t) => e && i.has(t), !0);
			return o.prefix === He && o.clientId === e.clientId && o.audience === e.audience && s;
		})[0];
	}
	async getEntryWithRefreshToken(e, t) {
		var n;
		for (const o of t) {
			const t = Fe.fromKey(o);
			if (t.prefix === He && t.clientId === e.clientId) {
				const e = await this.cache.get(o);
				if (null === (n = null == e ? void 0 : e.body) || void 0 === n ? void 0 : n.refresh_token) return {
					refresh_token: e.body.refresh_token,
					audience: e.body.audience,
					scope: e.body.scope
				};
			}
		}
	}
	async getRefreshTokensByAudience(e, t) {
		var n;
		const o = await this.getCacheKeys();
		if (!o) return [];
		const i = /* @__PURE__ */ new Set();
		for (const r of o) {
			const o = Fe.fromKey(r);
			if (o.prefix === He && o.clientId === t && o.audience === e) {
				const e = await this.cache.get(r);
				null !== (n = null == e ? void 0 : e.body) && void 0 !== n && n.refresh_token && i.add(e.body.refresh_token);
			}
		}
		return Array.from(i);
	}
	async updateEntry(e, t, n) {
		let o = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
		const i = await this.getCacheKeys();
		if (i) for (const r of i) {
			if (Fe.fromKey(r).clientId !== n) continue;
			const i = await this.cache.get(r);
			if (!(null == i ? void 0 : i.body)) continue;
			const s = i.body.refresh_token;
			s && (o || s === e) && (i.body.refresh_token = t, await this.cache.set(r, i));
		}
	}
};
var qe = class {
	constructor(e, t, n) {
		this.storage = e, this.clientId = t, this.cookieDomain = n, this.storageKey = "".concat("a0.spajs.txs", ".").concat(this.clientId);
	}
	create(e) {
		this.storage.save(this.storageKey, e, {
			daysUntilExpire: 1,
			cookieDomain: this.cookieDomain
		});
	}
	get() {
		return this.storage.get(this.storageKey);
	}
	remove() {
		this.storage.remove(this.storageKey, { cookieDomain: this.cookieDomain });
	}
};
var Ye = (e) => "number" == typeof e;
var Be = [
	"iss",
	"aud",
	"exp",
	"nbf",
	"iat",
	"jti",
	"azp",
	"nonce",
	"auth_time",
	"at_hash",
	"c_hash",
	"acr",
	"amr",
	"sub_jwk",
	"cnf",
	"sip_from_tag",
	"sip_date",
	"sip_callid",
	"sip_cseq_num",
	"sip_via_branch",
	"orig",
	"dest",
	"mky",
	"events",
	"toe",
	"txn",
	"rph",
	"sid",
	"vot",
	"vtm"
];
var Qe = (e) => {
	if (!e.id_token) throw new Error("ID token is required but missing");
	const t = ((e) => {
		const t = e.split("."), n = y(t, 3), o = n[0], i = n[1], r = n[2];
		if (3 !== t.length || !o || !i || !r) throw new Error("ID token could not be decoded");
		const s = JSON.parse(G(i)), a = { __raw: e }, c = {};
		return Object.keys(s).forEach((e) => {
			a[e] = s[e], Be.includes(e) || (c[e] = s[e]);
		}), {
			encoded: {
				header: o,
				payload: i,
				signature: r
			},
			header: JSON.parse(G(o)),
			claims: a,
			user: c
		};
	})(e.id_token);
	if (!t.claims.iss) throw new Error("Issuer (iss) claim must be a string present in the ID token");
	if (t.claims.iss !== e.iss) throw new Error("Issuer (iss) claim mismatch in the ID token; expected \"".concat(e.iss, "\", found \"").concat(t.claims.iss, "\""));
	if (!t.user.sub) throw new Error("Subject (sub) claim must be a string present in the ID token");
	if ("RS256" !== t.header.alg) throw new Error("Signature algorithm of \"".concat(t.header.alg, "\" is not supported. Expected the ID token to be signed with \"RS256\"."));
	if (!t.claims.aud || "string" != typeof t.claims.aud && !Array.isArray(t.claims.aud)) throw new Error("Audience (aud) claim must be a string or array of strings present in the ID token");
	if (Array.isArray(t.claims.aud)) {
		if (!t.claims.aud.includes(e.aud)) throw new Error("Audience (aud) claim mismatch in the ID token; expected \"".concat(e.aud, "\" but was not one of \"").concat(t.claims.aud.join(", "), "\""));
		if (t.claims.aud.length > 1) {
			if (!t.claims.azp) throw new Error("Authorized Party (azp) claim must be a string present in the ID token when Audience (aud) claim has multiple values");
			if (t.claims.azp !== e.aud) throw new Error("Authorized Party (azp) claim mismatch in the ID token; expected \"".concat(e.aud, "\", found \"").concat(t.claims.azp, "\""));
		}
	} else if (t.claims.aud !== e.aud) throw new Error("Audience (aud) claim mismatch in the ID token; expected \"".concat(e.aud, "\" but found \"").concat(t.claims.aud, "\""));
	if (e.nonce) {
		if (!t.claims.nonce) throw new Error("Nonce (nonce) claim must be a string present in the ID token");
		if (t.claims.nonce !== e.nonce) throw new Error("Nonce (nonce) claim mismatch in the ID token; expected \"".concat(e.nonce, "\", found \"").concat(t.claims.nonce, "\""));
	}
	if (null != e.max_age && !Ye(t.claims.auth_time)) throw new Error("Authentication Time (auth_time) claim must be a number present in the ID token when Max Age (max_age) is specified");
	if (null == t.claims.exp || !Ye(t.claims.exp)) throw new Error("Expiration Time (exp) claim must be a number present in the ID token");
	if (!Ye(t.claims.iat)) throw new Error("Issued At (iat) claim must be a number present in the ID token");
	const n = e.leeway || 60, o = new Date(e.now || Date.now()), i = /* @__PURE__ */ new Date(0);
	if (i.setUTCSeconds(t.claims.exp + n), o > i) throw new Error("Expiration Time (exp) claim error in the ID token; current time (".concat(o, ") is after expiration time (").concat(i, ")"));
	if (null != t.claims.nbf && Ye(t.claims.nbf)) {
		const e = /* @__PURE__ */ new Date(0);
		if (e.setUTCSeconds(t.claims.nbf - n), o < e) throw new Error("Not Before time (nbf) claim in the ID token indicates that this token can't be used just yet. Current time (".concat(o, ") is before ").concat(e));
	}
	if (null != t.claims.auth_time && Ye(t.claims.auth_time)) {
		const i = /* @__PURE__ */ new Date(0);
		if (i.setUTCSeconds(parseInt(t.claims.auth_time) + e.max_age + n), o > i) throw new Error("Authentication Time (auth_time) claim in the ID token indicates that too much time has passed since the last end-user authentication. Current time (".concat(o, ") is after last auth at ").concat(i));
	}
	if (e.organization) {
		const n = e.organization.trim();
		if (n.startsWith("org_")) {
			const e = n;
			if (!t.claims.org_id) throw new Error("Organization ID (org_id) claim must be a string present in the ID token");
			if (e !== t.claims.org_id) throw new Error("Organization ID (org_id) claim mismatch in the ID token; expected \"".concat(e, "\", found \"").concat(t.claims.org_id, "\""));
		} else {
			const e = n.toLowerCase();
			if (!t.claims.org_name) throw new Error("Organization Name (org_name) claim must be a string present in the ID token");
			if (e !== t.claims.org_name) throw new Error("Organization Name (org_name) claim mismatch in the ID token; expected \"".concat(e, "\", found \"").concat(t.claims.org_name, "\""));
		}
	}
	return t;
};
var $e = B && B.__assign || function() {
	return $e = Object.assign || function(e) {
		for (var t, n = 1, o = arguments.length; n < o; n++) for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
		return e;
	}, $e.apply(this, arguments);
};
function et(e, t) {
	if (!t) return "";
	var n = "; " + e;
	return !0 === t ? n : n + "=" + t;
}
function tt(e, t, n) {
	return encodeURIComponent(e).replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent).replace(/\(/g, "%28").replace(/\)/g, "%29") + "=" + encodeURIComponent(t).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent) + function(e) {
		if ("number" == typeof e.expires) {
			var t = /* @__PURE__ */ new Date();
			t.setMilliseconds(t.getMilliseconds() + 864e5 * e.expires), e.expires = t;
		}
		return et("Expires", e.expires ? e.expires.toUTCString() : "") + et("Domain", e.domain) + et("Path", e.path) + et("Secure", e.secure) + et("SameSite", e.sameSite);
	}(n);
}
function nt() {
	return function(e) {
		for (var t = {}, n = e ? e.split("; ") : [], o = /(%[\dA-F]{2})+/gi, i = 0; i < n.length; i++) {
			var r = n[i].split("="), s = r.slice(1).join("=");
			"\"" === s.charAt(0) && (s = s.slice(1, -1));
			try {
				t[r[0].replace(o, decodeURIComponent)] = s.replace(o, decodeURIComponent);
			} catch (e) {}
		}
		return t;
	}(document.cookie);
}
var ot = function(e) {
	return nt()[e];
};
function it(e, t, n) {
	document.cookie = tt(e, t, $e({ path: "/" }, n));
}
var rt = it;
var st = function(e, t) {
	it(e, "", $e($e({}, t), { expires: -1 }));
};
var at = {
	get(e) {
		const t = ot(e);
		if (void 0 !== t) return JSON.parse(t);
	},
	save(e, t, n) {
		let o = {};
		"https:" === window.location.protocol && (o = {
			secure: !0,
			sameSite: "none"
		}), null != n && n.daysUntilExpire && (o.expires = n.daysUntilExpire), null != n && n.cookieDomain && (o.domain = n.cookieDomain), rt(e, JSON.stringify(t), o);
	},
	remove(e, t) {
		let n = {};
		null != t && t.cookieDomain && (n.domain = t.cookieDomain), st(e, n);
	}
};
var ct = "_legacy_";
var ut = {
	get(e) {
		return at.get(e) || at.get("".concat(ct).concat(e));
	},
	save(e, t, n) {
		let o = {};
		"https:" === window.location.protocol && (o = { secure: !0 }), null != n && n.daysUntilExpire && (o.expires = n.daysUntilExpire), null != n && n.cookieDomain && (o.domain = n.cookieDomain), rt("".concat(ct).concat(e), JSON.stringify(t), o), at.save(e, t, n);
	},
	remove(e, t) {
		let n = {};
		null != t && t.cookieDomain && (n.domain = t.cookieDomain), st(e, n), at.remove(e, t), at.remove("".concat(ct).concat(e), t);
	}
};
var lt = {
	get(e) {
		if ("undefined" == typeof sessionStorage) return;
		const t = sessionStorage.getItem(e);
		return null != t ? JSON.parse(t) : void 0;
	},
	save(e, t) {
		sessionStorage.setItem(e, JSON.stringify(t));
	},
	remove(e) {
		sessionStorage.removeItem(e);
	}
};
var dt = {
	Offline: "offline",
	Online: "online"
};
var ht;
(function(e) {
	e.Code = "code", e.ConnectCode = "connect_code";
})(ht || (ht = {}));
var pt = class {};
function ft(e, t, n) {
	var o = void 0 === t ? null : t, i = function(e, t) {
		var n = atob(e);
		if (t) {
			for (var o = new Uint8Array(n.length), i = 0, r = n.length; i < r; ++i) o[i] = n.charCodeAt(i);
			return String.fromCharCode.apply(null, new Uint16Array(o.buffer));
		}
		return n;
	}(e, void 0 !== n && n), r = i.indexOf("\n", 10) + 1, s = i.substring(r) + (o ? "//# sourceMappingURL=" + o : ""), a = new Blob([s], { type: "application/javascript" });
	return URL.createObjectURL(a);
}
var mt;
var yt;
var wt;
var gt;
var vt = (mt = "Lyogcm9sbHVwLXBsdWdpbi13ZWItd29ya2VyLWxvYWRlciAqLwohZnVuY3Rpb24oKXsidXNlIHN0cmljdCI7ZnVuY3Rpb24gZShlLHQpeyhudWxsPT10fHx0PmUubGVuZ3RoKSYmKHQ9ZS5sZW5ndGgpO2Zvcih2YXIgcj0wLG89QXJyYXkodCk7cjx0O3IrKylvW3JdPWVbcl07cmV0dXJuIG99ZnVuY3Rpb24gdCh0LHIpe3JldHVybiBmdW5jdGlvbihlKXtpZihBcnJheS5pc0FycmF5KGUpKXJldHVybiBlfSh0KXx8ZnVuY3Rpb24oZSx0KXt2YXIgcj1udWxsPT1lP251bGw6InVuZGVmaW5lZCIhPXR5cGVvZiBTeW1ib2wmJmVbU3ltYm9sLml0ZXJhdG9yXXx8ZVsiQEBpdGVyYXRvciJdO2lmKG51bGwhPXIpe3ZhciBvLG4scyxhLGk9W10sYz0hMCxsPSExO3RyeXtpZihzPShyPXIuY2FsbChlKSkubmV4dCwwPT09dCl7aWYoT2JqZWN0KHIpIT09cilyZXR1cm47Yz0hMX1lbHNlIGZvcig7IShjPShvPXMuY2FsbChyKSkuZG9uZSkmJihpLnB1c2goby52YWx1ZSksaS5sZW5ndGghPT10KTtjPSEwKTt9Y2F0Y2goZSl7bD0hMCxuPWV9ZmluYWxseXt0cnl7aWYoIWMmJm51bGwhPXIucmV0dXJuJiYoYT1yLnJldHVybigpLE9iamVjdChhKSE9PWEpKXJldHVybn1maW5hbGx5e2lmKGwpdGhyb3cgbn19cmV0dXJuIGl9fSh0LHIpfHxmdW5jdGlvbih0LHIpe2lmKHQpe2lmKCJzdHJpbmciPT10eXBlb2YgdClyZXR1cm4gZSh0LHIpO3ZhciBvPXt9LnRvU3RyaW5nLmNhbGwodCkuc2xpY2UoOCwtMSk7cmV0dXJuIk9iamVjdCI9PT1vJiZ0LmNvbnN0cnVjdG9yJiYobz10LmNvbnN0cnVjdG9yLm5hbWUpLCJNYXAiPT09b3x8IlNldCI9PT1vP0FycmF5LmZyb20odCk6IkFyZ3VtZW50cyI9PT1vfHwvXig/OlVpfEkpbnQoPzo4fDE2fDMyKSg/OkNsYW1wZWQpP0FycmF5JC8udGVzdChvKT9lKHQscik6dm9pZCAwfX0odCxyKXx8ZnVuY3Rpb24oKXt0aHJvdyBuZXcgVHlwZUVycm9yKCJJbnZhbGlkIGF0dGVtcHQgdG8gZGVzdHJ1Y3R1cmUgbm9uLWl0ZXJhYmxlIGluc3RhbmNlLlxuSW4gb3JkZXIgdG8gYmUgaXRlcmFibGUsIG5vbi1hcnJheSBvYmplY3RzIG11c3QgaGF2ZSBhIFtTeW1ib2wuaXRlcmF0b3JdKCkgbWV0aG9kLiIpfSgpfWNsYXNzIHIgZXh0ZW5kcyBFcnJvcntjb25zdHJ1Y3RvcihlLHQsbyl7c3VwZXIodCksdGhpcy5lcnJvcj1lLHRoaXMuZXJyb3JfZGVzY3JpcHRpb249dCx0aGlzLmRhdGE9byxPYmplY3Quc2V0UHJvdG90eXBlT2YodGhpcyxyLnByb3RvdHlwZSl9c3RhdGljIGZyb21QYXlsb2FkKGUpe2xldCB0PWUuZXJyb3Isbz1lLmVycm9yX2Rlc2NyaXB0aW9uO3JldHVybiBuZXcgcih0LG8pfX1jbGFzcyBvIGV4dGVuZHMgcntjb25zdHJ1Y3RvcihlLHQpe3N1cGVyKCJtaXNzaW5nX3JlZnJlc2hfdG9rZW4iLCJNaXNzaW5nIFJlZnJlc2ggVG9rZW4gKGF1ZGllbmNlOiAnIi5jb25jYXQobihlLFsiZGVmYXVsdCJdKSwiJywgc2NvcGU6ICciKS5jb25jYXQobih0KSwiJykiKSksdGhpcy5hdWRpZW5jZT1lLHRoaXMuc2NvcGU9dCxPYmplY3Quc2V0UHJvdG90eXBlT2YodGhpcyxvLnByb3RvdHlwZSl9fWZ1bmN0aW9uIG4oZSl7cmV0dXJuIGUmJiEoYXJndW1lbnRzLmxlbmd0aD4xJiZ2b2lkIDAhPT1hcmd1bWVudHNbMV0/YXJndW1lbnRzWzFdOltdKS5pbmNsdWRlcyhlKT9lOiIifSJmdW5jdGlvbiI9PXR5cGVvZiBTdXBwcmVzc2VkRXJyb3ImJlN1cHByZXNzZWRFcnJvcjtjb25zdCBzPWU9Pnt2YXIgdD1lLmNsaWVudElkLHI9ZnVuY3Rpb24oZSx0KXt2YXIgcj17fTtmb3IodmFyIG8gaW4gZSlPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoZSxvKSYmdC5pbmRleE9mKG8pPDAmJihyW29dPWVbb10pO2lmKG51bGwhPWUmJiJmdW5jdGlvbiI9PXR5cGVvZiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKXt2YXIgbj0wO2ZvcihvPU9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoZSk7bjxvLmxlbmd0aDtuKyspdC5pbmRleE9mKG9bbl0pPDAmJk9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChlLG9bbl0pJiYocltvW25dXT1lW29bbl1dKX1yZXR1cm4gcn0oZSxbImNsaWVudElkIl0pO3JldHVybiBuZXcgVVJMU2VhcmNoUGFyYW1zKChlPT5PYmplY3Qua2V5cyhlKS5maWx0ZXIodD0+dm9pZCAwIT09ZVt0XSkucmVkdWNlKCh0LHIpPT5PYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sdCkse1tyXTplW3JdfSkse30pKShPYmplY3QuYXNzaWduKHtjbGllbnRfaWQ6dH0scikpKS50b1N0cmluZygpfTtsZXQgYT17fSxpPW51bGw7Y29uc3QgYz0oZSx0KT0+IiIuY29uY2F0KGUsInwiKS5jb25jYXQodCksbD0oZSx0KT0+dC5zdGFydHNXaXRoKCIiLmNvbmNhdChlLCJ8IikpLHU9KGUsdCk9PmFbYyhlLHQpXSxmPWU9PntPYmplY3QuZW50cmllcyhhKS5mb3JFYWNoKHI9PntsZXQgbz10KHIsMiksbj1vWzBdO29bMV09PT1lJiZkZWxldGUgYVtuXX0pfSxoPWU9Pntjb25zdCB0PW5ldyBVUkxTZWFyY2hQYXJhbXMoZSkscj17fTtyZXR1cm4gdC5mb3JFYWNoKChlLHQpPT57clt0XT1lfSkscn0sZD1hc3luYyBlPT57bGV0IHIsbixpPWUuZGF0YSxmPWkudGltZW91dCxkPWkuYXV0aCxwPWkuZmV0Y2hVcmwseT1pLmZldGNoT3B0aW9ucyxnPWkudXNlRm9ybURhdGEsYj1pLnVzZU1ycnQsTz1pLnNraXBUb2tlblN0b3JhZ2Usaz1pLnByZXNlcnZlUmVmcmVzaFRva2VuLG09dChlLnBvcnRzLDEpWzBdLGo9e307Y29uc3Qgdj1kfHx7fSxfPXYuYXVkaWVuY2Usdz12LnNjb3BlO3RyeXtjb25zdCBlPWc/aCh5LmJvZHkpOkpTT04ucGFyc2UoeS5ib2R5KTtpZihlLnJlZnJlc2hfdG9rZW58fCJyZWZyZXNoX3Rva2VuIiE9PWUuZ3JhbnRfdHlwZSllLm1mYV90b2tlbiYmKG49dShfLHcpLCFuJiZiJiYobj1hLmxhdGVzdF9yZWZyZXNoX3Rva2VuKSk7ZWxzZXtpZihuPXUoXyx3KSwhbiYmYil7Y29uc3QgZT1hLmxhdGVzdF9yZWZyZXNoX3Rva2VuLHQ9KChlLHQpPT4hIU9iamVjdC5rZXlzKGEpLmZpbmQocj0+e2lmKCJsYXRlc3RfcmVmcmVzaF90b2tlbiIhPT1yKXtjb25zdCBvPWwodCxyKSxuPXIuc3BsaXQoInwiKVsxXS5zcGxpdCgiICIpLHM9ZS5zcGxpdCgiICIpLmV2ZXJ5KGU9Pm4uaW5jbHVkZXMoZSkpO3JldHVybiBvJiZzfX0pKSh3LF8pO2UmJiF0JiYobj1lKX1pZighbil0aHJvdyBuZXcgbyhfLHcpO3kuYm9keT1nP3MoT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LGUpLHtyZWZyZXNoX3Rva2VuOm59KSk6SlNPTi5zdHJpbmdpZnkoT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LGUpLHtyZWZyZXNoX3Rva2VuOm59KSl9bGV0IGksZDsiZnVuY3Rpb24iPT10eXBlb2YgQWJvcnRDb250cm9sbGVyJiYoaT1uZXcgQWJvcnRDb250cm9sbGVyLHkuc2lnbmFsPWkuc2lnbmFsKTt0cnl7ZD1hd2FpdCBQcm9taXNlLnJhY2UoWyhQPWYsbmV3IFByb21pc2UoZT0+c2V0VGltZW91dChlLFApKSksZmV0Y2gocCxPYmplY3QuYXNzaWduKHt9LHkpKV0pfWNhdGNoKGUpe3JldHVybiB2b2lkIG0ucG9zdE1lc3NhZ2Uoe2Vycm9yOmUubWVzc2FnZX0pfWlmKCFkKXJldHVybiBpJiZpLmFib3J0KCksdm9pZCBtLnBvc3RNZXNzYWdlKHtlcnJvcjoiVGltZW91dCB3aGVuIGV4ZWN1dGluZyAnZmV0Y2gnIn0pO2lmKFU9ZC5oZWFkZXJzLGo9Wy4uLlVdLnJlZHVjZSgoZSxyKT0+e2xldCBvPXQociwyKSxuPW9bMF0scz1vWzFdO3JldHVybiBlW25dPXMsZX0se30pLHI9YXdhaXQgZC5qc29uKCksTylyZXR1cm4gZGVsZXRlIHIucmVmcmVzaF90b2tlbix2b2lkIG0ucG9zdE1lc3NhZ2Uoe29rOmQub2ssanNvbjpyLGhlYWRlcnM6an0pO3IucmVmcmVzaF90b2tlbj8oYiYmKGEubGF0ZXN0X3JlZnJlc2hfdG9rZW49ci5yZWZyZXNoX3Rva2VuLFM9bixNPXIucmVmcmVzaF90b2tlbixPYmplY3QuZW50cmllcyhhKS5mb3JFYWNoKGU9PntsZXQgcj10KGUsMiksbz1yWzBdO3JbMV09PT1TJiYoYVtvXT1NKX0pKSwoKGUsdCxyKT0+e2FbYyh0LHIpXT1lfSkoci5yZWZyZXNoX3Rva2VuLF8sdyksZGVsZXRlIHIucmVmcmVzaF90b2tlbik6a3x8KChlLHQpPT57ZGVsZXRlIGFbYyhlLHQpXX0pKF8sdyksbS5wb3N0TWVzc2FnZSh7b2s6ZC5vayxqc29uOnIsaGVhZGVyczpqfSl9Y2F0Y2goZSl7bS5wb3N0TWVzc2FnZSh7b2s6ITEsanNvbjp7ZXJyb3I6ZS5lcnJvcixlcnJvcl9kZXNjcmlwdGlvbjplLm1lc3NhZ2V9LGhlYWRlcnM6an0pfXZhciBTLE0sVSxQfSxwPWFzeW5jIGU9PntsZXQgcj1lLmRhdGEsbz1yLnRpbWVvdXQsbj1yLmF1dGgsaT1yLmZldGNoVXJsLGM9ci5mZXRjaE9wdGlvbnMsdT1yLnVzZUZvcm1EYXRhLGQ9dChlLnBvcnRzLDEpWzBdO2NvbnN0IHA9KG58fHt9KS5hdWRpZW5jZTt0cnl7Y29uc3QgZT0oZT0+e2NvbnN0IHI9bmV3IFNldDtyZXR1cm4gT2JqZWN0LmVudHJpZXMoYSkuZm9yRWFjaChvPT57bGV0IG49dChvLDIpLHM9blswXSxhPW5bMV07bChlLHMpJiZyLmFkZChhKX0pLEFycmF5LmZyb20ocil9KShwKTtpZigwPT09ZS5sZW5ndGgpcmV0dXJuIHZvaWQgZC5wb3N0TWVzc2FnZSh7b2s6ITB9KTtjb25zdCByPXU/aChjLmJvZHkpOkpTT04ucGFyc2UoYy5ib2R5KTtmb3IoY29uc3QgdCBvZiBlKXtjb25zdCBlPXU/cyhPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30scikse3Rva2VuOnR9KSk6SlNPTi5zdHJpbmdpZnkoT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LHIpLHt0b2tlbjp0fSkpO2xldCBuLGEsbCxoOyJmdW5jdGlvbiI9PXR5cGVvZiBBYm9ydENvbnRyb2xsZXImJihuPW5ldyBBYm9ydENvbnRyb2xsZXIsYT1uLnNpZ25hbCk7dHJ5e2g9YXdhaXQgUHJvbWlzZS5yYWNlKFtuZXcgUHJvbWlzZShlPT57bD1zZXRUaW1lb3V0KGUsbyl9KSxmZXRjaChpLE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSxjKSx7Ym9keTplLHNpZ25hbDphfSkpXSkuZmluYWxseSgoKT0+Y2xlYXJUaW1lb3V0KGwpKX1jYXRjaChlKXtyZXR1cm4gdm9pZCBkLnBvc3RNZXNzYWdlKHtlcnJvcjplLm1lc3NhZ2V9KX1pZighaClyZXR1cm4gbiYmbi5hYm9ydCgpLHZvaWQgZC5wb3N0TWVzc2FnZSh7ZXJyb3I6IlRpbWVvdXQgd2hlbiBleGVjdXRpbmcgJ2ZldGNoJyJ9KTtpZighaC5vayl7bGV0IGU7dHJ5e2NvbnN0IHQ9SlNPTi5wYXJzZShhd2FpdCBoLnRleHQoKSk7ZT10LmVycm9yX2Rlc2NyaXB0aW9ufWNhdGNoKGUpe31yZXR1cm4gdm9pZCBkLnBvc3RNZXNzYWdlKHtlcnJvcjplfHwiSFRUUCBlcnJvciAiLmNvbmNhdChoLnN0YXR1cyl9KX1mKHQpfWQucG9zdE1lc3NhZ2Uoe29rOiEwfSl9Y2F0Y2goZSl7ZC5wb3N0TWVzc2FnZSh7ZXJyb3I6ZS5tZXNzYWdlfHwiVW5rbm93biBlcnJvciBkdXJpbmcgdG9rZW4gcmV2b2NhdGlvbiJ9KX19LHk9KGUsdCk9PntpZighaSlyZXR1cm4hMTt0cnl7Y29uc3Qgcj1uZXcgVVJMKGkpLm9yaWdpbixvPW5ldyBVUkwoZS5mZXRjaFVybCk7cmV0dXJuIG8ub3JpZ2luPT09ciYmby5wYXRobmFtZT09PXR9Y2F0Y2goZSl7cmV0dXJuITF9fTthZGRFdmVudExpc3RlbmVyKCJtZXNzYWdlIixlPT57Y29uc3Qgcj1lLmRhdGEsbz10KGUucG9ydHMsMSlbMF07aWYoISgidHlwZSJpbiByKXx8ImluaXQiIT09ci50eXBlKXJldHVybiJ0eXBlImluIHImJiJjbGVhciI9PT1yLnR5cGU/KGE9e30sdm9pZChudWxsPT1vfHxvLnBvc3RNZXNzYWdlKHtvazohMH0pKSk6InR5cGUiaW4gciYmInJldm9rZSI9PT1yLnR5cGU/eShyLCIvb2F1dGgvcmV2b2tlIik/dm9pZCBwKGUpOnZvaWQobnVsbD09b3x8by5wb3N0TWVzc2FnZSh7b2s6ITEsanNvbjp7ZXJyb3I6ImludmFsaWRfZmV0Y2hfdXJsIixlcnJvcl9kZXNjcmlwdGlvbjoiVW5hdXRob3JpemVkIGZldGNoIFVSTCJ9LGhlYWRlcnM6e319KSk6dm9pZCgiZmV0Y2hVcmwiaW4gciYmeShyLCIvb2F1dGgvdG9rZW4iKT9kKGUpOm51bGw9PW98fG8ucG9zdE1lc3NhZ2Uoe29rOiExLGpzb246e2Vycm9yOiJpbnZhbGlkX2ZldGNoX3VybCIsZXJyb3JfZGVzY3JpcHRpb246IlVuYXV0aG9yaXplZCBmZXRjaCBVUkwifSxoZWFkZXJzOnt9fSkpO2lmKG51bGw9PT1pKXRyeXtuZXcgVVJMKHIuYWxsb3dlZEJhc2VVcmwpLGk9ci5hbGxvd2VkQmFzZVVybH1jYXRjaChlKXtyZXR1cm59fSl9KCk7Cgo=", yt = null, wt = !1, function(e) {
	return gt = gt || ft(mt, yt, wt), new Worker(gt, e);
});
var bt = class {
	constructor(e, t) {
		this.cache = e, this.clientId = t, this.manifestKey = this.createManifestKeyFrom(this.clientId);
	}
	async add(e) {
		var t;
		const n = new Set((null === (t = await this.cache.get(this.manifestKey)) || void 0 === t ? void 0 : t.keys) || []);
		n.add(e), await this.cache.set(this.manifestKey, { keys: [...n] });
	}
	async remove(e) {
		const t = await this.cache.get(this.manifestKey);
		if (t) {
			const n = new Set(t.keys);
			return n.delete(e), n.size > 0 ? await this.cache.set(this.manifestKey, { keys: [...n] }) : await this.cache.remove(this.manifestKey);
		}
	}
	get() {
		return this.cache.get(this.manifestKey);
	}
	clear() {
		return this.cache.remove(this.manifestKey);
	}
	createManifestKeyFrom(e) {
		return "".concat(He, "::").concat(e);
	}
};
var _t = "auth0.is.authenticated";
var kt = {
	memory: () => new Xe().enclosedCache,
	localstorage: () => new Ve()
};
var St = (e) => kt[e];
var Tt = (t) => {
	const n = t.openUrl, o = t.onRedirect, i = e(t, ["openUrl", "onRedirect"]);
	return Object.assign(Object.assign({}, i), { openUrl: !1 === n || n ? n : o });
};
var Pt = (e, t, n) => {
	const o = (null == e ? void 0 : e.split(" ")) || [], i = n ? o.filter((e) => e !== S) : o;
	const r = (null == t ? void 0 : t.split(" ")) || [];
	return i.filter((e) => -1 == r.indexOf(e)).join(",");
};
var Ct = {
	NONCE: "nonce",
	KEYPAIR: "keypair"
};
var Et = class {
	constructor(e) {
		this.clientId = e;
	}
	getVersion() {
		return 1;
	}
	createDbHandle() {
		const e = window.indexedDB.open("auth0-spa-js", this.getVersion());
		return new Promise((t, n) => {
			e.onupgradeneeded = () => Object.values(Ct).forEach((t) => e.result.createObjectStore(t)), e.onerror = () => n(e.error), e.onsuccess = () => t(e.result);
		});
	}
	async getDbHandle() {
		return this.dbHandle || (this.dbHandle = await this.createDbHandle()), this.dbHandle;
	}
	async executeDbRequest(e, t, n) {
		const o = n((await this.getDbHandle()).transaction(e, t).objectStore(e));
		return new Promise((e, t) => {
			o.onsuccess = () => e(o.result), o.onerror = () => t(o.error);
		});
	}
	buildKey(e) {
		const t = e ? "_".concat(e) : "auth0";
		return "".concat(this.clientId, "::").concat(t);
	}
	setNonce(e, t) {
		return this.save(Ct.NONCE, this.buildKey(t), e);
	}
	setKeyPair(e) {
		return this.save(Ct.KEYPAIR, this.buildKey(), e);
	}
	async save(e, t, n) {
		await this.executeDbRequest(e, "readwrite", (e) => e.put(n, t));
	}
	findNonce(e) {
		return this.find(Ct.NONCE, this.buildKey(e));
	}
	findKeyPair() {
		return this.find(Ct.KEYPAIR, this.buildKey());
	}
	find(e, t) {
		return this.executeDbRequest(e, "readonly", (e) => e.get(t));
	}
	async deleteBy(e, t) {
		const n = await this.executeDbRequest(e, "readonly", (e) => e.getAllKeys());
		await Promise.all((null == n ? void 0 : n.filter(t).map((t) => this.executeDbRequest(e, "readwrite", (e) => e.delete(t)))) || []);
	}
	deleteByClientId(e, t) {
		return this.deleteBy(e, (e) => "string" == typeof e && e.startsWith("".concat(t, "::")));
	}
	clearNonces() {
		return this.deleteByClientId(Ct.NONCE, this.clientId);
	}
	clearKeyPairs() {
		return this.deleteByClientId(Ct.KEYPAIR, this.clientId);
	}
};
var Rt = class {
	constructor(e) {
		this.storage = new Et(e);
	}
	getNonce(e) {
		return this.storage.findNonce(e);
	}
	setNonce(e, t) {
		return this.storage.setNonce(e, t);
	}
	async getOrGenerateKeyPair() {
		let e = await this.storage.findKeyPair();
		return e || (e = await je(), await this.storage.setKeyPair(e)), e;
	}
	async generateProof(e) {
		const t = await this.getOrGenerateKeyPair();
		return Ne(Object.assign({ keyPair: t }, e));
	}
	async calculateThumbprint() {
		return We(await this.getOrGenerateKeyPair());
	}
	async clear() {
		await Promise.all([this.storage.clearNonces(), this.storage.clearKeyPairs()]);
	}
};
var At;
(function(e) {
	e.Bearer = "Bearer", e.DPoP = "DPoP";
})(At || (At = {}));
var xt = class {
	constructor(e, t) {
		this.hooks = t, this.config = Object.assign(Object.assign({}, e), { fetch: e.fetch || ("undefined" == typeof window ? fetch : window.fetch.bind(window)) });
	}
	isAbsoluteUrl(e) {
		return /^(https?:)?\/\//i.test(e);
	}
	buildUrl(e, t) {
		if (t) {
			if (this.isAbsoluteUrl(t)) return t;
			if (e) return "".concat(e.replace(/\/?\/$/, ""), "/").concat(t.replace(/^\/+/, ""));
		}
		throw new TypeError("`url` must be absolute or `baseUrl` non-empty.");
	}
	getAccessToken(e) {
		return this.config.getAccessToken ? this.config.getAccessToken(e) : this.hooks.getAccessToken(e);
	}
	extractUrl(e) {
		return "string" == typeof e ? e : e instanceof URL ? e.href : e.url;
	}
	buildBaseRequest(e, t) {
		if (!this.config.baseUrl) return new Request(e, t);
		const n = this.buildUrl(this.config.baseUrl, this.extractUrl(e)), o = e instanceof Request ? new Request(n, e) : n;
		return new Request(o, t);
	}
	setAuthorizationHeader(e, t) {
		let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : At.Bearer;
		e.headers.set("authorization", "".concat(n, " ").concat(t));
	}
	async setDpopProofHeader(e, t) {
		if (!this.config.dpopNonceId) return;
		const n = await this.hooks.getDpopNonce(), o = await this.hooks.generateDpopProof({
			accessToken: t,
			method: e.method,
			nonce: n,
			url: e.url
		});
		e.headers.set("dpop", o);
	}
	async prepareRequest(e, t) {
		const n = await this.getAccessToken(t);
		if (void 0 === n) throw new E("missing_access_token", "No access token available");
		let o, i;
		"string" == typeof n ? (o = this.config.dpopNonceId ? At.DPoP : At.Bearer, i = n) : (o = n.token_type, i = n.access_token), this.setAuthorizationHeader(e, i, o), o === At.DPoP && await this.setDpopProofHeader(e, i);
	}
	getHeader(e, t) {
		return Array.isArray(e) ? new Headers(e).get(t) || "" : "function" == typeof e.get ? e.get(t) || "" : e[t] || "";
	}
	hasUseDpopNonceError(e) {
		if (401 !== e.status) return !1;
		const t = this.getHeader(e.headers, "www-authenticate");
		return t.includes("invalid_dpop_nonce") || t.includes("use_dpop_nonce");
	}
	async handleResponse(e, t) {
		const n = this.getHeader(e.headers, Ie);
		if (n && await this.hooks.setDpopNonce(n), !this.hasUseDpopNonceError(e)) return e;
		if (!n || !t.onUseDpopNonceError) throw new K(n);
		return t.onUseDpopNonceError();
	}
	async internalFetchWithAuth(e, t, n, o) {
		const i = this.buildBaseRequest(e, t);
		await this.prepareRequest(i, o);
		const r = await this.config.fetch(i);
		return this.handleResponse(r, n);
	}
	fetchWithAuth(e, t, n) {
		const o = { onUseDpopNonceError: () => this.internalFetchWithAuth(e, t, Object.assign(Object.assign({}, o), { onUseDpopNonceError: void 0 }), n) };
		return this.internalFetchWithAuth(e, t, o, n);
	}
};
var It = class {
	constructor(e, t) {
		this.myAccountFetcher = e, this.apiBase = t;
	}
	async connectAccount(e) {
		const t = await this.myAccountFetcher.fetchWithAuth("".concat(this.apiBase, "v1/connected-accounts/connect"), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(e)
		}, { scope: ["create:me:connected_accounts"] });
		return this._handleResponse(t);
	}
	async completeAccount(e) {
		const t = await this.myAccountFetcher.fetchWithAuth("".concat(this.apiBase, "v1/connected-accounts/complete"), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(e)
		}, { scope: ["create:me:connected_accounts"] });
		return this._handleResponse(t);
	}
	async getFactors() {
		const e = await this.myAccountFetcher.fetchWithAuth("".concat(this.apiBase, "v1/factors"), { method: "GET" }, { scope: ["read:me:factors"] });
		return (await this._handleResponse(e)).factors;
	}
	async getAuthenticationMethods(e) {
		const t = e ? "?".concat(new URLSearchParams({ type: e })) : "", n = await this.myAccountFetcher.fetchWithAuth("".concat(this.apiBase, "v1/authentication-methods").concat(t), { method: "GET" }, { scope: ["read:me:authentication_methods"] });
		return (await this._handleResponse(n)).authentication_methods;
	}
	async getAuthenticationMethod(e) {
		const t = await this.myAccountFetcher.fetchWithAuth("".concat(this.apiBase, "v1/authentication-methods/").concat(encodeURIComponent(e)), { method: "GET" }, { scope: ["read:me:authentication_methods"] });
		return this._handleResponse(t);
	}
	async deleteAuthenticationMethod(e) {
		const t = await this.myAccountFetcher.fetchWithAuth("".concat(this.apiBase, "v1/authentication-methods/").concat(encodeURIComponent(e)), { method: "DELETE" }, { scope: ["delete:me:authentication_methods"] });
		t.ok || await this._handleResponse(t);
	}
	async updateAuthenticationMethod(e, t) {
		const n = await this.myAccountFetcher.fetchWithAuth("".concat(this.apiBase, "v1/authentication-methods/").concat(encodeURIComponent(e)), {
			method: "PATCH",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(t)
		}, { scope: ["update:me:authentication_methods"] });
		return this._handleResponse(n);
	}
	async enrollmentChallenge(e) {
		var t;
		const n = await this.myAccountFetcher.fetchWithAuth("".concat(this.apiBase, "v1/authentication-methods"), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(e)
		}, { scope: ["create:me:authentication_methods"] }), o = await this._handleResponse(n), i = null !== (t = n.headers.get("location")) && void 0 !== t ? t : "", r = decodeURIComponent(i.split("/").pop() || "");
		return Object.assign(Object.assign({}, o), {
			id: r,
			location: i
		});
	}
	async enrollmentVerify(t) {
		const n = t, o = n.location;
		n.type;
		const i = e(n, ["location", "type"]), r = await this.myAccountFetcher.fetchWithAuth("".concat(o, "/verify"), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(i)
		}, { scope: ["create:me:authentication_methods"] });
		return this._handleResponse(r);
	}
	async getUserProfile(e) {
		var t;
		const n = new URLSearchParams();
		null !== (t = null == e ? void 0 : e.fields) && void 0 !== t && t.length && n.set("fields", e.fields.join(",")), !1 === (null == e ? void 0 : e.includeFields) && n.set("include_fields", "false");
		const o = n.toString() ? "?".concat(n) : "", i = await this.myAccountFetcher.fetchWithAuth("".concat(this.apiBase, "v1/profile").concat(o), { method: "GET" }, { scope: ["read:me:profile"] });
		return this._handleResponse(i);
	}
	async updateUserProfile(e) {
		const t = await this.myAccountFetcher.fetchWithAuth("".concat(this.apiBase, "v1/profile"), {
			method: "PATCH",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(e)
		}, { scope: ["update:me:profile"] });
		return this._handleResponse(t);
	}
	async _handleResponse(e) {
		let t;
		try {
			t = await e.text(), t = JSON.parse(t);
		} catch (n) {
			throw new Ot({
				type: "invalid_json",
				status: e.status,
				title: "Invalid JSON response",
				detail: t || String(n)
			});
		}
		if (e.ok) return t;
		throw new Ot(t);
	}
};
var Ot = class Ot extends Error {
	constructor(e) {
		let t = e.type, n = e.status, o = e.title, i = e.detail, r = e.validation_errors;
		super(i), this.name = "MyAccountApiError", this.type = t, this.status = n, this.title = o, this.detail = i, this.validation_errors = r, Object.setPrototypeOf(this, Ot.prototype);
	}
};
var jt = {
	otp: { authenticatorTypes: ["otp"] },
	sms: {
		authenticatorTypes: ["oob"],
		oobChannels: ["sms"]
	},
	email: {
		authenticatorTypes: ["oob"],
		oobChannels: ["email"]
	},
	push: {
		authenticatorTypes: ["oob"],
		oobChannels: ["auth0"]
	},
	voice: {
		authenticatorTypes: ["oob"],
		oobChannels: ["voice"]
	}
};
var Wt = "http://auth0.com/oauth/grant-type/mfa-otp";
var Nt = "http://auth0.com/oauth/grant-type/mfa-oob";
var Mt = "http://auth0.com/oauth/grant-type/mfa-recovery-code";
var Ut;
var Lt;
var Kt;
if ("undefined" == typeof navigator || null === (Ut = navigator.userAgent) || void 0 === Ut || null === (Lt = Ut.startsWith) || void 0 === Lt || !Lt.call(Ut, "Mozilla/5.0 ")) Kt = "".concat("oauth4webapi", "/").concat("v3.8.6");
function zt(e, t) {
	if (null == e) return !1;
	try {
		return e instanceof t || Object.getPrototypeOf(e)[Symbol.toStringTag] === t.prototype[Symbol.toStringTag];
	} catch (e) {
		return !1;
	}
}
var Jt = "ERR_INVALID_ARG_VALUE";
var Dt = "ERR_INVALID_ARG_TYPE";
function Ht(e, t, n) {
	const o = new TypeError(e, { cause: n });
	return Object.assign(o, { code: t }), o;
}
var Zt = Symbol();
var Ft = Symbol();
var Vt = Symbol();
var Xt = Symbol();
var Gt = Symbol();
var qt = Symbol();
var Yt = new TextEncoder();
var Bt = new TextDecoder();
function Qt(e) {
	return "string" == typeof e ? Yt.encode(e) : Bt.decode(e);
}
var $t;
var en;
if (Uint8Array.prototype.toBase64) $t = (e) => (e instanceof ArrayBuffer && (e = new Uint8Array(e)), e.toBase64({
	alphabet: "base64url",
	omitPadding: !0
}));
else {
	const e = 32768;
	$t = (t) => {
		t instanceof ArrayBuffer && (t = new Uint8Array(t));
		const n = [];
		for (let o = 0; o < t.byteLength; o += e) n.push(String.fromCharCode.apply(null, t.subarray(o, o + e)));
		return btoa(n.join("")).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
	};
}
function tn(e) {
	return "string" == typeof e ? en(e) : $t(e);
}
en = Uint8Array.fromBase64 ? (e) => {
	try {
		return Uint8Array.fromBase64(e, { alphabet: "base64url" });
	} catch (e) {
		throw Ht("The input to be decoded is not correctly encoded.", Jt, e);
	}
} : (e) => {
	try {
		const t = atob(e.replace(/-/g, "+").replace(/_/g, "/").replace(/\s/g, "")), n = new Uint8Array(t.length);
		for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
		return n;
	} catch (e) {
		throw Ht("The input to be decoded is not correctly encoded.", Jt, e);
	}
};
var nn = class extends Error {
	constructor(e, t) {
		var n;
		super(e, t), h(this, "code", void 0), this.name = this.constructor.name, this.code = lo, null === (n = Error.captureStackTrace) || void 0 === n || n.call(Error, this, this.constructor);
	}
};
var on = class extends Error {
	constructor(e, t) {
		var n;
		super(e, t), h(this, "code", void 0), this.name = this.constructor.name, null != t && t.code && (this.code = null == t ? void 0 : t.code), null === (n = Error.captureStackTrace) || void 0 === n || n.call(Error, this, this.constructor);
	}
};
function rn(e, t, n) {
	return new on(e, {
		code: t,
		cause: n
	});
}
function sn(e, t) {
	if (function(e, t) {
		if (!(e instanceof CryptoKey)) throw Ht("".concat(t, " must be a CryptoKey"), Dt);
	}(e, t), "private" !== e.type) throw Ht("".concat(t, " must be a private CryptoKey"), Jt);
}
function an(e) {
	return null !== e && "object" == typeof e && !Array.isArray(e);
}
function cn(e) {
	zt(e, Headers) && (e = Object.fromEntries(e.entries()));
	const t = new Headers(null != e ? e : {});
	if (Kt && !t.has("user-agent") && t.set("user-agent", Kt), t.has("authorization")) throw Ht("\"options.headers\" must not include the \"authorization\" header name", Jt);
	return t;
}
function un(e, t) {
	if (void 0 !== t) {
		if ("function" == typeof t && (t = t(e.href)), !(t instanceof AbortSignal)) throw Ht("\"options.signal\" must return or be an instance of AbortSignal", Dt);
		return t;
	}
}
function ln(e) {
	return e.includes("//") ? e.replace("//", "/") : e;
}
async function dn(e, t) {
	return async function(e, t, n, o) {
		if (!(e instanceof URL)) throw Ht("\"".concat(t, "\" must be an instance of URL"), Dt);
		Pn(e, !0 !== (null == o ? void 0 : o[Zt]));
		const i = n(new URL(e.href)), r = cn(null == o ? void 0 : o.headers);
		return r.set("accept", "application/json"), ((null == o ? void 0 : o[Xt]) || fetch)(i.href, {
			body: void 0,
			headers: Object.fromEntries(r.entries()),
			method: "GET",
			redirect: "manual",
			signal: un(i, null == o ? void 0 : o.signal)
		});
	}(e, "issuerIdentifier", (e) => {
		switch (null == t ? void 0 : t.algorithm) {
			case void 0:
			case "oidc":
				(function(e, t) {
					e.pathname = ln("".concat(e.pathname, "/").concat(t));
				})(e, ".well-known/openid-configuration");
				break;
			case "oauth2":
				(function(e, t) {
					let n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
					"/" === e.pathname ? e.pathname = t : e.pathname = ln("".concat(t, "/").concat(n ? e.pathname : e.pathname.replace(/(\/)$/, "")));
				})(e, ".well-known/oauth-authorization-server");
				break;
			default: throw Ht("\"options.algorithm\" must be \"oidc\" (default), or \"oauth2\"", Jt);
		}
		return e;
	}, t);
}
function hn(e, t, n, o, i) {
	try {
		if ("number" != typeof e || !Number.isFinite(e)) throw Ht("".concat(n, " must be a number"), Dt, i);
		if (e > 0) return;
		if (t) {
			if (0 !== e) throw Ht("".concat(n, " must be a non-negative number"), Jt, i);
			return;
		}
		throw Ht("".concat(n, " must be a positive number"), Jt, i);
	} catch (e) {
		if (o) throw rn(e.message, o, i);
		throw e;
	}
}
function pn(e, t, n, o) {
	try {
		if ("string" != typeof e) throw Ht("".concat(t, " must be a string"), Dt, o);
		if (0 === e.length) throw Ht("".concat(t, " must not be empty"), Jt, o);
	} catch (e) {
		if (n) throw rn(e.message, n, o);
		throw e;
	}
}
function fn(e) {
	(function(e, t) {
		if (Dn(e) !== t) throw function(e) {
			let t = "\"response\" content-type must be ";
			for (var n = arguments.length, o = new Array(n > 1 ? n - 1 : 0), i = 1; i < n; i++) o[i - 1] = arguments[i];
			if (o.length > 2) {
				const e = o.pop();
				t += "".concat(o.join(", "), ", or ").concat(e);
			} else 2 === o.length ? t += "".concat(o[0], " or ").concat(o[1]) : t += o[0];
			return rn(t, yo, e);
		}(e, t);
	})(e, "application/json");
}
function mn() {
	return tn(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(32)));
}
function yn(e) {
	switch (e.algorithm.name) {
		case "RSA-PSS": return function(e) {
			switch (e.algorithm.hash.name) {
				case "SHA-256": return "PS256";
				case "SHA-384": return "PS384";
				case "SHA-512": return "PS512";
				default: throw new nn("unsupported RsaHashedKeyAlgorithm hash name", { cause: e });
			}
		}(e);
		case "RSASSA-PKCS1-v1_5": return function(e) {
			switch (e.algorithm.hash.name) {
				case "SHA-256": return "RS256";
				case "SHA-384": return "RS384";
				case "SHA-512": return "RS512";
				default: throw new nn("unsupported RsaHashedKeyAlgorithm hash name", { cause: e });
			}
		}(e);
		case "ECDSA": return function(e) {
			switch (e.algorithm.namedCurve) {
				case "P-256": return "ES256";
				case "P-384": return "ES384";
				case "P-521": return "ES512";
				default: throw new nn("unsupported EcKeyAlgorithm namedCurve", { cause: e });
			}
		}(e);
		case "Ed25519":
		case "ML-DSA-44":
		case "ML-DSA-65":
		case "ML-DSA-87": return e.algorithm.name;
		case "EdDSA": return "Ed25519";
		default: throw new nn("unsupported CryptoKey algorithm name", { cause: e });
	}
}
function wn(e) {
	const t = null == e ? void 0 : e[Ft];
	return "number" == typeof t && Number.isFinite(t) ? t : 0;
}
function gn(e) {
	const t = null == e ? void 0 : e[Vt];
	return "number" == typeof t && Number.isFinite(t) && -1 !== Math.sign(t) ? t : 30;
}
function vn() {
	return Math.floor(Date.now() / 1e3);
}
function bn(e) {
	if ("object" != typeof e || null === e) throw Ht("\"as\" must be an object", Dt);
	pn(e.issuer, "\"as.issuer\"");
}
function _n(e) {
	if ("object" != typeof e || null === e) throw Ht("\"client\" must be an object", Dt);
	pn(e.client_id, "\"client.client_id\"");
}
function kn(e) {
	return pn(e, "\"clientSecret\""), (t, n, o, i) => {
		o.set("client_id", n.client_id), o.set("client_secret", e);
	};
}
function Sn(e, t) {
	const n = (r = e) instanceof CryptoKey ? { key: r } : (null == r ? void 0 : r.key) instanceof CryptoKey ? (void 0 !== r.kid && pn(r.kid, "\"kid\""), {
		key: r.key,
		kid: r.kid
	}) : {}, o = n.key, i = n.kid;
	var r;
	return sn(o, "\"clientPrivateKey.key\""), async (e, n, r, s) => {
		var a;
		const c = {
			alg: yn(o),
			kid: i
		}, u = function(e, t) {
			const n = vn() + wn(t);
			return {
				jti: mn(),
				aud: e.issuer,
				exp: n + 60,
				iat: n,
				nbf: n,
				iss: t.client_id,
				sub: t.client_id
			};
		}(e, n);
		null == t || null === (a = t[Gt]) || void 0 === a || a.call(t, c, u), r.set("client_id", n.client_id), r.set("client_assertion_type", "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"), r.set("client_assertion", await async function(e, t, n) {
			if (!n.usages.includes("sign")) throw Ht("CryptoKey instances used for signing assertions must include \"sign\" in their \"usages\"", Jt);
			const o = "".concat(tn(Qt(JSON.stringify(e))), ".").concat(tn(Qt(JSON.stringify(t)))), i = tn(await crypto.subtle.sign(function(e) {
				switch (e.algorithm.name) {
					case "ECDSA": return {
						name: e.algorithm.name,
						hash: Ro(e)
					};
					case "RSA-PSS": switch (Eo(e), e.algorithm.hash.name) {
						case "SHA-256":
						case "SHA-384":
						case "SHA-512": return {
							name: e.algorithm.name,
							saltLength: parseInt(e.algorithm.hash.name.slice(-3), 10) >> 3
						};
						default: throw new nn("unsupported RSA-PSS hash name", { cause: e });
					}
					case "RSASSA-PKCS1-v1_5": return Eo(e), e.algorithm.name;
					case "ML-DSA-44":
					case "ML-DSA-65":
					case "ML-DSA-87":
					case "Ed25519": return e.algorithm.name;
				}
				throw new nn("unsupported CryptoKey algorithm name", { cause: e });
			}(n), n, Qt(o)));
			return "".concat(o, ".").concat(i);
		}(c, u, o));
	};
}
var Tn = URL.parse ? (e, t) => URL.parse(e, t) : (e, t) => {
	try {
		return new URL(e, t);
	} catch (e) {
		return null;
	}
};
function Pn(e, t) {
	if (t && "https:" !== e.protocol) throw rn("only requests to HTTPS are allowed", go, e);
	if ("https:" !== e.protocol && "http:" !== e.protocol) throw rn("only HTTP and HTTPS requests are allowed", vo, e);
}
function Cn(e, t, n, o) {
	let i;
	if ("string" != typeof e || !(i = Tn(e))) throw rn("authorization server metadata does not contain a valid ".concat(n ? "\"as.mtls_endpoint_aliases.".concat(t, "\"") : "\"as.".concat(t, "\"")), void 0 === e ? So : To, { attribute: n ? "mtls_endpoint_aliases.".concat(t) : t });
	return Pn(i, o), i;
}
function En(e, t, n, o) {
	return n && e.mtls_endpoint_aliases && t in e.mtls_endpoint_aliases ? Cn(e.mtls_endpoint_aliases[t], t, n, o) : Cn(e[t], t, n, o);
}
var Rn = class extends Error {
	constructor(e, t) {
		var n;
		super(e, t), h(this, "cause", void 0), h(this, "code", void 0), h(this, "error", void 0), h(this, "status", void 0), h(this, "error_description", void 0), h(this, "response", void 0), this.name = this.constructor.name, this.code = uo, this.cause = t.cause, this.error = t.cause.error, this.status = t.response.status, this.error_description = t.cause.error_description, Object.defineProperty(this, "response", {
			enumerable: !1,
			value: t.response
		}), null === (n = Error.captureStackTrace) || void 0 === n || n.call(Error, this, this.constructor);
	}
};
var An = class extends Error {
	constructor(e, t) {
		var n, o;
		super(e, t), h(this, "cause", void 0), h(this, "code", void 0), h(this, "error", void 0), h(this, "error_description", void 0), this.name = this.constructor.name, this.code = ho, this.cause = t.cause, this.error = t.cause.get("error"), this.error_description = null !== (n = t.cause.get("error_description")) && void 0 !== n ? n : void 0, null === (o = Error.captureStackTrace) || void 0 === o || o.call(Error, this, this.constructor);
	}
};
var xn = class extends Error {
	constructor(e, t) {
		var n;
		super(e, t), h(this, "cause", void 0), h(this, "code", void 0), h(this, "response", void 0), h(this, "status", void 0), this.name = this.constructor.name, this.code = co, this.cause = t.cause, this.status = t.response.status, this.response = t.response, Object.defineProperty(this, "response", { enumerable: !1 }), null === (n = Error.captureStackTrace) || void 0 === n || n.call(Error, this, this.constructor);
	}
};
var Wn = /* @__PURE__ */ new RegExp("^[,\\s]*([a-zA-Z0-9!#$%&\\'\\*\\+\\-\\.\\^_`\\|~]+)");
var Nn = /* @__PURE__ */ new RegExp("^[,\\s]*([a-zA-Z0-9!#$%&\\'\\*\\+\\-\\.\\^_`\\|~]+)\\s*=\\s*\"((?:[^\"\\\\]|\\\\[\\s\\S])*)\"[,\\s]*(.*)");
var Mn = /* @__PURE__ */ new RegExp("^[,\\s]*([a-zA-Z0-9!#$%&\\'\\*\\+\\-\\.\\^_`\\|~]+)\\s*=\\s*([a-zA-Z0-9!#$%&\\'\\*\\+\\-\\.\\^_`\\|~]+)[,\\s]*(.*)");
var Un = /* @__PURE__ */ new RegExp("^([a-zA-Z0-9\\-\\._\\~\\+\\/]+={0,2})(?:$|[,\\s])(.*)");
async function Ln(e, t, n) {
	if (e.status !== t) {
		let t;
		var o;
		if (Yn(e), t = await async function(e) {
			if (e.status > 399 && e.status < 500) {
				Co(e), fn(e);
				try {
					const t = await e.clone().json();
					if (an(t) && "string" == typeof t.error && t.error.length) return t;
				} catch (e) {}
			}
		}(e)) throw await (null === (o = e.body) || void 0 === o ? void 0 : o.cancel()), new Rn("server responded with an error in the response body", {
			cause: t,
			response: e
		});
		throw rn("\"response\" is not a conform ".concat(n, " response (unexpected HTTP status code)"), wo, e);
	}
}
function Kn(e) {
	if (!to.has(e)) throw Ht("\"options.DPoP\" is not a valid DPoPHandle", Jt);
}
async function zn(e, t, n, o) {
	bn(e), _n(t);
	const i = En(e, "userinfo_endpoint", t.use_mtls_endpoint_aliases, !0 !== (null == o ? void 0 : o[Zt])), r = cn(null == o ? void 0 : o.headers);
	return t.userinfo_signed_response_alg ? r.set("accept", "application/jwt") : (r.set("accept", "application/json"), r.append("accept", "application/jwt")), async function(e, t, n, o, i, r) {
		var s;
		if (pn(e, "\"accessToken\""), !(n instanceof URL)) throw Ht("\"url\" must be an instance of URL", Dt);
		Pn(n, !0 !== (null == r ? void 0 : r[Zt])), o = cn(o), null != r && r.DPoP && (Kn(r.DPoP), await r.DPoP.addProof(n, o, t.toUpperCase(), e)), o.set("authorization", "".concat(o.has("dpop") ? "DPoP" : "Bearer", " ").concat(e));
		const a = await ((null == r ? void 0 : r[Xt]) || fetch)(n.href, {
			duplex: zt(i, ReadableStream) ? "half" : void 0,
			body: i,
			headers: Object.fromEntries(o.entries()),
			method: t,
			redirect: "manual",
			signal: un(n, null == r ? void 0 : r.signal)
		});
		return null == r || null === (s = r.DPoP) || void 0 === s || s.cacheNonce(a, n), a;
	}(n, "GET", i, r, null, f(f({}, o), {}, { [Ft]: wn(t) }));
}
var Jn = Symbol();
function Dn(e) {
	var t;
	return null === (t = e.headers.get("content-type")) || void 0 === t ? void 0 : t.split(";")[0];
}
async function Hn(e, t, n, o, i) {
	if (bn(e), _n(t), !zt(o, Response)) throw Ht("\"response\" must be an instance of Response", Dt);
	if (Yn(o), 200 !== o.status) throw rn("\"response\" is not a conform UserInfo Endpoint response (unexpected HTTP status code)", wo, o);
	let r;
	if (Co(o), "application/jwt" === Dn(o)) {
		const n = await Ao(await o.text(), Io.bind(void 0, t.userinfo_signed_response_alg, e.userinfo_signing_alg_values_supported, void 0), wn(t), gn(t), null == i ? void 0 : i[qt]).then(Bn.bind(void 0, t.client_id)).then($n.bind(void 0, e)), s = n.claims, a = n.jwt;
		Xn.set(o, a), r = s;
	} else {
		if (t.userinfo_signed_response_alg) throw rn("JWT UserInfo Response expected", po, o);
		r = await Mo(o);
	}
	if (pn(r.sub, "\"response\" body \"sub\" property", mo, { body: r }), n === Jn);
	else if (pn(n, "\"expectedSubject\""), r.sub !== n) throw rn("unexpected \"response\" body \"sub\" property value", ko, {
		expected: n,
		body: r,
		attribute: "sub"
	});
	return r;
}
async function Zn(e, t, n, o, i, r, s) {
	return await n(e, t, i, r), r.set("content-type", "application/x-www-form-urlencoded;charset=UTF-8"), ((null == s ? void 0 : s[Xt]) || fetch)(o.href, {
		body: i,
		headers: Object.fromEntries(r.entries()),
		method: "POST",
		redirect: "manual",
		signal: un(o, null == s ? void 0 : s.signal)
	});
}
async function Fn(e, t, n, o, i, r) {
	var s;
	const a = En(e, "token_endpoint", t.use_mtls_endpoint_aliases, !0 !== (null == r ? void 0 : r[Zt]));
	i.set("grant_type", o);
	const c = cn(null == r ? void 0 : r.headers);
	c.set("accept", "application/json"), void 0 !== (null == r ? void 0 : r.DPoP) && (Kn(r.DPoP), await r.DPoP.addProof(a, c, "POST"));
	const u = await Zn(e, t, n, a, i, c, r);
	return null == r || null === (s = r.DPoP) || void 0 === s || s.cacheNonce(u, a), u;
}
var Vn = /* @__PURE__ */ new WeakMap();
var Xn = /* @__PURE__ */ new WeakMap();
function Gn(e) {
	if (!e.id_token) return;
	const t = Vn.get(e);
	if (!t) throw Ht("\"ref\" was already garbage collected or did not resolve from the proper sources", Jt);
	return t;
}
async function qn(e, t, n, o, i, r) {
	if (bn(e), _n(t), !zt(n, Response)) throw Ht("\"response\" must be an instance of Response", Dt);
	await Ln(n, 200, "Token Endpoint"), Co(n);
	const s = await Mo(n);
	if (pn(s.access_token, "\"response\" body \"access_token\" property", mo, { body: s }), pn(s.token_type, "\"response\" body \"token_type\" property", mo, { body: s }), s.token_type = s.token_type.toLowerCase(), void 0 !== s.expires_in) {
		let e = "number" != typeof s.expires_in ? parseFloat(s.expires_in) : s.expires_in;
		hn(e, !0, "\"response\" body \"expires_in\" property", mo, { body: s }), s.expires_in = e;
	}
	if (void 0 !== s.refresh_token && pn(s.refresh_token, "\"response\" body \"refresh_token\" property", mo, { body: s }), void 0 !== s.scope && "string" != typeof s.scope) throw rn("\"response\" body \"scope\" property must be a string", mo, { body: s });
	if (void 0 !== s.id_token) {
		pn(s.id_token, "\"response\" body \"id_token\" property", mo, { body: s });
		const r = [
			"aud",
			"exp",
			"iat",
			"iss",
			"sub"
		];
		!0 === t.require_auth_time && r.push("auth_time"), void 0 !== t.default_max_age && (hn(t.default_max_age, !0, "\"client.default_max_age\""), r.push("auth_time")), null != o && o.length && r.push(...o);
		const a = await Ao(s.id_token, Io.bind(void 0, t.id_token_signed_response_alg, e.id_token_signing_alg_values_supported, "RS256"), wn(t), gn(t), i).then(io.bind(void 0, r)).then(eo.bind(void 0, e)).then(Qn.bind(void 0, t.client_id)), c = a.claims, u = a.jwt;
		if (Array.isArray(c.aud) && 1 !== c.aud.length) {
			if (void 0 === c.azp) throw rn("ID Token \"aud\" (audience) claim includes additional untrusted audiences", _o, {
				claims: c,
				claim: "aud"
			});
			if (c.azp !== t.client_id) throw rn("unexpected ID Token \"azp\" (authorized party) claim value", _o, {
				expected: t.client_id,
				claims: c,
				claim: "azp"
			});
		}
		void 0 !== c.auth_time && hn(c.auth_time, !0, "ID Token \"auth_time\" (authentication time)", mo, { claims: c }), Xn.set(n, u), Vn.set(s, c);
	}
	if (void 0 !== (null == r ? void 0 : r[s.token_type])) r[s.token_type](n, s);
	else if ("dpop" !== s.token_type && "bearer" !== s.token_type) throw new nn("unsupported `token_type` value", { cause: { body: s } });
	return s;
}
function Yn(e) {
	let t;
	if (t = function(e) {
		if (!zt(e, Response)) throw Ht("\"response\" must be an instance of Response", Dt);
		const t = e.headers.get("www-authenticate");
		if (null === t) return;
		const n = [];
		let o = t;
		for (; o;) {
			var i;
			let e = o.match(Wn);
			const t = null === (i = e) || void 0 === i ? void 0 : i[1].toLowerCase();
			if (!t) return;
			const c = o.substring(e[0].length);
			if (c && !c.match(/^[\s,]/)) return;
			const u = c.match(/^\s+(.*)$/), l = !!u;
			o = u ? u[1] : void 0;
			const d = {};
			let h;
			if (l) for (; o;) {
				let t, n;
				if (e = o.match(Nn)) {
					var r = y(e, 4);
					if (t = r[1], n = r[2], o = r[3], n.includes("\\")) try {
						n = JSON.parse("\"".concat(n, "\""));
					} catch (e) {}
					d[t.toLowerCase()] = n;
				} else {
					if (!(e = o.match(Mn))) {
						if (e = o.match(Un)) {
							if (Object.keys(d).length) break;
							var s = y(e, 3);
							h = s[1], o = s[2];
							break;
						}
						return;
					}
					var a = y(e, 4);
					t = a[1], n = a[2], o = a[3], d[t.toLowerCase()] = n;
				}
			}
			else o = c || void 0;
			const p = {
				scheme: t,
				parameters: d
			};
			h && (p.token68 = h), n.push(p);
		}
		return n.length ? n : void 0;
	}(e)) throw new xn("server responded with a challenge in the WWW-Authenticate HTTP Header", {
		cause: t,
		response: e
	});
}
function Bn(e, t) {
	return void 0 !== t.claims.aud ? Qn(e, t) : t;
}
function Qn(e, t) {
	if (Array.isArray(t.claims.aud)) {
		if (!t.claims.aud.includes(e)) throw rn("unexpected JWT \"aud\" (audience) claim value", _o, {
			expected: e,
			claims: t.claims,
			claim: "aud"
		});
	} else if (t.claims.aud !== e) throw rn("unexpected JWT \"aud\" (audience) claim value", _o, {
		expected: e,
		claims: t.claims,
		claim: "aud"
	});
	return t;
}
function $n(e, t) {
	return void 0 !== t.claims.iss ? eo(e, t) : t;
}
function eo(e, t) {
	var n, o;
	const i = null !== (n = null === (o = e[Lo]) || void 0 === o ? void 0 : o.call(e, t)) && void 0 !== n ? n : e.issuer;
	if (t.claims.iss !== i) throw rn("unexpected JWT \"iss\" (issuer) claim value", _o, {
		expected: i,
		claims: t.claims,
		claim: "iss"
	});
	return t;
}
var to = /* @__PURE__ */ new WeakSet();
var no = Symbol();
var oo = {
	aud: "audience",
	c_hash: "code hash",
	client_id: "client id",
	exp: "expiration time",
	iat: "issued at",
	iss: "issuer",
	jti: "jwt id",
	nonce: "nonce",
	s_hash: "state hash",
	sub: "subject",
	ath: "access token hash",
	htm: "http method",
	htu: "http uri",
	cnf: "confirmation",
	auth_time: "authentication time"
};
function io(e, t) {
	for (const n of e) if (void 0 === t.claims[n]) throw rn("JWT \"".concat(n, "\" (").concat(oo[n], ") claim missing"), mo, { claims: t.claims });
	return t;
}
var ro = Symbol();
var so = Symbol();
async function ao(e, t, n, o) {
	return "string" == typeof (null == o ? void 0 : o.expectedNonce) || "number" == typeof (null == o ? void 0 : o.maxAge) || null != o && o.requireIdToken ? async function(e, t, n, o, i, r, s) {
		const a = [];
		switch (o) {
			case void 0:
				o = ro;
				break;
			case ro: break;
			default: pn(o, "\"expectedNonce\" argument"), a.push("nonce");
		}
		switch (i ??= t.default_max_age, i) {
			case void 0:
				i = so;
				break;
			case so: break;
			default: hn(i, !0, "\"maxAge\" argument"), a.push("auth_time");
		}
		const c = await qn(e, t, n, a, r, s);
		pn(c.id_token, "\"response\" body \"id_token\" property", mo, { body: c });
		const u = Gn(c);
		if (i !== so) {
			const e = vn() + wn(t), n = gn(t);
			if (u.auth_time + i < e - n) throw rn("too much time has elapsed since the last End-User authentication", bo, {
				claims: u,
				now: e,
				tolerance: n,
				claim: "auth_time"
			});
		}
		if (o === ro) {
			if (void 0 !== u.nonce) throw rn("unexpected ID Token \"nonce\" claim value", _o, {
				expected: void 0,
				claims: u,
				claim: "nonce"
			});
		} else if (u.nonce !== o) throw rn("unexpected ID Token \"nonce\" claim value", _o, {
			expected: o,
			claims: u,
			claim: "nonce"
		});
		return c;
	}(e, t, n, o.expectedNonce, o.maxAge, o[qt], o.recognizedTokenTypes) : async function(e, t, n, o, i) {
		const r = await qn(e, t, n, void 0, o, i), s = Gn(r);
		if (s) {
			if (void 0 !== t.default_max_age) {
				hn(t.default_max_age, !0, "\"client.default_max_age\"");
				const e = vn() + wn(t), n = gn(t);
				if (s.auth_time + t.default_max_age < e - n) throw rn("too much time has elapsed since the last End-User authentication", bo, {
					claims: s,
					now: e,
					tolerance: n,
					claim: "auth_time"
				});
			}
			if (void 0 !== s.nonce) throw rn("unexpected ID Token \"nonce\" claim value", _o, {
				expected: void 0,
				claims: s,
				claim: "nonce"
			});
		}
		return r;
	}(e, t, n, null == o ? void 0 : o[qt], null == o ? void 0 : o.recognizedTokenTypes);
}
var co = "OAUTH_WWW_AUTHENTICATE_CHALLENGE";
var uo = "OAUTH_RESPONSE_BODY_ERROR";
var lo = "OAUTH_UNSUPPORTED_OPERATION";
var ho = "OAUTH_AUTHORIZATION_RESPONSE_ERROR";
var po = "OAUTH_JWT_USERINFO_EXPECTED";
var fo = "OAUTH_PARSE_ERROR";
var mo = "OAUTH_INVALID_RESPONSE";
var yo = "OAUTH_RESPONSE_IS_NOT_JSON";
var wo = "OAUTH_RESPONSE_IS_NOT_CONFORM";
var go = "OAUTH_HTTP_REQUEST_FORBIDDEN";
var vo = "OAUTH_REQUEST_PROTOCOL_FORBIDDEN";
var bo = "OAUTH_JWT_TIMESTAMP_CHECK_FAILED";
var _o = "OAUTH_JWT_CLAIM_COMPARISON_FAILED";
var ko = "OAUTH_JSON_ATTRIBUTE_COMPARISON_FAILED";
var So = "OAUTH_MISSING_SERVER_METADATA";
var To = "OAUTH_INVALID_SERVER_METADATA";
async function Po(e) {
	if (!zt(e, Response)) throw Ht("\"response\" must be an instance of Response", Dt);
	await Ln(e, 200, "Revocation Endpoint");
}
function Co(e) {
	if (e.bodyUsed) throw Ht("\"response\" body has been used already", Jt);
}
function Eo(e) {
	const t = e.algorithm;
	if ("number" != typeof t.modulusLength || t.modulusLength < 2048) throw new nn("unsupported ".concat(t.name, " modulusLength"), { cause: e });
}
function Ro(e) {
	switch (e.algorithm.namedCurve) {
		case "P-256": return "SHA-256";
		case "P-384": return "SHA-384";
		case "P-521": return "SHA-512";
		default: throw new nn("unsupported ECDSA namedCurve", { cause: e });
	}
}
async function Ao(e, t, n, o, i) {
	let r, s, a = e.split("."), c = a[0], u = a[1], l = a.length;
	if (5 === l) {
		if (void 0 === i) throw new nn("JWE decryption is not configured", { cause: e });
		var d = (e = await i(e)).split(".");
		c = d[0], u = d[1], l = d.length;
	}
	if (3 !== l) throw rn("Invalid JWT", mo, e);
	try {
		r = JSON.parse(Qt(tn(c)));
	} catch (e) {
		throw rn("failed to parse JWT Header body as base64url encoded JSON", fo, e);
	}
	if (!an(r)) throw rn("JWT Header must be a top level object", mo, e);
	if (t(r), void 0 !== r.crit) throw new nn("no JWT \"crit\" header parameter extensions are supported", { cause: { header: r } });
	try {
		s = JSON.parse(Qt(tn(u)));
	} catch (e) {
		throw rn("failed to parse JWT Payload body as base64url encoded JSON", fo, e);
	}
	if (!an(s)) throw rn("JWT Payload must be a top level object", mo, e);
	const h = vn() + n;
	if (void 0 !== s.exp) {
		if ("number" != typeof s.exp) throw rn("unexpected JWT \"exp\" (expiration time) claim type", mo, { claims: s });
		if (s.exp <= h - o) throw rn("unexpected JWT \"exp\" (expiration time) claim value, expiration is past current timestamp", bo, {
			claims: s,
			now: h,
			tolerance: o,
			claim: "exp"
		});
	}
	if (void 0 !== s.iat && "number" != typeof s.iat) throw rn("unexpected JWT \"iat\" (issued at) claim type", mo, { claims: s });
	if (void 0 !== s.iss && "string" != typeof s.iss) throw rn("unexpected JWT \"iss\" (issuer) claim type", mo, { claims: s });
	if (void 0 !== s.nbf) {
		if ("number" != typeof s.nbf) throw rn("unexpected JWT \"nbf\" (not before) claim type", mo, { claims: s });
		if (s.nbf > h + o) throw rn("unexpected JWT \"nbf\" (not before) claim value", bo, {
			claims: s,
			now: h,
			tolerance: o,
			claim: "nbf"
		});
	}
	if (void 0 !== s.aud && "string" != typeof s.aud && !Array.isArray(s.aud)) throw rn("unexpected JWT \"aud\" (audience) claim type", mo, { claims: s });
	return {
		header: r,
		claims: s,
		jwt: e
	};
}
async function xo(e) {
	if ("POST" !== e.method) throw Ht("form_post responses are expected to use the POST method", Jt, { cause: e });
	if ("application/x-www-form-urlencoded" !== Dn(e)) throw Ht("form_post responses are expected to use the application/x-www-form-urlencoded content-type", Jt, { cause: e });
	return async function(e) {
		if (e.bodyUsed) throw Ht("form_post Request instances must contain a readable body", Jt, { cause: e });
		return e.text();
	}(e);
}
function Io(e, t, n, o) {
	if (void 0 === e) if (Array.isArray(t)) {
		if (!t.includes(o.alg)) throw rn("unexpected JWT \"alg\" header parameter", mo, {
			header: o,
			expected: t,
			reason: "authorization server metadata"
		});
	} else {
		if (void 0 === n) throw rn("missing client or server configuration to verify used JWT \"alg\" header parameter", void 0, {
			client: e,
			issuer: t,
			fallback: n
		});
		if ("string" == typeof n ? o.alg !== n : "function" == typeof n ? !n(o.alg) : !n.includes(o.alg)) throw rn("unexpected JWT \"alg\" header parameter", mo, {
			header: o,
			expected: n,
			reason: "default value"
		});
	}
	else if ("string" == typeof e ? o.alg !== e : !e.includes(o.alg)) throw rn("unexpected JWT \"alg\" header parameter", mo, {
		header: o,
		expected: e,
		reason: "client configuration"
	});
}
function Oo(e, t) {
	const n = e.getAll(t), o = n[0];
	if (n.length > 1) throw rn("\"".concat(t, "\" parameter must be provided only once"), mo);
	return o;
}
var jo = Symbol();
var Wo = Symbol();
function No(e, t, n, o) {
	if (bn(e), _n(t), n instanceof URL && (n = n.searchParams), !(n instanceof URLSearchParams)) throw Ht("\"parameters\" must be an instance of URLSearchParams, or URL", Dt);
	if (Oo(n, "response")) throw rn("\"parameters\" contains a JARM response, use validateJwtAuthResponse() instead of validateAuthResponse()", mo, { parameters: n });
	const i = Oo(n, "iss"), r = Oo(n, "state");
	if (!i && e.authorization_response_iss_parameter_supported) throw rn("response parameter \"iss\" (issuer) missing", mo, { parameters: n });
	if (i && i !== e.issuer) throw rn("unexpected \"iss\" (issuer) response parameter value", mo, {
		expected: e.issuer,
		parameters: n
	});
	switch (o) {
		case void 0:
		case Wo:
			if (void 0 !== r) throw rn("unexpected \"state\" response parameter encountered", mo, {
				expected: void 0,
				parameters: n
			});
			break;
		case jo: break;
		default: if (pn(o, "\"expectedState\" argument"), r !== o) throw rn(void 0 === r ? "response parameter \"state\" missing" : "unexpected \"state\" response parameter value", mo, {
			expected: o,
			parameters: n
		});
	}
	if (Oo(n, "error")) throw new An("authorization response from the server is an error", { cause: n });
	const s = Oo(n, "id_token"), a = Oo(n, "token");
	if (void 0 !== s || void 0 !== a) throw new nn("implicit and hybrid flows are not supported");
	return c = new URLSearchParams(n), to.add(c), c;
	var c;
}
async function Mo(e) {
	let t, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : fn;
	try {
		t = await e.json();
	} catch (t) {
		throw n(e), rn("failed to parse \"response\" body as JSON", fo, t);
	}
	if (!an(t)) throw rn("\"response\" body must be a top level object", mo, { body: t });
	return t;
}
var Uo = Symbol();
var Lo = Symbol();
var Ko = new TextEncoder();
var zo = new TextDecoder();
var Jo = new TextDecoder("utf-8", { fatal: !0 });
function Do() {
	for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
	const o = t.reduce((e, t) => e + t.length, 0), i = new Uint8Array(o);
	let r = 0;
	for (const e of t) i.set(e, r), r += e.length;
	return i;
}
var Ho = /[^\x00-\x7f]/;
function Zo(e) {
	if ("string" == typeof e && e.length >= 128) {
		if (Ho.test(e)) throw new TypeError("non-ASCII string encountered in encode()");
		return Ko.encode(e);
	}
	const t = new Uint8Array(e.length);
	for (let n = 0; n < e.length; n++) {
		const o = e.charCodeAt(n);
		if (o > 127) throw new TypeError("non-ASCII string encountered in encode()");
		t[n] = o;
	}
	return t;
}
function Fo(e) {
	let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
	if (Uint8Array.fromBase64) return Uint8Array.fromBase64(e, { alphabet: t ? "base64url" : "base64" });
	if (t) {
		if (e.includes("+") || e.includes("/")) throw new TypeError("Invalid base64url");
		e = e.replace(/-/g, "+").replace(/_/g, "/");
	}
	const n = atob(e), o = new Uint8Array(n.length);
	for (let e = 0; e < n.length; e++) o[e] = n.charCodeAt(e);
	return o;
}
var Vo = class extends Error {
	constructor(e, t) {
		var n;
		super(e, t), h(this, "code", "ERR_JOSE_GENERIC"), this.name = this.constructor.name, null === (n = Error.captureStackTrace) || void 0 === n || n.call(Error, this, this.constructor);
	}
};
h(Vo, "code", "ERR_JOSE_GENERIC");
var Xo = class extends Vo {
	constructor(e, t) {
		let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "unspecified", o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "unspecified";
		super(e, { cause: {
			claim: n,
			reason: o,
			payload: t
		} }), h(this, "code", "ERR_JWT_CLAIM_VALIDATION_FAILED"), h(this, "claim", void 0), h(this, "reason", void 0), h(this, "payload", void 0), this.claim = n, this.reason = o, this.payload = t;
	}
};
h(Xo, "code", "ERR_JWT_CLAIM_VALIDATION_FAILED");
var Go = class extends Vo {
	constructor(e, t) {
		let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "unspecified", o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "unspecified";
		super(e, { cause: {
			claim: n,
			reason: o,
			payload: t
		} }), h(this, "code", "ERR_JWT_EXPIRED"), h(this, "claim", void 0), h(this, "reason", void 0), h(this, "payload", void 0), this.claim = n, this.reason = o, this.payload = t;
	}
};
h(Go, "code", "ERR_JWT_EXPIRED");
var qo = class extends Vo {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JOSE_ALG_NOT_ALLOWED");
	}
};
h(qo, "code", "ERR_JOSE_ALG_NOT_ALLOWED");
var Yo = class extends Vo {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JOSE_NOT_SUPPORTED");
	}
};
h(Yo, "code", "ERR_JOSE_NOT_SUPPORTED");
h(class extends Vo {
	constructor() {
		super(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "decryption operation failed", arguments.length > 1 ? arguments[1] : void 0), h(this, "code", "ERR_JWE_DECRYPTION_FAILED");
	}
}, "code", "ERR_JWE_DECRYPTION_FAILED");
h(class extends Vo {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JWE_INVALID");
	}
}, "code", "ERR_JWE_INVALID");
var Bo = class extends Vo {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JWS_INVALID");
	}
};
h(Bo, "code", "ERR_JWS_INVALID");
var Qo = class extends Vo {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JWT_INVALID");
	}
};
h(Qo, "code", "ERR_JWT_INVALID");
h(class extends Vo {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JWK_INVALID");
	}
}, "code", "ERR_JWK_INVALID");
var $o = class extends Vo {
	constructor() {
		super(...arguments), h(this, "code", "ERR_JWKS_INVALID");
	}
};
h($o, "code", "ERR_JWKS_INVALID");
var ei = class extends Vo {
	constructor() {
		super(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "no applicable key found in the JSON Web Key Set", arguments.length > 1 ? arguments[1] : void 0), h(this, "code", "ERR_JWKS_NO_MATCHING_KEY");
	}
};
h(ei, "code", "ERR_JWKS_NO_MATCHING_KEY");
var ti = class extends Vo {
	constructor() {
		super(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "multiple matching keys found in the JSON Web Key Set", arguments.length > 1 ? arguments[1] : void 0), h(this, Symbol.asyncIterator, w(function* () {})), h(this, "code", "ERR_JWKS_MULTIPLE_MATCHING_KEYS");
	}
};
h(ti, "code", "ERR_JWKS_MULTIPLE_MATCHING_KEYS");
var ni = class extends Vo {
	constructor() {
		super(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "request timed out", arguments.length > 1 ? arguments[1] : void 0), h(this, "code", "ERR_JWKS_TIMEOUT");
	}
};
h(ni, "code", "ERR_JWKS_TIMEOUT");
var oi = class extends Vo {
	constructor() {
		super(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "signature verification failed", arguments.length > 1 ? arguments[1] : void 0), h(this, "code", "ERR_JWS_SIGNATURE_VERIFICATION_FAILED");
	}
};
h(oi, "code", "ERR_JWS_SIGNATURE_VERIFICATION_FAILED");
function ii(e) {
	try {
		return Fo("string" == typeof e ? e : zo.decode(e), !0);
	} catch (e) {
		throw new TypeError("The input to be decoded is not correctly encoded.", { cause: e });
	}
}
function ri(e) {
	return function(e) {
		let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
		if (Uint8Array.prototype.toBase64) return e.toBase64({
			alphabet: t ? "base64url" : "base64",
			omitPadding: t
		});
		const n = [];
		for (let t = 0; t < e.length; t += 32768) n.push(String.fromCharCode.apply(null, e.subarray(t, t + 32768)));
		const o = btoa(n.join(""));
		return t ? o.replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_") : o;
	}("string" == typeof e ? Ko.encode(e) : e, !0);
}
function si(e) {
	if ("object" != typeof e || null === e || "[object Object]" !== Object.prototype.toString.call(e)) return !1;
	const t = Object.getPrototypeOf(e);
	return null === t || null === Object.getPrototypeOf(t);
}
function ai(e) {
	return si(e) && Array.isArray(e.keys) && Array.from(e.keys).every(si);
}
function ci() {
	const e = /* @__PURE__ */ new Set();
	for (var t = arguments.length, n = new Array(t), o = 0; o < t; o++) n[o] = arguments[o];
	for (const t of n) if (t) for (const n of Object.keys(t)) {
		if (e.has(n)) return !1;
		e.add(n);
	}
	return !0;
}
function ui(e, t, n) {
	try {
		return ii(e);
	} catch (e) {
		throw new n("Failed to base64url decode the ".concat(t), { cause: e });
	}
}
var li = {
	__proto__: null,
	b64: !0
};
function di(e, t) {
	if (void 0 !== t && (!Array.isArray(t) || t.some((e) => "string" != typeof e))) throw new TypeError("\"".concat(e, "\" option must be an array of strings"));
	return void 0 === t ? void 0 : new Set(t);
}
function hi(e, t, n, o, i) {
	if (void 0 !== i.crit && void 0 === (null == o ? void 0 : o.crit)) throw new e("\"crit\" (Critical) Header Parameter MUST be integrity protected");
	if (!o || void 0 === o.crit) return [];
	if (!Array.isArray(o.crit) || 0 === o.crit.length || o.crit.some((e) => "string" != typeof e || 0 === e.length)) throw new e("\"crit\" (Critical) Header Parameter MUST be an array of non-empty strings when present");
	const r = void 0 === n ? t : f(f({ __proto__: null }, n), t);
	for (const t of o.crit) {
		if (!(t in r)) throw new Yo("Extension Header Parameter \"".concat(t, "\" is not recognized"));
		if (!Object.hasOwn(i, t) || void 0 === i[t]) throw new e("Extension Header Parameter \"".concat(t, "\" is missing"));
		if (r[t] && (!Object.hasOwn(o, t) || void 0 === o[t])) throw new e("Extension Header Parameter \"".concat(t, "\" MUST be integrity protected"));
	}
	return o.crit;
}
function pi(e, t) {
	if (t.includes("b64")) {
		const t = e.b64;
		if ("boolean" != typeof t) throw new Bo("The \"b64\" (base64url-encode payload) Header Parameter must be a boolean");
		return t;
	}
	return !0;
}
function fi(e, t) {
	let n, o;
	try {
		n = JSON.stringify(t), o = JSON.parse(n);
	} catch (t) {
		throw new e("JOSE Header is not valid JSON", { cause: t });
	}
	if (!si(o)) throw new e("JOSE Header is not a JSON object");
	return [o, n];
}
async function mi(e, t, n) {
	var o;
	const i = e.alg, r = e.secret, s = "decrypt" === n || "sign" === n;
	if (r && t instanceof Uint8Array) return t;
	let a, c;
	if (si(t)) {
		if (a = function(e) {
			const t = Ti(e);
			if (void 0 !== t.ext && "boolean" != typeof t.ext) throw new TypeError("\"ext\" (Extractable) Parameter must be a boolean");
			if (void 0 !== t.key_ops) {
				const e = t.key_ops, n = Array.isArray(e) ? [...e] : void 0;
				if (!n || n.some((e) => "string" != typeof e) || new Set(n).size !== n.length) throw new TypeError("\"key_ops\" (Key Operations) Parameter must be an array of unique strings");
				t.key_ops = n;
			}
			return t;
		}(t), "string" != typeof a.kty) throw bi(i, t, r);
		if (!(r ? "oct" === a.kty && "string" == typeof a.k : "oct" !== a.kty && (s ? "AKP" === a.kty && "string" == typeof a.priv || "string" == typeof a.d : void 0 === a.d && void 0 === a.priv))) throw new TypeError(r ? "JSON Web Key for symmetric algorithms must have JWK \"kty\" (Key Type) equal to \"oct\" and the JWK \"k\" (Key Value) present" : "JSON Web Key for this operation must be a ".concat(s ? "private" : "public", " JWK"));
		if (((e, t, n) => {
			const o = e.alg;
			if (void 0 !== t.use) {
				const e = "sign" === n || "verify" === n ? "sig" : "enc";
				if (t.use !== e) throw new TypeError("Invalid key for this operation, its \"use\" must be \"".concat(e, "\" when present"));
			}
			if (void 0 !== t.alg && t.alg !== o) throw new TypeError("Invalid key for this operation, its \"alg\" must be \"".concat(o, "\" when present"));
			if (Array.isArray(t.key_ops)) {
				var i;
				const o = "encrypt" === n || "decrypt" === n ? null === (i = e.ops) || void 0 === i ? void 0 : i["encrypt" === n ? 0 : 1] : n;
				if (o && !t.key_ops.includes(o)) throw new TypeError("Invalid key for this operation, its \"key_ops\" must include \"".concat(o, "\" when present"));
			}
		})(e, a, n), "oct" === a.kty) return ii(a.k);
		if (!Object.isFrozen(t)) {
			const e = t.key_ops;
			Array.isArray(e) && Object.freeze(e), Object.freeze(t);
		}
	} else {
		if (!vi(t)) throw bi(i, t, r);
		const e = r ? "secret" : s ? "private" : "public";
		if (t.type !== e && (r || [
			"secret",
			"public",
			"private"
		].includes(t.type))) throw new TypeError("".concat(((e) => e[Symbol.toStringTag])(t), " instances must be of type \"").concat(e, "\" for the ").concat(i, " algorithm"));
		if (gi(t)) return t;
		if (c = t, "secret" === c.type) return c.export();
	}
	yi || (yi = /* @__PURE__ */ new WeakMap());
	const u = t;
	let l = yi.get(u);
	if (null !== (o = l) && void 0 !== o && o[i]) return l[i];
	if (l || yi.set(u, l = {}), c && "function" == typeof c.toCryptoKey) {
		var d, h, p;
		const t = "public" === c.type, n = wi[null === (d = c.asymmetricKeyDetails) || void 0 === d ? void 0 : d.namedCurve], o = null !== (h = null === (p = e.resolve) || void 0 === p ? void 0 : p.call(e, {
			crv: n,
			asymmetricKeyType: c.asymmetricKeyType
		})) && void 0 !== h ? h : e.subtle;
		return l[i] = c.toCryptoKey(o, t, e.usages[t ? 0 : 1]);
	}
	return a ??= c.export({ format: "jwk" }), a.alg = i, l[i] = await Pi(e, a);
}
var yi;
var wi = {
	__proto__: null,
	prime256v1: "P-256",
	secp384r1: "P-384",
	secp521r1: "P-521"
};
var gi = (e) => {
	if ("CryptoKey" === (null == e ? void 0 : e[Symbol.toStringTag])) return !0;
	try {
		return e instanceof CryptoKey;
	} catch (e) {
		return !1;
	}
};
var vi = (e) => gi(e) || ((e) => "KeyObject" === (null == e ? void 0 : e[Symbol.toStringTag]))(e);
function bi(e, t, n) {
	const o = [
		"CryptoKey",
		"KeyObject",
		"JSON Web Key"
	];
	return n && o.push("Uint8Array"), new TypeError(function(e, t) {
		for (var n, o = arguments.length, i = new Array(o > 2 ? o - 2 : 0), r = 2; r < o; r++) i[r - 2] = arguments[r];
		if (i.length > 2) {
			const t = i.pop();
			e += "one of type ".concat(i.join(", "), ", or ").concat(t, ".");
		} else 2 === i.length ? e += "one of type ".concat(i[0], " or ").concat(i[1], ".") : e += "of type ".concat(i[0], ".");
		return null == t ? e += " Received ".concat(t) : "function" == typeof t && t.name ? e += " Received function ".concat(t.name) : "object" == typeof t && null != t && null !== (n = t.constructor) && void 0 !== n && n.name && (e += " Received an instance of ".concat(t.constructor.name)), e;
	}("Key for the ".concat(e, " algorithm must be "), t, ...o));
}
var _i = function(e) {
	return new TypeError("CryptoKey does not support this operation, its ".concat(arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "algorithm.name", " must be ").concat(e));
};
function ki(e, t) {
	const n = t.algorithm.modulusLength;
	if ("number" != typeof n || n < 2048) throw new TypeError("".concat(e, " requires key modulusLength to be 2048 bits or larger"));
}
function Si(e, t, n) {
	var o;
	const i = e.algorithm;
	if (i.name !== t.name) throw _i(t.name);
	if (t.hash && (null === (o = i.hash) || void 0 === o ? void 0 : o.name) !== t.hash) throw _i(t.hash, "algorithm.hash");
	if (t.namedCurve && i.namedCurve !== t.namedCurve) throw _i(t.namedCurve, "algorithm.namedCurve");
	if (void 0 !== t.length && i.length !== t.length) throw _i(t.length, "algorithm.length");
	(function(e, t) {
		if (t && !e.usages.includes(t)) throw new TypeError("CryptoKey does not support this operation, its usages must include ".concat(t, "."));
	})(e, n);
}
function Ti(e) {
	return f({ __proto__: null }, e);
}
async function Pi(e, t, n) {
	var o, i, r, s;
	if (!e.kty.includes(t.kty)) throw new Yo("Invalid or unsupported JWK \"alg\" (Algorithm) Parameter value");
	const a = null !== (o = null === (i = e.resolve) || void 0 === i ? void 0 : i.call(e, {
		kty: t.kty,
		crv: t.crv
	})) && void 0 !== o ? o : e.subtle, c = !(!t.d && !t.priv), u = f(f({}, t), {}, { ext: null != n ? n : t.ext });
	return "AKP" !== u.kty && delete u.alg, delete u.use, crypto.subtle.importKey("jwk", u, a, null !== (r = u.ext) && void 0 !== r ? r : !c, null !== (s = t.key_ops) && void 0 !== s ? s : e.usages[c ? 1 : 0]);
}
async function Ci(e, t, n) {
	let o = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
	return e instanceof Uint8Array && (e = await crypto.subtle.importKey("raw", e, t, o, [n])), Si(e, t, n), e;
}
function Ei(e) {
	const t = { __proto__: null };
	for (const n in e) t[n] = f(f({}, e[n]), {}, { alg: n });
	return t;
}
var Ri = [["encrypt", "wrapKey"], ["decrypt", "unwrapKey"]];
var Ai = [[], ["deriveBits"]];
var xi = [[], []];
function Ii(e) {
	return {
		kty: ["RSA"],
		mode: "key-encryption",
		subtle: {
			name: "RSA-OAEP",
			hash: "SHA-".concat(e)
		},
		usages: Ri,
		ops: ["wrapKey", "unwrapKey"]
	};
}
function Oi(e) {
	return {
		kty: ["EC", "OKP"],
		mode: e,
		subtle: { name: "ECDH" },
		resolve: (e) => {
			let t = e.kty, n = e.crv, o = e.asymmetricKeyType;
			if ("X25519" === n || "x25519" === o) return { name: "X25519" };
			if ("OKP" === t) throw new Yo("Invalid or unsupported JWK \"alg\" (Algorithm) Parameter value");
			return {
				name: "ECDH",
				namedCurve: n
			};
		},
		usages: Ai,
		ops: [void 0, "deriveBits"]
	};
}
function ji(e) {
	let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
	return {
		kty: ["oct"],
		mode: "key-wrapping",
		secret: !0,
		subtle: {
			name: t ? "AES-GCM" : "AES-KW",
			length: e
		},
		usages: xi,
		ops: t ? ["encrypt", "decrypt"] : ["wrapKey", "unwrapKey"]
	};
}
function Wi() {
	return {
		kty: ["oct"],
		mode: "key-wrapping",
		secret: !0,
		subtle: { name: "PBKDF2" },
		usages: xi,
		ops: ["deriveBits", "deriveBits"]
	};
}
var Ni = Ei({
	dir: {
		kty: ["oct"],
		mode: "direct-encryption",
		secret: !0,
		subtle: { name: "AES-GCM" },
		usages: xi,
		ops: ["encrypt", "decrypt"]
	},
	"RSA-OAEP": Ii(1),
	"RSA-OAEP-256": Ii(256),
	"RSA-OAEP-384": Ii(384),
	"RSA-OAEP-512": Ii(512),
	"ECDH-ES": Oi("direct-key-agreement"),
	"ECDH-ES+A128KW": Oi("key-agreement-with-key-wrapping"),
	"ECDH-ES+A192KW": Oi("key-agreement-with-key-wrapping"),
	"ECDH-ES+A256KW": Oi("key-agreement-with-key-wrapping"),
	A128KW: ji(128),
	A192KW: ji(192),
	A256KW: ji(256),
	A128GCMKW: ji(128, !0),
	A192GCMKW: ji(192, !0),
	A256GCMKW: ji(256, !0),
	"PBES2-HS256+A128KW": Wi(),
	"PBES2-HS384+A192KW": Wi(),
	"PBES2-HS512+A256KW": Wi()
});
var Mi = ["encrypt", "decrypt"];
function Ui(e) {
	let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
	return {
		kty: ["oct"],
		secret: !0,
		subtle: {
			name: t ? "AES-CBC" : "AES-GCM",
			length: e
		},
		usages: xi,
		ops: Mi,
		cekBits: e,
		ivBits: t ? 128 : 96,
		cbc: t
	};
}
var Li;
var Ki;
var zi;
var Ji;
if (Ei({
	A128GCM: Ui(128),
	A192GCM: Ui(192),
	A256GCM: Ui(256),
	"A128CBC-HS256": Ui(256, !0),
	"A192CBC-HS384": Ui(384, !0),
	"A256CBC-HS512": Ui(512, !0)
}), "undefined" == typeof navigator || null === (Li = navigator.userAgent) || void 0 === Li || null === (Ki = Li.startsWith) || void 0 === Ki || !Ki.call(Li, "Mozilla/5.0 ")) Ji = "".concat("openid-client", "/").concat("v6.8.4"), zi = { "user-agent": Ji };
var Di = (e) => Hi.get(e);
var Hi;
var Zi;
function Fi(e) {
	return void 0 !== e ? kn(e) : (Zi || (Zi = /* @__PURE__ */ new WeakMap()), (e, t, n, o) => {
		let i;
		return (i = Zi.get(t)) || (function(e, t) {
			if ("string" != typeof e) throw Yi("".concat(t, " must be a string"), qi);
			if (0 === e.length) throw Yi("".concat(t, " must not be empty"), Gi);
		}(t.client_secret, "\"metadata.client_secret\""), i = kn(t.client_secret), Zi.set(t, i)), i(e, t, n, o);
	});
}
var Vi = Jn;
var Xi = Xt;
var Gi = "ERR_INVALID_ARG_VALUE";
var qi = "ERR_INVALID_ARG_TYPE";
function Yi(e, t, n) {
	const o = new TypeError(e, { cause: n });
	return Object.assign(o, { code: t }), o;
}
function Bi(e) {
	return async function(e) {
		return pn(e, "codeVerifier"), tn(await crypto.subtle.digest("SHA-256", Qt(e)));
	}(e);
}
function Qi() {
	return mn();
}
var $i = class extends Error {
	constructor(e, t) {
		var n;
		super(e, t), h(this, "code", void 0), this.name = this.constructor.name, this.code = null == t ? void 0 : t.code, null === (n = Error.captureStackTrace) || void 0 === n || n.call(Error, this, this.constructor);
	}
};
function er(e, t, n) {
	return new $i(e, {
		cause: t,
		code: n
	});
}
function tr(e) {
	if (e instanceof TypeError || e instanceof $i || e instanceof Rn || e instanceof An || e instanceof xn) throw e;
	if (e instanceof on) switch (e.code) {
		case go: throw er("only requests to HTTPS are allowed", e, e.code);
		case vo: throw er("only requests to HTTP or HTTPS are allowed", e, e.code);
		case wo: throw er("unexpected HTTP response status code", e.cause, e.code);
		case yo: throw er("unexpected response content-type", e.cause, e.code);
		case fo: throw er("parsing error occured", e, e.code);
		case mo: throw er("invalid response encountered", e, e.code);
		case _o: throw er("unexpected JWT claim value encountered", e, e.code);
		case ko: throw er("unexpected JSON attribute value encountered", e, e.code);
		case bo: throw er("JWT timestamp claim value failed validation", e, e.code);
		default: throw er(e.message, e, e.code);
	}
	if (e instanceof nn) throw er("unsupported operation", e, e.code);
	if (e instanceof DOMException) switch (e.name) {
		case "OperationError": throw er("runtime operation error", e, lo);
		case "NotSupportedError": throw er("runtime unsupported operation", e, lo);
		case "TimeoutError": throw er("operation timed out", e, "OAUTH_TIMEOUT");
		case "AbortError": throw er("operation aborted", e, "OAUTH_ABORT");
	}
	throw new $i("something went wrong", { cause: e });
}
async function nr(e, t, n, o, i) {
	const s = new ir(await async function(e, t) {
		var n, o;
		if (!(e instanceof URL)) throw Yi("\"server\" must be an instance of URL", qi);
		const i = !e.href.includes("/.well-known/"), r = null !== (n = null == t ? void 0 : t.timeout) && void 0 !== n ? n : 30, s = AbortSignal.timeout(1e3 * r), a = await (i ? dn(e, {
			algorithm: null == t ? void 0 : t.algorithm,
			[Xt]: null == t ? void 0 : t[Xi],
			[Zt]: null == t || null === (o = t.execute) || void 0 === o ? void 0 : o.includes(lr),
			signal: s,
			headers: new Headers(zi)
		}) : ((null == t ? void 0 : t[Xi]) || fetch)((Pn(e, null == t || null === (c = t.execute) || void 0 === c || !c.includes(lr)), e.href), {
			headers: Object.fromEntries(new Headers(f({ accept: "application/json" }, zi)).entries()),
			body: void 0,
			method: "GET",
			redirect: "manual",
			signal: s
		})).then((e) => async function(e, t) {
			const n = e;
			if (!(n instanceof URL) && n !== Uo) throw Ht("\"expectedIssuerIdentifier\" must be an instance of URL", Dt);
			if (!zt(t, Response)) throw Ht("\"response\" must be an instance of Response", Dt);
			if (200 !== t.status) throw rn("\"response\" is not a conform Authorization Server Metadata response (unexpected HTTP status code)", wo, t);
			Co(t);
			const o = await Mo(t);
			if (pn(o.issuer, "\"response\" body \"issuer\" property", mo, { body: o }), n !== Uo && new URL(o.issuer).href !== n.href) throw rn("\"response\" body \"issuer\" property does not match the expected value", ko, {
				expected: n.href,
				body: o,
				attribute: "issuer"
			});
			return o;
		}(Uo, e)).catch(tr);
		var c;
		i && new URL(a.issuer).href !== e.href && (function(e, t, n) {
			return !("https://login.microsoftonline.com" !== e.origin || null != n && n.algorithm && "oidc" !== n.algorithm || (t[or] = !0, 0));
		}(e, a, t) || function(e, t) {
			return !(!e.hostname.endsWith(".b2clogin.com") || null != t && t.algorithm && "oidc" !== t.algorithm);
		}(e, t) || (() => {
			throw new $i("discovered metadata issuer does not match the expected issuer", {
				code: ko,
				cause: {
					expected: e.href,
					body: a,
					attribute: "issuer"
				}
			});
		})());
		return a;
	}(e, i), t, n, o);
	let a = Di(s);
	if (null != i && i[Xi] && (a.fetch = i[Xi]), null != i && i.timeout && (a.timeout = i.timeout), null != i && i.execute) for (const e of i.execute) e(s);
	return s;
}
new TextDecoder();
var or = Symbol();
var ir = class {
	constructor(e, t, n, o) {
		var i, r, s, a, c;
		if ("string" != typeof t || !t.length) throw Yi("\"clientId\" must be a non-empty string", qi);
		if ("string" == typeof n && (n = { client_secret: n }), void 0 !== (null === (i = n) || void 0 === i ? void 0 : i.client_id) && t !== n.client_id) throw Yi("\"clientId\" and \"metadata.client_id\" must be the same", Gi);
		const u = f(f({}, structuredClone(n)), {}, { client_id: t });
		let l;
		u[Ft] = null !== (r = null === (s = n) || void 0 === s ? void 0 : s[Ft]) && void 0 !== r ? r : 0, u[Vt] = null !== (a = null === (c = n) || void 0 === c ? void 0 : c[Vt]) && void 0 !== a ? a : 30, l = o || ("string" == typeof u.client_secret && u.client_secret.length ? Fi(u.client_secret) : (e, t, n, o) => {
			n.set("client_id", t.client_id);
		});
		let d = Object.freeze(u);
		const h = structuredClone(e);
		or in e && (h[Lo] = (t) => {
			let n = t.claims.tid;
			return e.issuer.replace("{tenantid}", n);
		});
		let p = Object.freeze(h);
		Hi || (Hi = /* @__PURE__ */ new WeakMap()), Hi.set(this, {
			__proto__: null,
			as: p,
			c: d,
			auth: l,
			tlsOnly: !0,
			jwksCache: {}
		});
	}
	serverMetadata() {
		const e = structuredClone(Di(this).as);
		return function(e) {
			Object.defineProperties(e, function(e) {
				return { supportsPKCE: {
					__proto__: null,
					value() {
						var t;
						let n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "S256";
						return !0 === (null === (t = e.code_challenge_methods_supported) || void 0 === t ? void 0 : t.includes(n));
					}
				} };
			}(e));
		}(e), e;
	}
	clientMetadata() {
		return structuredClone(Di(this).c);
	}
	get timeout() {
		return Di(this).timeout;
	}
	set timeout(e) {
		Di(this).timeout = e;
	}
	get [Xi]() {
		return Di(this).fetch;
	}
	set [Xi](e) {
		Di(this).fetch = e;
	}
};
function rr(e) {
	Object.defineProperties(e, function(e) {
		let t;
		if (void 0 !== e.expires_in) {
			const n = /* @__PURE__ */ new Date();
			n.setSeconds(n.getSeconds() + e.expires_in), t = n.getTime();
		}
		return {
			expiresIn: {
				__proto__: null,
				value() {
					if (t) {
						const e = Date.now();
						return t > e ? Math.floor((t - e) / 1e3) : 0;
					}
				}
			},
			claims: {
				__proto__: null,
				value() {
					try {
						return Gn(this);
					} catch (e) {
						return;
					}
				}
			}
		};
	}(e));
}
async function sr(e, t, n) {
	var o;
	let i = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
	const r = null === (o = e.headers.get("retry-after")) || void 0 === o ? void 0 : o.trim();
	if (void 0 === r) return;
	let s;
	if (/^\d+$/.test(r)) s = parseInt(r, 10);
	else {
		const e = new Date(r);
		if (Number.isFinite(e.getTime())) {
			const t = /* @__PURE__ */ new Date(), n = e.getTime() - t.getTime();
			n > 0 && (s = Math.ceil(n / 1e3));
		}
	}
	if (i && !Number.isFinite(s)) throw new on("invalid Retry-After header value", { cause: e });
	s > t && await ar(s - t, n);
}
function ar(e, t) {
	return new Promise((n, o) => {
		const i = (e) => {
			try {
				t.throwIfAborted();
			} catch (e) {
				o(e);
				return;
			}
			if (e <= 0) return void n();
			const r = Math.min(e, 5);
			setTimeout(() => i(e - r), 1e3 * r);
		};
		i(e);
	});
}
async function cr(e, t) {
	yr(e);
	const n = Di(e), o = n.as, i = n.c, r = n.auth, s = n.fetch, a = n.tlsOnly, c = n.timeout;
	return async function(e, t, n, o, i) {
		bn(e), _n(t);
		const r = En(e, "backchannel_authentication_endpoint", t.use_mtls_endpoint_aliases, !0 !== (null == i ? void 0 : i[Zt])), s = new URLSearchParams(o);
		s.set("client_id", t.client_id);
		const a = cn(null == i ? void 0 : i.headers);
		return a.set("accept", "application/json"), Zn(e, t, n, r, s, a, i);
	}(o, i, r, t, {
		[Xt]: s,
		[Zt]: !a,
		headers: new Headers(zi),
		signal: wr(c)
	}).then((e) => async function(e, t, n) {
		if (bn(e), _n(t), !zt(n, Response)) throw Ht("\"response\" must be an instance of Response", Dt);
		await Ln(n, 200, "Backchannel Authentication Endpoint"), Co(n);
		const o = await Mo(n);
		pn(o.auth_req_id, "\"response\" body \"auth_req_id\" property", mo, { body: o });
		let i = "number" != typeof o.expires_in ? parseFloat(o.expires_in) : o.expires_in;
		return hn(i, !0, "\"response\" body \"expires_in\" property", mo, { body: o }), o.expires_in = i, void 0 !== o.interval && hn(o.interval, !1, "\"response\" body \"interval\" property", mo, { body: o }), o;
	}(o, i, e)).catch(tr);
}
async function ur(e, t, n, o) {
	var i, r;
	yr(e), n = new URLSearchParams(n);
	let s = null !== (i = t.interval) && void 0 !== i ? i : 5;
	const a = null !== (r = null == o ? void 0 : o.signal) && void 0 !== r ? r : AbortSignal.timeout(1e3 * t.expires_in);
	try {
		await ar(s, a);
	} catch (e) {
		tr(e);
	}
	const c = Di(e), u = c.as, l = c.c, d = c.auth, h = c.fetch, p = c.tlsOnly, m = c.nonRepudiation, y = c.timeout, w = c.decrypt, g = (i, r) => ur(e, f(f({}, t), {}, { interval: i }), n, f(f({}, o), {}, {
		signal: a,
		flag: r
	})), v = function(e, t) {
		const n = wr(t);
		if (!n) return {
			signal: e,
			cleanup() {}
		};
		const o = new AbortController(), i = (e) => {
			const t = e.target;
			o.abort(t.reason);
		};
		return e.aborted ? o.abort(e.reason) : n.aborted ? o.abort(n.reason) : (e.addEventListener("abort", i, { once: !0 }), n.addEventListener("abort", i, { once: !0 })), {
			signal: o.signal,
			cleanup() {
				e.removeEventListener("abort", i), n.removeEventListener("abort", i);
			}
		};
	}(a, y), b = await async function(e, t, n, o, i) {
		bn(e), _n(t), pn(o, "\"authReqId\"");
		const r = new URLSearchParams(null == i ? void 0 : i.additionalParameters);
		return r.set("auth_req_id", o), Fn(e, t, n, "urn:openid:params:grant-type:ciba", r, i);
	}(u, l, d, t.auth_req_id, {
		[Xt]: h,
		[Zt]: !p,
		additionalParameters: n,
		DPoP: null == o ? void 0 : o.DPoP,
		headers: new Headers(zi),
		signal: v.signal
	}).catch(tr).finally(v.cleanup);
	var _;
	if (503 === b.status && b.headers.has("retry-after")) return await sr(b, s, a, !0), await (null === (_ = b.body) || void 0 === _ ? void 0 : _.cancel()), g(s);
	const k = async function(e, t, n, o) {
		return qn(e, t, n, void 0, null == o ? void 0 : o[qt], null == o ? void 0 : o.recognizedTokenTypes);
	}(u, l, b, { [qt]: w });
	let S;
	try {
		S = await k;
	} catch (e) {
		if (vr(e, o)) return g(s, br);
		if (e instanceof Rn) switch (e.error) {
			case "slow_down": s += 5;
			case "authorization_pending": return await sr(e.response, s, a), g(s);
		}
		tr(e);
	}
	return S.id_token && await (null == m ? void 0 : m(b)), rr(S), S;
}
function lr(e) {
	Di(e).tlsOnly = !1;
}
async function dr(e, t, n, o, i) {
	if (yr(e), !((null == i ? void 0 : i.flag) === br || t instanceof URL || function(e, t) {
		try {
			return Object.getPrototypeOf(e)[Symbol.toStringTag] === t;
		} catch (e) {
			return !1;
		}
	}(t, "Request"))) throw Yi("\"currentUrl\" must be an instance of URL, or Request", qi);
	let r, s;
	const a = Di(e), c = a.as, u = a.c, l = a.auth, d = a.fetch, h = a.tlsOnly, p = a.jarm, m = a.hybrid, w = a.nonRepudiation, g = a.timeout, v = a.decrypt, b = a.implicit;
	if ((null == i ? void 0 : i.flag) === br) r = i.authResponse, s = i.redirectUri;
	else {
		if (!(t instanceof URL)) {
			const e = t;
			switch (t = new URL(t.url), e.method) {
				case "GET": break;
				case "POST":
					const n = new URLSearchParams(await xo(e));
					if (m) t.hash = n.toString();
					else for (const e of n.entries()) {
						var _ = y(e, 2);
						const n = _[0], o = _[1];
						t.searchParams.append(n, o);
					}
					break;
				default: throw Yi("unexpected Request HTTP method", Gi);
			}
		}
		switch (s = function(e) {
			return (e = new URL(e)).search = "", e.hash = "", e.href;
		}(t), !0) {
			case !!p:
				r = await p(t, null == n ? void 0 : n.expectedState);
				break;
			case !!m:
				r = await m(t, null == n ? void 0 : n.expectedNonce, null == n ? void 0 : n.expectedState, null == n ? void 0 : n.maxAge);
				break;
			case !!b: throw new TypeError("authorizationCodeGrant() cannot be used by response_type=id_token clients");
			default: try {
				r = No(c, u, t.searchParams, null == n ? void 0 : n.expectedState);
			} catch (e) {
				tr(e);
			}
		}
	}
	const k = await async function(e, t, n, o, i, r, s) {
		if (bn(e), _n(t), !to.has(o)) throw Ht("\"callbackParameters\" must be an instance of URLSearchParams obtained from \"validateAuthResponse()\", or \"validateJwtAuthResponse()", Jt);
		pn(i, "\"redirectUri\"");
		const a = Oo(o, "code");
		if (!a) throw rn("no authorization code in \"callbackParameters\"", mo);
		const c = new URLSearchParams(null == s ? void 0 : s.additionalParameters);
		return c.set("redirect_uri", i), c.set("code", a), r !== no && (pn(r, "\"codeVerifier\""), c.set("code_verifier", r)), Fn(e, t, n, "authorization_code", c, s);
	}(c, u, l, r, s, (null == n ? void 0 : n.pkceCodeVerifier) || no, {
		additionalParameters: o,
		[Xt]: d,
		[Zt]: !h,
		DPoP: null == i ? void 0 : i.DPoP,
		headers: new Headers(zi),
		signal: wr(g)
	}).catch(tr);
	"string" != typeof (null == n ? void 0 : n.expectedNonce) && "number" != typeof (null == n ? void 0 : n.maxAge) || (n.idTokenExpected = !0);
	const S = ao(c, u, k, {
		expectedNonce: null == n ? void 0 : n.expectedNonce,
		maxAge: null == n ? void 0 : n.maxAge,
		requireIdToken: null == n ? void 0 : n.idTokenExpected,
		[qt]: v
	});
	let T;
	try {
		T = await S;
	} catch (t) {
		if (vr(t, i)) return dr(e, void 0, n, o, f(f({}, i), {}, {
			flag: br,
			authResponse: r,
			redirectUri: s
		}));
		tr(t);
	}
	return T.id_token && await (null == w ? void 0 : w(k)), rr(T), T;
}
async function hr(e, t, n, o) {
	yr(e), n = new URLSearchParams(n);
	const i = Di(e), r = i.as, s = i.c, a = i.auth, c = i.fetch, u = i.tlsOnly, l = i.nonRepudiation, d = i.timeout, h = i.decrypt, p = await async function(e, t, n, o, i) {
		bn(e), _n(t), pn(o, "\"refreshToken\"");
		const r = new URLSearchParams(null == i ? void 0 : i.additionalParameters);
		return r.set("refresh_token", o), Fn(e, t, n, "refresh_token", r, i);
	}(r, s, a, t, {
		[Xt]: c,
		[Zt]: !u,
		additionalParameters: n,
		DPoP: null == o ? void 0 : o.DPoP,
		headers: new Headers(zi),
		signal: wr(d)
	}).catch(tr), m = async function(e, t, n, o) {
		return qn(e, t, n, void 0, null == o ? void 0 : o[qt], null == o ? void 0 : o.recognizedTokenTypes);
	}(r, s, p, { [qt]: h });
	let y;
	try {
		y = await m;
	} catch (i) {
		if (vr(i, o)) return hr(e, t, n, f(f({}, o), {}, { flag: br }));
		tr(i);
	}
	return y.id_token && await (null == l ? void 0 : l(p)), rr(y), y;
}
async function pr(e, t, n) {
	yr(e), t = new URLSearchParams(t);
	const o = Di(e), i = o.as, r = o.c, s = o.auth, a = o.fetch, c = o.tlsOnly, u = o.timeout, d = async function(e, t, n, o) {
		return qn(e, t, n, void 0, null == o ? void 0 : o[qt], null == o ? void 0 : o.recognizedTokenTypes);
	}(i, r, await async function(e, t, n, o, i) {
		return bn(e), _n(t), Fn(e, t, n, "client_credentials", new URLSearchParams(o), i);
	}(i, r, s, t, {
		[Xt]: a,
		[Zt]: !c,
		DPoP: null == n ? void 0 : n.DPoP,
		headers: new Headers(zi),
		signal: wr(u)
	}).catch(tr));
	let h;
	try {
		h = await d;
	} catch (o) {
		if (vr(o, n)) return pr(e, t, f(f({}, n), {}, { flag: br }));
		tr(o);
	}
	return rr(h), h;
}
function fr(e, t) {
	yr(e);
	const n = Di(e), o = n.as, i = n.c, r = n.tlsOnly, s = n.hybrid, a = n.jarm, c = n.implicit, u = En(o, "authorization_endpoint", !1, r);
	if ((t = new URLSearchParams(t)).has("client_id") || t.set("client_id", i.client_id), !t.has("request_uri") && !t.has("request")) {
		if (t.has("response_type") || t.set("response_type", s ? "code id_token" : c ? "id_token" : "code"), c && !t.has("nonce")) throw Yi("response_type=id_token clients must provide a nonce parameter in their authorization request parameters", Gi);
		a && t.set("response_mode", "jwt");
	}
	for (const e of t.entries()) {
		var l = y(e, 2);
		const t = l[0], n = l[1];
		u.searchParams.append(t, n);
	}
	return u;
}
async function mr(e, t, n) {
	yr(e);
	const o = fr(e, t), i = Di(e), r = i.as, s = i.c, a = i.auth, c = i.fetch, u = i.tlsOnly, l = i.timeout, h = async function(e, t, n) {
		if (bn(e), _n(t), !zt(n, Response)) throw Ht("\"response\" must be an instance of Response", Dt);
		await Ln(n, 201, "Pushed Authorization Request Endpoint"), Co(n);
		const o = await Mo(n);
		pn(o.request_uri, "\"response\" body \"request_uri\" property", mo, { body: o });
		let i = "number" != typeof o.expires_in ? parseFloat(o.expires_in) : o.expires_in;
		return hn(i, !0, "\"response\" body \"expires_in\" property", mo, { body: o }), o.expires_in = i, o;
	}(r, s, await async function(e, t, n, o, i) {
		var r;
		bn(e), _n(t);
		const s = En(e, "pushed_authorization_request_endpoint", t.use_mtls_endpoint_aliases, !0 !== (null == i ? void 0 : i[Zt])), a = new URLSearchParams(o);
		a.set("client_id", t.client_id);
		const c = cn(null == i ? void 0 : i.headers);
		c.set("accept", "application/json"), void 0 !== (null == i ? void 0 : i.DPoP) && (Kn(i.DPoP), await i.DPoP.addProof(s, c, "POST"));
		const u = await Zn(e, t, n, s, a, c, i);
		return null == i || null === (r = i.DPoP) || void 0 === r || r.cacheNonce(u, s), u;
	}(r, s, a, o.searchParams, {
		[Xt]: c,
		[Zt]: !u,
		DPoP: null == n ? void 0 : n.DPoP,
		headers: new Headers(zi),
		signal: wr(l)
	}).catch(tr));
	let p;
	try {
		p = await h;
	} catch (o) {
		if (vr(o, n)) return mr(e, t, f(f({}, n), {}, { flag: br }));
		tr(o);
	}
	return fr(e, { request_uri: p.request_uri });
}
function yr(e) {
	if (!(e instanceof ir)) throw Yi("\"config\" must be an instance of Configuration", qi);
	if (Object.getPrototypeOf(e) !== ir.prototype) throw Yi("subclassing Configuration is not allowed", Gi);
}
function wr(e) {
	return e ? AbortSignal.timeout(1e3 * e) : void 0;
}
async function gr(e, t, n, o) {
	yr(e);
	const i = Di(e), r = i.as, s = i.c, a = i.fetch, c = i.tlsOnly, u = i.nonRepudiation, l = i.timeout, d = i.decrypt, h = await zn(r, s, t, {
		[Xt]: a,
		[Zt]: !c,
		DPoP: null == o ? void 0 : o.DPoP,
		headers: new Headers(zi),
		signal: wr(l)
	}).catch(tr);
	let p, m = Hn(r, s, n, h, { [qt]: d });
	try {
		p = await m;
	} catch (i) {
		if (vr(i, o)) return gr(e, t, n, f(f({}, o), {}, { flag: br }));
		tr(i);
	}
	return "application/jwt" === Dn(h) && await (null == u ? void 0 : u(h)), p;
}
function vr(e, t) {
	return !(null == t || !t.DPoP || t.flag === br) && function(e) {
		if (e instanceof xn) {
			const t = e.cause, n = t[0];
			return 1 === t.length && "dpop" === n.scheme && "use_dpop_nonce" === n.parameters.error;
		}
		return e instanceof Rn && "use_dpop_nonce" === e.error;
	}(e);
}
Object.freeze(ir.prototype);
var br = Symbol();
async function _r(e, t, n, o) {
	yr(e);
	const i = Di(e), r = i.as, s = i.c, a = i.auth, c = i.fetch, u = i.tlsOnly, l = i.timeout, d = i.decrypt, h = i.nonRepudiation, p = await async function(e, t, n, o, i, r) {
		return bn(e), _n(t), pn(o, "\"grantType\""), Fn(e, t, n, o, new URLSearchParams(i), r);
	}(r, s, a, t, new URLSearchParams(n), {
		[Xt]: c,
		[Zt]: !u,
		DPoP: null == o ? void 0 : o.DPoP,
		headers: new Headers(zi),
		signal: wr(l)
	}).catch(tr);
	let m;
	"urn:ietf:params:oauth:grant-type:token-exchange" === t && (m = { n_a: () => {} });
	const y = async function(e, t, n, o) {
		return qn(e, t, n, void 0, null == o ? void 0 : o[qt], null == o ? void 0 : o.recognizedTokenTypes);
	}(r, s, p, {
		[qt]: d,
		recognizedTokenTypes: m
	});
	let w;
	try {
		w = await y;
	} catch (i) {
		if (vr(i, o)) return _r(e, t, n, f(f({}, o), {}, { flag: br }));
		tr(i);
	}
	return w.id_token && await (null == h ? void 0 : h(p)), rr(w), w;
}
async function kr(e, t, n) {
	yr(e);
	const o = Di(e), i = o.as, r = o.c, s = o.auth, a = o.fetch, c = o.tlsOnly, u = o.timeout;
	return async function(e, t, n, o, i) {
		bn(e), _n(t), pn(o, "\"token\"");
		const r = En(e, "revocation_endpoint", t.use_mtls_endpoint_aliases, !0 !== (null == i ? void 0 : i[Zt])), s = new URLSearchParams(null == i ? void 0 : i.additionalParameters);
		s.set("token", o);
		const a = cn(null == i ? void 0 : i.headers);
		return a.delete("accept"), Zn(e, t, n, r, s, a, i);
	}(i, r, s, t, {
		[Xt]: a,
		[Zt]: !c,
		additionalParameters: new URLSearchParams(n),
		headers: new Headers(zi),
		signal: wr(u)
	}).then(Po).catch(tr);
}
var Sr = [["verify"], ["sign"]];
function Tr(e) {
	const t = {
		name: "HMAC",
		hash: "SHA-".concat(e)
	};
	return {
		kty: ["oct"],
		secret: !0,
		subtle: t,
		signing: t,
		usages: Sr
	};
}
function Pr(e, t) {
	const n = {
		name: t ? "RSA-PSS" : "RSASSA-PKCS1-v1_5",
		hash: "SHA-".concat(e)
	};
	return {
		kty: ["RSA"],
		subtle: n,
		signing: t ? f(f({}, n), {}, { saltLength: t }) : n,
		usages: Sr,
		minRsaBits: 2048
	};
}
function Cr(e, t) {
	return {
		kty: ["EC"],
		crv: e,
		subtle: {
			name: "ECDSA",
			namedCurve: e
		},
		signing: {
			name: "ECDSA",
			hash: "SHA-".concat(t)
		},
		usages: Sr
	};
}
function Er() {
	const e = { name: "Ed25519" };
	return {
		kty: ["OKP"],
		crv: "Ed25519",
		subtle: e,
		signing: e,
		usages: Sr
	};
}
function Rr(e) {
	const t = { name: "ML-DSA-".concat(e) };
	return {
		kty: ["AKP"],
		subtle: t,
		signing: t,
		usages: Sr
	};
}
var Ar = Ei({
	HS256: Tr(256),
	HS384: Tr(384),
	HS512: Tr(512),
	RS256: Pr(256),
	RS384: Pr(384),
	RS512: Pr(512),
	PS256: Pr(256, 32),
	PS384: Pr(384, 48),
	PS512: Pr(512, 64),
	ES256: Cr("P-256", 256),
	ES384: Cr("P-384", 384),
	ES512: Cr("P-521", 512),
	EdDSA: Er(),
	Ed25519: Er(),
	"ML-DSA-44": Rr(44),
	"ML-DSA-65": Rr(65),
	"ML-DSA-87": Rr(87)
});
function xr(e) {
	const t = "string" == typeof e ? Ar[e] : void 0;
	if (!t) throw new Yo("alg ".concat(e, " is not supported either by JOSE or your javascript runtime"));
	return t;
}
function Ir(e) {
	return void 0 === e ? {} : function(e, t, n) {
		let o;
		try {
			o = JSON.parse(Jo.decode(ii(e)));
		} catch (e) {
			throw new t(n, { cause: e });
		}
		if (!si(o)) throw new t(n);
		return o;
	}(e, Bo, "JWS Protected Header is invalid");
}
function Or(e) {
	try {
		return Zo(e);
	} catch (e) {
		throw new Bo("JWS Compact Serialization payload must use only ASCII characters", { cause: e });
	}
}
async function jr(e, t, n, o, i) {
	var r;
	const s = e.protected, a = e.header, c = e.payload, u = null != i ? i : Ir(s);
	if (!ci(u, a)) throw new Bo("JWS Protected and JWS Unprotected Header Parameter names must be disjoint");
	const l = f(f({}, u), a), d = pi(u, hi(Bo, li, t[1], u, l)), h = l.alg;
	if ("string" != typeof h || !h) throw new Bo("JWS \"alg\" (Algorithm) Header Parameter missing or invalid");
	if (t[0] && !t[0].has(h)) throw new qo("\"alg\" (Algorithm) Header Parameter value not allowed");
	if (d) {
		if ("string" != typeof c) throw new Bo("JWS Payload must be a string");
	} else if ("string" != typeof c && !(c instanceof Uint8Array)) throw new Bo("JWS Payload must be a string or an Uint8Array instance");
	const p = d || "string" != typeof c ? c : o(c);
	let m = !1;
	"function" == typeof n && (n = await n(u, e), m = !0);
	const y = xr(h), w = Do(void 0 !== s ? Zo(s) : /* @__PURE__ */ new Uint8Array(), Zo("."), "string" == typeof p ? null !== (r = t[2]) && void 0 !== r ? r : t[2] = function(e, t, n) {
		try {
			return Zo(e);
		} catch (e) {
			throw new n("The ".concat(t, " is not a valid base64url string"), { cause: e });
		}
	}(p, "payload", Bo) : p), g = ui(e.signature, "signature", Bo), v = await mi(y, n, "verify"), b = await Ci(v, y.subtle, "verify");
	y.minRsaBits && ki(y.alg, b);
	let _ = !1;
	try {
		_ = await crypto.subtle.verify(y.signing, b, g, w);
	} catch (e) {
		throw new oi(void 0, { cause: e });
	}
	if (!_) throw new oi();
	const k = { payload: "string" == typeof p ? ui(p, "payload", Bo) : p };
	return void 0 !== s && (k.protectedHeader = u), void 0 !== a && (k.unprotectedHeader = a), m ? [f(f({}, k), {}, { key: v }), d] : [k, d];
}
var Wr = (e) => Math.floor(e.getTime() / 1e3);
var Nr = {
	s: 1,
	m: 60,
	h: 3600,
	d: 86400,
	w: 604800,
	y: 31557600
};
var Mr = /^(\+|\-)? ?(\d+|\d+\.\d+) ?(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)(?: (ago|from now))?$/i;
var Ur = "check_failed";
function Lr() {
	throw new TypeError("Invalid time period format");
}
function Kr(e) {
	"string" != typeof e && Lr();
	const t = Mr.exec(e);
	(!t || t[4] && t[1]) && Lr();
	const n = parseFloat(t[2]), o = Math.round(n * Nr[t[3][0].toLowerCase()]);
	return Number.isFinite(o) || Lr(), "-" === t[1] || "ago" === t[4] ? -o : o;
}
function zr(e, t) {
	if (!Number.isFinite(t)) throw new TypeError("Invalid ".concat(e, " input"));
	return t;
}
function Jr(e, t) {
	if ("string" != typeof t) throw new TypeError("\"".concat(e, "\" claim must be a string"));
}
function Dr(e, t) {
	return "number" == typeof e ? zr(t, e) : e instanceof Date ? zr(t, Wr(e)) : Wr(/* @__PURE__ */ new Date()) + Kr(e);
}
var Hr = (e) => {
	const t = e.toLowerCase();
	return e.includes("/") ? t : "application/".concat(t);
};
function Zr(e, t) {
	let n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
	const o = e[t];
	if (void 0 !== o || n) {
		if ("number" != typeof o) throw new Xo("\"".concat(t, "\" claim must be a number"), e, t, "invalid");
		return o;
	}
}
function Fr(e, t) {
	throw new Xo("unexpected \"".concat(t, "\" claim value"), e, t, Ur);
}
function Vr(e, t) {
	let n, o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
	try {
		n = JSON.parse(Jo.decode(t));
	} catch (e) {
		throw new Qo("JWT Claims Set must be a top-level JSON object", { cause: e });
	}
	if (!si(n)) throw new Qo("JWT Claims Set must be a top-level JSON object");
	const i = o.typ;
	if (void 0 !== i && ("string" != typeof e.typ || Hr(e.typ) !== Hr(i))) throw new Xo("unexpected \"typ\" JWT header value", n, "typ", Ur);
	const r = o.requiredClaims, s = void 0 === r ? [] : r, a = o.issuer, c = o.subject, u = o.audience, l = o.maxTokenAge, d = [...s];
	void 0 !== l && d.push("iat"), void 0 !== u && d.push("aud"), void 0 !== c && d.push("sub"), void 0 !== a && d.push("iss");
	for (const e of new Set(d.reverse())) if (!Object.hasOwn(n, e)) throw new Xo("missing required \"".concat(e, "\" claim"), n, e, "missing");
	var h, p;
	void 0 !== a && !(Array.isArray(a) ? a : [a]).includes(n.iss) && Fr(n, "iss"), void 0 !== c && n.sub !== c && Fr(n, "sub"), void 0 !== u && (h = n.aud, p = "string" == typeof u ? [u] : u, !("string" == typeof h ? p.includes(h) : Array.isArray(h) && p.some((e) => h.includes(e)))) && Fr(n, "aud");
	const f = o.clockTolerance;
	let m = 0;
	if ("string" == typeof f) m = Kr(f);
	else if (void 0 !== f) {
		if ("number" != typeof f) throw new TypeError("Invalid clockTolerance option type");
		m = f;
	}
	zr("clockTolerance option", m);
	const y = o.currentDate, w = zr("currentDate option", Wr(void 0 === y ? /* @__PURE__ */ new Date() : y)), g = Zr(n, "iat", void 0 !== l), v = Zr(n, "nbf");
	if (void 0 !== v && v > w + m) throw new Xo("\"nbf\" claim timestamp check failed", n, "nbf", Ur);
	const b = Zr(n, "exp");
	if (void 0 !== b && b <= w - m) throw new Go("\"exp\" claim timestamp check failed", n, "exp", Ur);
	if (void 0 !== l) {
		const e = w - g;
		if (e - m > zr("maxTokenAge option", "number" == typeof l ? l : Kr(l))) throw new Go("\"iat\" claim timestamp check failed (too far in the past)", n, "iat", Ur);
		if (e < -m) throw new Xo("\"iat\" claim timestamp check failed (it should be in the past)", n, "iat", Ur);
	}
	return n;
}
var Xr;
function Gr(e) {
	return Xr.get(e);
}
async function qr(e, t, n) {
	const i = y(await async function(e, t, n) {
		if (e instanceof Uint8Array && (e = zo.decode(e)), "string" != typeof e) throw new Bo("Compact JWS must be a string or Uint8Array");
		const o = e.split("."), i = o[0], r = o[1], s = o[2];
		if (3 !== o.length) throw new Bo("Invalid Compact JWS");
		return jr({
			payload: r,
			protected: i,
			signature: s
		}, t, n, Or);
	}(e, function(e) {
		return [e && di("algorithms", e.algorithms), null == e ? void 0 : e.crit];
	}(n), t), 2), r = i[0];
	if (!i[1]) throw new Qo("JWTs MUST NOT use unencoded payload");
	const s = Vr(r.protectedHeader, r.payload, n);
	return f(f({}, r), {}, { payload: s });
}
async function Yr(e, t, n) {
	let o = y(e, 4), i = o[0], r = o[1], s = o[2], a = o[3], c = "";
	if (void 0 !== r) {
		const e = fi(Bo, r);
		r = e[0], c = ri(e[1]);
	}
	if (void 0 !== s && (s = fi(Bo, s)[0]), !r && !s) throw new Bo("either setProtectedHeader or setUnprotectedHeader must be called before #sign()");
	if (!ci(r, s)) throw new Bo("JWS Protected and JWS Unprotected Header Parameter names must be disjoint");
	const u = f(f({}, r), s);
	(function(e, t) {
		const n = (null != t ? t : {}).crit;
		if (Array.isArray(n) && new Set(n).size !== n.length) throw new e("\"crit\" (Critical) Header Parameter MUST NOT contain duplicate values");
	})(Bo, r);
	const l = pi(r, hi(Bo, li, a, r, u));
	l || null == n || n();
	const d = u.alg;
	if ("string" != typeof d || !d) throw new Bo("JWS \"alg\" (Algorithm) Header Parameter missing or invalid");
	const h = xr(d);
	let p, m = "", w = i;
	if (l) {
		var g, v;
		const t = e[4];
		t ? (m = null !== (g = t[0]) && void 0 !== g ? g : t[0] = ri(i), w = null !== (v = t[1]) && void 0 !== v ? v : t[1] = Zo(m)) : (m = ri(i), p = Ko.encode("".concat(c, ".").concat(m)));
	}
	p ??= Do(Zo(c), Zo("."), w);
	const b = await Ci(await mi(h, t, "sign"), h.subtle, "sign");
	h.minRsaBits && ki(h.alg, b);
	const _ = {
		signature: ri(new Uint8Array(await crypto.subtle.sign(h.signing, b, p))),
		payload: m
	};
	return r && (_.protected = c), s && (_.header = s), [_, l];
}
var Br = class {
	constructor() {
		let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
		if (!si(e)) throw new TypeError("JWT Claims Set MUST be an object");
		(Xr || (Xr = /* @__PURE__ */ new WeakMap())).set(this, structuredClone(e));
	}
	setIssuer(e) {
		return Jr("iss", e), Gr(this).iss = e, this;
	}
	setSubject(e) {
		return Jr("sub", e), Gr(this).sub = e, this;
	}
	setAudience(e) {
		return function(e) {
			if ("string" != typeof e && (!Array.isArray(e) || Array.from(e).some((e) => "string" != typeof e))) throw new TypeError("\"aud\" claim must be a string or an array of strings");
		}(e), Gr(this).aud = e, this;
	}
	setJti(e) {
		return Jr("jti", e), Gr(this).jti = e, this;
	}
	setNotBefore(e) {
		return Gr(this).nbf = Dr(e, "setNotBefore"), this;
	}
	setExpirationTime(e) {
		return Gr(this).exp = Dr(e, "setExpirationTime"), this;
	}
	setIssuedAt(e) {
		const t = Gr(this);
		return t.iat = void 0 === e ? Wr(/* @__PURE__ */ new Date()) : "string" == typeof e ? zr("setIssuedAt", Wr(/* @__PURE__ */ new Date()) + Kr(e)) : Dr(e, "setIssuedAt"), this;
	}
};
var Qr = /* @__PURE__ */ new WeakMap();
var $r = class extends Br {
	constructor() {
		super(...arguments), u(this, Qr, void 0);
	}
	setProtectedHeader(e) {
		return function(e, t) {
			if (void 0 !== e) throw new TypeError("".concat(t, " can only be called once"));
		}(c(Qr, this), "setProtectedHeader"), l(Qr, this, e), this;
	}
	async sign(e, t) {
		return async function(e, t, n, o, i) {
			const r = y(await Yr([
				e,
				t,
				void 0,
				n
			], o, i), 1)[0];
			return "".concat(r.protected, ".").concat(r.payload, ".").concat(r.signature);
		}(function(e) {
			const t = Gr(e);
			for (const e of [
				"iat",
				"nbf",
				"exp"
			]) {
				const n = t[e];
				if ("number" == typeof n && !Number.isFinite(n)) throw new TypeError("\"".concat(e, "\" claim must be a finite number"));
			}
			return Ko.encode(JSON.stringify(t));
		}(this), c(Qr, this), null == t ? void 0 : t.crit, e, () => {
			throw new Qo("JWTs MUST NOT use unencoded payload");
		});
	}
};
var es = "\"alg\" (Algorithm)";
function ts() {
	throw new Yo("Invalid or unsupported ".concat(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "JWK \"alg\" (Algorithm) Parameter", " value"));
}
var ns = (e, t) => {
	if (e.byteLength !== t.length) return !1;
	for (let n = 0; n < e.byteLength; n++) if (e[n] !== t[n]) return !1;
	return !0;
};
var os = (e) => {
	const t = e.data[e.pos++];
	if (void 0 === t) throw new Error("Unexpected end of ASN.1 input");
	return t;
};
var is = (e) => {
	const t = os(e);
	if (128 & t) {
		const n = 127 & t;
		let o = 0;
		for (let t = 0; t < n; t++) o = o << 8 | os(e);
		return o;
	}
	return t;
};
var rs = (e, t, n) => {
	if (os(e) !== t) throw new Error(n);
};
var ss = (e, t) => {
	if (t < 0 || e.pos + t > e.data.length) throw new Error("Unexpected end of ASN.1 input");
	const n = e.data.subarray(e.pos, e.pos + t);
	return e.pos += t, n;
};
var as = (e) => {
	const t = ((e) => {
		rs(e, 6, "Expected algorithm OID");
		return ss(e, is(e));
	})(e);
	if (ns(t, [
		43,
		101,
		110
	])) return "X25519";
	if (!ns(t, [
		42,
		134,
		72,
		206,
		61,
		2,
		1
	])) throw new Error("Unsupported key algorithm");
	rs(e, 6, "Expected curve OID");
	const o = ss(e, is(e));
	if (ns(o, [
		42,
		134,
		72,
		206,
		61,
		3,
		1,
		7
	])) return "P-256";
	if (ns(o, [
		43,
		129,
		4,
		0,
		34
	])) return "P-384";
	if (ns(o, [
		43,
		129,
		4,
		0,
		35
	])) return "P-521";
	throw new Error("Unsupported named curve");
};
var cs = async (e, t, n, o) => {
	const i = function(e) {
		if (void 0 !== e && "boolean" != typeof e) throw new TypeError("\"extractable\" option must be a boolean");
		return e;
	}(null == o ? void 0 : o.extractable), r = function(e, t) {
		var n, o;
		return null !== (n = "string" == typeof e ? null !== (o = Ar[e]) && void 0 !== o ? o : Ni[e] : void 0) && void 0 !== n ? n : ts(t);
	}(n, es);
	r.secret && ts(es);
	const s = "spki" === e;
	let a;
	if (r.resolve) try {
		const n = {
			data: t,
			pos: 0
		};
		(function(e, t) {
			if (rs(e, 48, "Invalid ".concat("spki" === t ? "SPKI" : "PKCS#8", " structure")), is(e), "pkcs8" === t) {
				rs(e, 2, "Expected version field");
				const t = is(e);
				e.pos += t;
			}
			rs(e, 48, "Expected algorithm identifier"), is(e);
		})(n, e), a = r.resolve({ crv: as(n) });
	} catch (e) {
		throw new Yo("Invalid or unsupported key format", { cause: e });
	}
	else a = r.subtle;
	return crypto.subtle.importKey(e, t, a, null != i ? i : s, r.usages[s ? 0 : 1]);
};
var us = (e, t, n) => {
	return cs("pkcs8", ((e, t) => Fo(e.replace(t, "")))(e, /(?:-----(?:BEGIN|END) PRIVATE KEY-----|\s)/g), t, n);
};
async function ls(e, t, n) {
	const o = e.get(t) || e.set(t, {}).get(t), i = n.alg;
	if (void 0 === o[i]) {
		const e = Pi(n, t, !0).then((e) => {
			if ("public" !== e.type) throw new $o("JSON Web Key Set members must be public keys");
			return o[i] = e, e;
		}).catch((t) => {
			throw o[i] === e && delete o[i], t;
		});
		o[i] = e;
	}
	return o[i];
}
function ds(e) {
	let t;
	try {
		t = structuredClone(e);
	} catch (e) {
		throw new $o("JSON Web Key Set malformed", { cause: e });
	}
	if (!ai(t)) throw new $o("JSON Web Key Set malformed");
	const n = t.keys.map((e) => {
		const t = Ti(e);
		return Array.isArray(t.key_ops) && (t.key_ops = [...t.key_ops]), t;
	}), o = /* @__PURE__ */ new WeakMap();
	return Object.defineProperty(async (e, i) => {
		const r = f(f({}, e), null == i ? void 0 : i.header), a = r.alg, c = r.kid, u = "string" == typeof a ? Ar[a] : void 0;
		if (!u || u.secret) throw new Yo("Unsupported \"alg\" value for a JSON Web Key Set");
		const l = t.keys.filter((e, t) => function(e, t, n, o) {
			const i = e.kty, r = e.key_ops, s = e.ext, a = e.kid, c = e.alg, u = e.use, l = e.crv;
			return (void 0 === s || "boolean" == typeof s) && (void 0 === r || Array.isArray(r) && r.every((e, t) => "string" == typeof e && r.indexOf(e) === t) && r.includes("verify")) && t.kty.includes(i) && (void 0 === o || "string" == typeof o && o === a) && (void 0 === c ? "AKP" !== i : n === c) && (void 0 === u || "sig" === u) && (!t.crv || l === t.crv);
		}(n[t], u, a, c)), d = l[0], h = l.length;
		if (!h) throw new ei();
		if (1 !== h) {
			const e = new ti();
			throw e[Symbol.asyncIterator] = w(function* () {
				for (const e of l) try {
					yield yield s(ls(o, e, u));
				} catch (e) {}
			}), e;
		}
		return ls(o, d, u);
	}, "jwks", { value: () => structuredClone(t) });
}
var hs;
var ps;
var fs;
(typeof navigator > "u" || null === (hs = navigator.userAgent) || void 0 === hs || null === (ps = hs.startsWith) || void 0 === ps || !ps.call(hs, "Mozilla/5.0 ")) && (fs = "jose/v6.2.13");
var ms = Symbol();
var ys = Symbol();
function ws(e, t) {
	return Number.isFinite(e) && Date.now() < e + t;
}
function gs(e, t, n) {
	if (Number.isNaN(e)) throw new TypeError("\"".concat(n, "\" option must not be NaN"));
	return "number" == typeof e ? e : t;
}
function vs(e, t) {
	if (!(e instanceof URL)) throw new TypeError("url must be an instance of URL");
	const n = new URL(e.href).href, o = null != t ? t : {}, i = o.timeoutDuration;
	if ("number" == typeof i && (!Number.isInteger(i) || i < 0)) throw new TypeError("\"timeoutDuration\" option must be a non-negative integer");
	const r = "number" == typeof i ? i : 5e3, s = gs(o.cooldownDuration, 3e4, "cooldownDuration"), a = gs(o.cacheMaxAge, 6e5, "cacheMaxAge"), c = new Headers(o.headers);
	fs && !c.has("User-Agent") && c.set("User-Agent", fs), c.has("accept") || c.set("accept", "application/json, application/jwk-set+json");
	const u = o[ms], l = o[ys];
	let d, h, p, f = 0, m = 0;
	if (l && "object" == typeof l) {
		const e = l.uat, t = l.jwks;
		ws(e, a) && ai(t) && (d = e, p = ds(t));
	}
	const y = async () => {
		if (h && (typeof WebSocketPair < "u" || typeof navigator < "u" && "Cloudflare-Workers" === navigator.userAgent || typeof EdgeRuntime < "u" && "vercel" === EdgeRuntime) && (h = void 0), !h) {
			const e = ++f, t = h = async function(e, t, n) {
				const i = await (arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : fetch)(e, {
					method: "GET",
					signal: n,
					redirect: "manual",
					headers: t
				}).catch((e) => {
					throw "TimeoutError" === e.name ? new ni(void 0, { cause: e }) : e;
				});
				if (200 !== i.status) throw new Vo("Expected 200 OK from the JSON Web Key Set HTTP response");
				try {
					return await i.json();
				} catch (e) {
					throw new Vo("Failed to parse the JSON Web Key Set HTTP response as JSON", { cause: e });
				}
			}(n, c, AbortSignal.timeout(r), u).then((t) => {
				const n = ds(t);
				if (e <= m) return;
				p = n;
				const o = Date.now();
				l && (l.uat = o, l.jwks = t), d = o, m = e;
			}).finally(() => {
				h === t && (h = void 0);
			});
		}
		await h;
	};
	return Object.defineProperties(async (e, t) => {
		(!p || !ws(d, a)) && await y();
		try {
			return await p(e, t);
		} catch (n) {
			if (n instanceof ei && !ws(d, s)) return await y(), p(e, t);
			throw n;
		}
	}, {
		coolingDown: {
			get: () => ws(d, s),
			enumerable: !0
		},
		fresh: {
			get: () => ws(d, a),
			enumerable: !0
		},
		reload: {
			value: y,
			enumerable: !0
		},
		reloading: {
			get: () => !!h,
			enumerable: !0
		},
		jwks: {
			value: () => {
				var e;
				return null === (e = p) || void 0 === e ? void 0 : e.jwks();
			},
			enumerable: !0
		}
	});
}
async function bs(e, t, n) {
	if ("string" != typeof e || 0 !== e.indexOf("-----BEGIN PRIVATE KEY-----")) throw new TypeError("\"pkcs8\" must be PKCS#8 formatted string");
	return us(e, t, n);
}
var _s = ["mfaToken"];
var ks = ["mfaToken"];
var Ss;
var Ts;
var Ps;
var Cs;
var Es;
var Rs;
var As;
var xs;
var Is;
var Os;
var js;
var Ws;
var Ns;
var Ms;
var Us;
var Ls;
var Ks;
var zs;
var Js;
var Ds;
var Hs;
var Zs;
var Fs;
var Vs;
var Xs;
var Gs;
var qs;
var Ys;
var Bs;
var Qs;
var $s;
var ea;
var ta;
var na;
var oa;
var ia;
var ra;
var sa;
var aa;
var ca;
var ua;
var la;
var da;
var ha;
var pa;
var fa;
var ma;
var ya;
var wa;
var ga;
var va;
var ba;
function _a(e) {
	if ("object" != typeof e || null === e) return {};
	const t = e;
	return {
		statusCode: "number" == typeof t.statusCode ? t.statusCode : void 0,
		headers: t.headers instanceof Headers ? t.headers : void 0,
		body: "string" == typeof t.body ? t.body : void 0
	};
}
function ka(e) {
	var t, n;
	if ("object" != typeof e || null === e) return {
		error: "unknown_error",
		error_description: String(e)
	};
	const o = e;
	let i;
	if (o.response instanceof Response) try {
		i = new Headers(o.response.headers), i.delete("set-cookie");
	} catch (e) {
		i = void 0;
	}
	const r = {
		error: null !== (t = o.error) && void 0 !== t ? t : "",
		error_description: null !== (n = o.error_description) && void 0 !== n ? n : "",
		message: o.message,
		statusCode: "number" == typeof o.status ? o.status : void 0,
		headers: i
	};
	if ("mfa_required" === o.error && o.cause) {
		r.mfa_token = "string" == typeof o.cause.mfa_token ? o.cause.mfa_token : void 0;
		const e = o.cause.mfa_requirements;
		"object" == typeof e && null !== e && (r.mfa_requirements = e);
	}
	return r;
}
var Sa = class extends Error {
	constructor(e, t) {
		super(t), h(this, "code", void 0), this.name = "NotSupportedError", this.code = e;
	}
};
var Ta = class extends Error {
	constructor(e, t, n) {
		super(t), h(this, "cause", void 0), h(this, "code", void 0), h(this, "statusCode", void 0), h(this, "headers", void 0), h(this, "body", void 0), this.code = e, this.cause = n && {
			error: n.error,
			error_description: n.error_description,
			message: n.message,
			mfa_token: n.mfa_token,
			mfa_requirements: n.mfa_requirements
		};
		const o = _a(n);
		this.statusCode = o.statusCode, this.headers = o.headers, this.body = o.body;
	}
};
var Pa = class extends Ta {
	constructor(e, t) {
		super("token_by_code_error", e, t), this.name = "TokenByCodeError";
	}
};
var Ca = class extends Ta {
	constructor(e, t) {
		super("token_by_client_credentials_error", e, t), this.name = "TokenByClientCredentialsError";
	}
};
var Ea = class extends Ta {
	constructor(e, t) {
		super("token_by_refresh_token_error", e, t), this.name = "TokenByRefreshTokenError";
	}
};
var Ra = class extends Ta {
	constructor(e, t) {
		super("token_by_password_error", e, t), this.name = "TokenByPasswordError";
	}
};
var Aa = class extends Ta {
	constructor(e, t) {
		super("token_for_connection_error", e, t), this.name = "TokenForConnectionErrorCode";
	}
};
var xa = class extends Ta {
	constructor(e, t) {
		super("token_exchange_error", e, t), this.name = "TokenExchangeError";
	}
};
var Ia = class extends Ta {
	constructor(e, t) {
		super("token_revocation_error", e, t), this.name = "TokenRevocationError";
	}
};
var Oa = class extends Ta {
	constructor(e, t) {
		super("user_info_error", e, t), this.name = "UserInfoError";
	}
};
var ja = class extends Error {
	constructor(e) {
		super(e), h(this, "code", "verify_logout_token_error"), this.name = "VerifyLogoutTokenError";
	}
};
var Wa = class extends Ta {
	constructor(e) {
		super("backchannel_authentication_error", "There was an error when trying to use Client-Initiated Backchannel Authentication.", e), h(this, "code", "backchannel_authentication_error"), this.name = "BackchannelAuthenticationError";
	}
};
var Na = class extends Ta {
	constructor(e) {
		super("build_authorization_url_error", "There was an error when trying to build the authorization URL.", e), this.name = "BuildAuthorizationUrlError";
	}
};
var Ma = class extends Ta {
	constructor(e) {
		super("build_link_user_url_error", "There was an error when trying to build the Link User URL.", e), this.name = "BuildLinkUserUrlError";
	}
};
var Ua = class extends Ta {
	constructor(e) {
		super("build_unlink_user_url_error", "There was an error when trying to build the Unlink User URL.", e), this.name = "BuildUnlinkUserUrlError";
	}
};
var La = class extends Error {
	constructor() {
		super("The client secret or client assertion signing key must be provided."), h(this, "code", "missing_client_auth_error"), this.name = "MissingClientAuthError";
	}
};
var Ka = class extends Error {
	constructor(e) {
		super(e), h(this, "code", "organization_validation_error"), this.name = "OrganizationValidationError";
	}
};
var za = class extends Error {
	constructor(e) {
		super(e || "fullResponse: true requested but no HTTP Response was captured. This is a bug in CapturingFetch."), h(this, "code", "missing_captured_response_error"), this.name = "MissingCapturedResponseError";
	}
};
var Ja = class extends Error {
	constructor(e) {
		super(e || "The scope option must be a non-empty string of space-separated scopes. Omit it to request the default grant."), h(this, "code", "invalid_scope_error"), this.name = "InvalidScopeError";
	}
};
function Da(e) {
	try {
		const t = new Headers(e);
		return t.delete("set-cookie"), t;
	} catch (e) {
		return new Headers();
	}
}
function Ha(e, t, n) {
	var o;
	const i = "object" == typeof t && null !== t ? t : void 0, r = null !== (o = null == i ? void 0 : i.response) && void 0 !== o ? o : n, s = "number" == typeof (null == i ? void 0 : i.status) ? i.status : null == r ? void 0 : r.status;
	"number" == typeof s && (e.statusCode = s), null != r && r.headers && (e.headers = Da(r.headers));
}
function Za(e) {
	return Object.entries(e).filter((e) => void 0 !== y(e, 2)[1]).reduce((e, t) => f(f({}, e), {}, { [t[0]]: t[1] }), {});
}
function Fa(e) {
	if (!e.trim()) throw new Ka("organization must not be blank");
}
function Va(e, t) {
	if (!e) return;
	const n = t.trim();
	if (n.startsWith("org_")) {
		const t = e.org_id;
		if ("string" != typeof t) throw new Ka("Organization Id (org_id) claim must be a string present in the ID token");
		if (t !== n) throw new Ka("Organization Id (org_id) claim value mismatch in the ID token; expected \"".concat(n, "\", found \"").concat(t, "\""));
	} else {
		const t = e.org_name;
		if ("string" != typeof t) throw new Ka("Organization Name (org_name) claim must be a string present in the ID token");
		if (t.toLowerCase() !== n.toLowerCase()) throw new Ka("Organization Name (org_name) claim value mismatch in the ID token; expected \"".concat(n, "\", found \"").concat(t, "\""));
	}
}
var Xa = class extends Error {
	constructor(e, t, n) {
		super(t), h(this, "cause", void 0), h(this, "code", void 0), h(this, "statusCode", void 0), h(this, "headers", void 0), h(this, "body", void 0), this.code = e, this.cause = n && {
			error: n.error,
			error_description: n.error_description,
			message: n.message
		};
		const o = _a(n);
		this.statusCode = o.statusCode, this.headers = o.headers, this.body = o.body;
	}
};
var Ga = class extends Xa {
	constructor(e, t) {
		super("mfa_list_authenticators_error", e, t), this.name = "MfaListAuthenticatorsError";
	}
};
var qa = class extends Xa {
	constructor(e, t) {
		super("mfa_enrollment_error", e, t), this.name = "MfaEnrollmentError";
	}
};
var Ya = class extends Xa {
	constructor(e, t) {
		super("mfa_delete_authenticator_error", e, t), this.name = "MfaDeleteAuthenticatorError";
	}
};
var Ba = class extends Xa {
	constructor(e, t) {
		super("mfa_challenge_error", e, t), this.name = "MfaChallengeError";
	}
};
var Qa = class extends Xa {
	constructor(e, t) {
		super("mfa_verify_error", e, t), this.name = "MfaVerifyError";
	}
};
function $a(e) {
	return {
		id: e.id,
		authenticatorType: e.authenticator_type,
		active: e.active,
		name: e.name,
		oobChannels: e.oob_channels,
		type: e.type
	};
}
var ec = class e {
	constructor(e, t, n, o, i, r, s) {
		h(this, "accessToken", void 0), h(this, "idToken", void 0), h(this, "refreshToken", void 0), h(this, "expiresAt", void 0), h(this, "scope", void 0), h(this, "claims", void 0), h(this, "authorizationDetails", void 0), h(this, "tokenType", void 0), h(this, "issuedTokenType", void 0), h(this, "recoveryCode", void 0), h(this, "act", void 0), this.accessToken = e, this.idToken = n, this.refreshToken = o, this.expiresAt = t, this.scope = i, this.claims = r, this.authorizationDetails = s;
	}
	static fromTokenEndpointResponse(t) {
		const n = t.id_token ? t.claims() : void 0, o = new e(t.access_token, Math.floor(Date.now() / 1e3) + Number(t.expires_in), t.id_token, t.refresh_token, t.scope, n, t.authorization_details);
		return o.tokenType = t.token_type, o.issuedTokenType = t.issued_token_type, o;
	}
};
function tc(e, t) {
	if (!1 === t.enabled) return e;
	const n = {
		name: t.name,
		version: t.version
	}, o = btoa(JSON.stringify(n));
	return async (t, n) => {
		const i = t instanceof Request ? new Headers(t.headers) : new Headers();
		if (null != n && n.headers) new Headers(n.headers).forEach((e, t) => {
			i.set(t, e);
		});
		return i.set("Auth0-Client", o), e(t, f(f({}, n), {}, { headers: i }));
	};
}
function nc(e) {
	var t, n;
	return !1 === (null == e ? void 0 : e.enabled) ? e : {
		enabled: !0,
		name: null !== (t = null == e ? void 0 : e.name) && void 0 !== t ? t : "@auth0/auth0-auth-js",
		version: null !== (n = null == e ? void 0 : e.version) && void 0 !== n ? n : "1.18.0"
	};
}
function oc(e) {
	let t;
	const n = async (n, o) => {
		const i = await e(n, o);
		return t = i.clone(), i;
	};
	return n.getCapturedResponse = () => t, n;
}
function ic(e, t, n) {
	if (!t) return e;
	const o = t.signal, i = t.headers, r = t.customFetch, s = r ? tc(r, n) : e;
	return o || i ? async (e, t) => {
		const n = i ? new Headers(e instanceof Request ? e.headers : void 0) : void 0;
		if (n && null != t && t.headers && new Headers(t.headers).forEach((e, t) => n.set(t, e)), i) for (const e of Object.entries(i)) {
			var r = y(e, 2);
			const t = r[0], o = r[1], i = t.toLowerCase();
			"authorization" !== i && "auth0-client" !== i && n.set(t, o);
		}
		const a = function(e, t) {
			if (!e) return { signal: null != t ? t : void 0 };
			if (!t) return { signal: e };
			if ("undefined" != typeof AbortSignal && "function" == typeof AbortSignal.any) return { signal: AbortSignal.any([e, t]) };
			const n = new AbortController(), o = [e, t], i = o.find((e) => e.aborted);
			if (i) return n.abort(i.reason), { signal: n.signal };
			const r = [], s = () => {
				o.forEach((e, t) => {
					const n = r[t];
					n && e.removeEventListener("abort", n);
				});
			};
			return o.forEach((e, t) => {
				const o = () => {
					s(), n.abort(e.reason);
				};
				r[t] = o, e.addEventListener("abort", o, { once: !0 });
			}), {
				signal: n.signal,
				cleanup: s
			};
		}(o, null == t ? void 0 : t.signal);
		try {
			return await s(e, f(f(f({}, t), n && { headers: n }), {}, { signal: a.signal }));
		} finally {
			var c;
			null === (c = a.cleanup) || void 0 === c || c.call(a);
		}
	} : s;
}
var rc = {
	otp: "http://auth0.com/oauth/grant-type/mfa-otp",
	oob: "http://auth0.com/oauth/grant-type/mfa-oob",
	"recovery-code": "http://auth0.com/oauth/grant-type/mfa-recovery-code"
};
var sc = (Ss = /* @__PURE__ */ new WeakMap(), Ts = /* @__PURE__ */ new WeakMap(), Ps = /* @__PURE__ */ new WeakMap(), Cs = /* @__PURE__ */ new WeakMap(), Es = /* @__PURE__ */ new WeakMap(), Rs = /* @__PURE__ */ new WeakMap(), As = /* @__PURE__ */ new WeakMap(), xs = /* @__PURE__ */ new WeakSet(), class {
	constructor(e) {
		var t, n;
		d(this, xs), u(this, Ss, void 0), u(this, Ts, void 0), u(this, Ps, void 0), u(this, Cs, void 0), u(this, Es, void 0), u(this, Rs, void 0), u(this, As, void 0), l(Ss, this, "https://".concat(e.domain)), l(Ts, this, e.clientId), l(Ps, this, e.clientSecret), l(Cs, this, null !== (t = e.customFetch) && void 0 !== t ? t : function() {
			return fetch(...arguments);
		}), l(Es, this, null !== (n = e.telemetryConfig) && void 0 !== n ? n : nc()), l(Rs, this, e.getConfiguration), l(As, this, e.createCaptureConfiguration);
	}
	async listAuthenticators(e, t) {
		const n = "".concat(c(Ss, this), "/mfa/authenticators"), o = e.mfaToken, i = await r(xs, this, ac).call(this, t)(n, {
			method: "GET",
			headers: {
				Authorization: "Bearer ".concat(o),
				"Content-Type": "application/json"
			}
		});
		if (!i.ok) {
			const e = await i.clone().text(), t = i.status, n = Da(i.headers);
			let o;
			try {
				o = JSON.parse(e);
			} catch (o) {
				throw new Ga("Failed to list authenticators", {
					error: "unknown_error",
					error_description: "Failed to list authenticators",
					statusCode: t,
					headers: n,
					body: e
				});
			}
			throw new Ga(o.error_description || "Failed to list authenticators", f(f({}, o), {}, {
				statusCode: t,
				headers: n,
				body: e
			}));
		}
		return (await i.json()).map($a);
	}
	async enrollAuthenticator(e, t) {
		const n = "".concat(c(Ss, this), "/mfa/associate"), o = e.mfaToken, i = m(e, _s), s = { authenticator_types: i.authenticatorTypes };
		"oobChannels" in i && (s.oob_channels = i.oobChannels), "phoneNumber" in i && i.phoneNumber && (s.phone_number = i.phoneNumber), "email" in i && i.email && (s.email = i.email);
		const a = await r(xs, this, ac).call(this, t)(n, {
			method: "POST",
			headers: {
				Authorization: "Bearer ".concat(o),
				"Content-Type": "application/json"
			},
			body: JSON.stringify(s)
		});
		if (!a.ok) {
			const e = await a.clone().text(), t = a.status, n = Da(a.headers);
			let o;
			try {
				o = JSON.parse(e);
			} catch (o) {
				throw new qa("Failed to enroll authenticator", {
					error: "unknown_error",
					error_description: "Failed to enroll authenticator",
					statusCode: t,
					headers: n,
					body: e
				});
			}
			throw new qa(o.error_description || "Failed to enroll authenticator", f(f({}, o), {}, {
				statusCode: t,
				headers: n,
				body: e
			}));
		}
		return function(e) {
			if ("otp" === e.authenticator_type) return {
				authenticatorType: "otp",
				secret: e.secret,
				barcodeUri: e.barcode_uri,
				recoveryCodes: e.recovery_codes,
				id: e.id
			};
			if ("oob" === e.authenticator_type) return {
				authenticatorType: "oob",
				oobChannel: e.oob_channel,
				oobCode: e.oob_code,
				bindingMethod: e.binding_method,
				id: e.id,
				barcodeUri: e.barcode_uri,
				recoveryCodes: e.recovery_codes
			};
			throw new Error("Unexpected authenticator type: ".concat(e.authenticator_type));
		}(await a.json());
	}
	async deleteAuthenticator(e, t) {
		const n = e.authenticatorId, o = e.mfaToken, i = "".concat(c(Ss, this), "/mfa/authenticators/").concat(encodeURIComponent(n)), s = await r(xs, this, ac).call(this, t)(i, {
			method: "DELETE",
			headers: {
				Authorization: "Bearer ".concat(o),
				"Content-Type": "application/json"
			}
		});
		if (!s.ok) {
			const e = await s.clone().text(), t = s.status, n = Da(s.headers);
			let o;
			try {
				o = JSON.parse(e);
			} catch (o) {
				throw new Ya("Failed to delete authenticator", {
					error: "unknown_error",
					error_description: "Failed to delete authenticator",
					statusCode: t,
					headers: n,
					body: e
				});
			}
			throw new Ya(o.error_description || "Failed to delete authenticator", f(f({}, o), {}, {
				statusCode: t,
				headers: n,
				body: e
			}));
		}
	}
	async challengeAuthenticator(e, t) {
		const n = "".concat(c(Ss, this), "/mfa/challenge"), o = e.mfaToken, i = m(e, ks), s = {
			mfa_token: o,
			client_id: c(Ts, this),
			challenge_type: i.challengeType
		};
		c(Ps, this) && (s.client_secret = c(Ps, this)), i.authenticatorId && (s.authenticator_id = i.authenticatorId);
		const a = await r(xs, this, ac).call(this, t)(n, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(s)
		});
		if (!a.ok) {
			const e = await a.clone().text(), t = a.status, n = Da(a.headers);
			let o;
			try {
				o = JSON.parse(e);
			} catch (o) {
				throw new Ba("Failed to challenge authenticator", {
					error: "unknown_error",
					error_description: "Failed to challenge authenticator",
					statusCode: t,
					headers: n,
					body: e
				});
			}
			throw new Ba(o.error_description || "Failed to challenge authenticator", f(f({}, o), {}, {
				statusCode: t,
				headers: n,
				body: e
			}));
		}
		return function(e) {
			const t = { challengeType: e.challenge_type };
			return void 0 !== e.oob_code && (t.oobCode = e.oob_code), void 0 !== e.binding_method && (t.bindingMethod = e.binding_method), t;
		}(await a.json());
	}
	async verify(e, t) {
		if (!c(Rs, this)) throw new Error("MFA verify requires a configuration provider (getConfiguration was not set)");
		const n = { mfa_token: e.mfaToken };
		if (e.audience && (n.audience = e.audience), "otp" === e.factorType ? n.otp = e.otp : "oob" === e.factorType ? (n.oob_code = e.oobCode, e.bindingCode && (n.binding_code = e.bindingCode)) : "recovery-code" === e.factorType && (n.recovery_code = e.recoveryCode), e.fullResponse) {
			var o;
			if (!c(As, this)) throw new Error("MFA verify fullResponse requires a capture-config factory (createCaptureConfiguration was not set)");
			const a = oc(null !== (o = (await c(Rs, this).call(this, t))[Xi]) && void 0 !== o ? o : fetch), u = await c(As, this).call(this, a);
			try {
				const t = await _r(u, rc[e.factorType], n), o = ec.fromTokenEndpointResponse(t);
				t.recovery_code && (o.recoveryCode = t.recovery_code);
				const i = a.getCapturedResponse();
				if (!i) throw new za();
				return {
					data: o,
					response: i
				};
			} catch (e) {
				var i, r, s;
				if (e instanceof za) throw e;
				if (e instanceof Qa) throw e;
				const t = e, n = new Qa(t.error_description || t.message || "Failed to verify MFA challenge", {
					error: null !== (i = t.error) && void 0 !== i ? i : "mfa_verify_error",
					error_description: null !== (r = null !== (s = t.error_description) && void 0 !== s ? s : t.message) && void 0 !== r ? r : "Failed to verify MFA challenge"
				});
				throw Ha(n, e, a.getCapturedResponse()), n;
			}
		}
		const a = await c(Rs, this).call(this, t);
		try {
			const t = await _r(a, rc[e.factorType], n), o = ec.fromTokenEndpointResponse(t);
			return t.recovery_code && (o.recoveryCode = t.recovery_code), o;
		} catch (e) {
			var u, l, d;
			if (e instanceof Qa) throw e;
			const t = e, n = new Qa(t.error_description || t.message || "Failed to verify MFA challenge", {
				error: null !== (u = t.error) && void 0 !== u ? u : "mfa_verify_error",
				error_description: null !== (l = null !== (d = t.error_description) && void 0 !== d ? d : t.message) && void 0 !== l ? l : "Failed to verify MFA challenge"
			});
			throw Ha(n, e), n;
		}
	}
});
function ac(e) {
	return ic(c(Cs, this), e, c(Es, this));
}
var cc = class extends Error {
	constructor(e, t, n) {
		super(t), h(this, "cause", void 0), h(this, "code", void 0), h(this, "statusCode", void 0), h(this, "headers", void 0), h(this, "body", void 0), this.code = e, this.cause = n && {
			error: n.error,
			error_description: n.error_description,
			message: n.message
		};
		const o = _a(n);
		this.statusCode = o.statusCode, this.headers = o.headers, this.body = o.body;
	}
};
var uc = class extends cc {
	constructor(e, t) {
		super("passkey_register_error", e, t), this.name = "PasskeyRegisterError";
	}
};
var lc = class extends cc {
	constructor(e, t) {
		super("passkey_challenge_error", e, t), this.name = "PasskeyChallengeError";
	}
};
var dc = class extends cc {
	constructor(e, t) {
		super("passkey_get_token_error", e, t), h(this, "isRetryable", void 0), h(this, "verificationRequired", void 0), h(this, "authSession", void 0), this.name = "PasskeyGetTokenError", this.cause = t && {
			error: t.error,
			error_description: t.error_description,
			message: t.message,
			mfa_token: t.mfa_token,
			mfa_requirements: t.mfa_requirements,
			verification_required: t.verification_required,
			auth_session: t.auth_session
		}, this.isRetryable = "invalid_grant" === (null == t ? void 0 : t.error) && null != (null == t ? void 0 : t.auth_session), this.verificationRequired = null == t ? void 0 : t.verification_required, this.authSession = null == t ? void 0 : t.auth_session;
	}
};
function hc(e) {
	return e.useMtls ? {} : e.clientSecret ? { client_secret: e.clientSecret } : {};
}
var pc = "urn:okta:params:oauth:grant-type:webauthn";
var fc = (Is = /* @__PURE__ */ new WeakMap(), Os = /* @__PURE__ */ new WeakMap(), js = /* @__PURE__ */ new WeakMap(), Ws = /* @__PURE__ */ new WeakMap(), Ns = /* @__PURE__ */ new WeakMap(), Ms = /* @__PURE__ */ new WeakMap(), Us = /* @__PURE__ */ new WeakSet(), class {
	constructor(e) {
		var t, n;
		d(this, Us), u(this, Is, void 0), u(this, Os, void 0), u(this, js, void 0), u(this, Ws, void 0), u(this, Ns, void 0), u(this, Ms, void 0), l(Is, this, "https://".concat(e.domain)), l(Os, this, e.clientId), l(js, this, {
			clientSecret: e.clientSecret,
			useMtls: e.useMtls
		}), l(Ws, this, null !== (t = e.customFetch) && void 0 !== t ? t : function() {
			return fetch(...arguments);
		}), l(Ns, this, null !== (n = e.telemetryConfig) && void 0 !== n ? n : nc()), l(Ms, this, e.grantRequest);
	}
	async register(e, t) {
		const n = "".concat(c(Is, this), "/passkey/register"), o = f(f(f(f(f(f(f(f({}, e.email && { email: e.email }), e.name && { name: e.name }), e.phoneNumber && { phone_number: e.phoneNumber }), e.username && { username: e.username }), e.givenName && { given_name: e.givenName }), e.familyName && { family_name: e.familyName }), e.nickname && { nickname: e.nickname }), e.picture && { picture: e.picture }), i = f(f({ client_id: c(Os, this) }, hc(c(js, this))), {}, { user_profile: o });
		e.realm && (i.realm = e.realm), e.organization && (i.organization = e.organization), e.userMetadata && (i.user_metadata = e.userMetadata), e.deliveryMethod && (i.delivery_method = e.deliveryMethod);
		const s = await r(Us, this, mc).call(this, t)(n, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(i)
		});
		if (!s.ok) {
			const e = await r(Us, this, yc).call(this, s), t = new uc(e.error_description || "Failed to request signup challenge", e);
			throw t.statusCode = s.status, t.headers = Da(s.headers), t;
		}
		return f({
			authSession: (u = await s.json()).auth_session,
			authnParamsPublicKey: f({}, u.authn_params_public_key)
		}, u.verification_required && { verificationRequired: u.verification_required });
		var u;
	}
	async challenge(e, t) {
		const n = "".concat(c(Is, this), "/passkey/challenge"), o = f({ client_id: c(Os, this) }, hc(c(js, this)));
		null != e && e.realm && (o.realm = e.realm), null != e && e.organization && (o.organization = e.organization);
		const i = await r(Us, this, mc).call(this, t)(n, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(o)
		});
		if (!i.ok) {
			const e = await r(Us, this, yc).call(this, i), t = new lc(e.error_description || "Failed to request login challenge", e);
			throw t.statusCode = i.status, t.headers = Da(i.headers), t;
		}
		return {
			authSession: (a = await i.json()).auth_session,
			authnParamsPublicKey: f({}, a.authn_params_public_key)
		};
		var a;
	}
	async getTokenByPasskey(e, t) {
		void 0 !== e.organization && Fa(e.organization);
		const n = new URLSearchParams({
			auth_session: e.authSession,
			authn_response: JSON.stringify(e.credential)
		});
		if (e.realm && n.append("realm", e.realm), e.scope && n.append("scope", e.scope), e.audience && n.append("audience", e.audience), e.organization && n.append("organization", e.organization), e.verification) {
			const t = Object.fromEntries(Object.entries(e.verification).filter((e) => y(e, 2)[1]));
			Object.keys(t).length > 0 && n.append("verification", JSON.stringify(t));
		}
		let o;
		try {
			o = await c(Ms, this).call(this, pc, n, t, e.fullResponse);
		} catch (e) {
			if (e instanceof za) throw e;
			const t = null == e ? void 0 : e.cause, n = ka(e), o = new dc(n.error_description || "Failed to exchange passkey credential for tokens.", f(f({}, n), {}, {
				verification_required: null == t ? void 0 : t.verification_required,
				auth_session: null == t ? void 0 : t.auth_session
			}));
			throw Ha(o, e), o;
		}
		if (e.fullResponse) {
			const t = o;
			return e.organization && Va(t.data.claims, e.organization), t;
		}
		const i = o;
		return e.organization && Va(i.claims, e.organization), i;
	}
});
function mc(e) {
	return ic(c(Ws, this), e, c(Ns, this));
}
async function yc(e) {
	const t = await e.clone().text();
	try {
		return f(f({}, JSON.parse(t)), {}, {
			statusCode: e.status,
			headers: e.headers,
			body: t
		});
	} catch (n) {
		return {
			error: "unknown_error",
			error_description: 429 === e.status ? "Too many requests. Please try again later." : "HTTP ".concat(e.status, " ").concat(e.statusText),
			statusCode: e.status,
			headers: e.headers,
			body: t
		};
	}
}
var wc = class extends Error {
	constructor(e, t, n) {
		super(t), h(this, "cause", void 0), h(this, "code", void 0), h(this, "statusCode", void 0), h(this, "headers", void 0), h(this, "body", void 0), Object.setPrototypeOf(this, new.target.prototype), this.code = e, this.cause = n && (n.error || n.error_description) ? {
			error: n.error,
			error_description: n.error_description,
			message: n.message,
			mfa_token: n.mfa_token,
			mfa_requirements: n.mfa_requirements
		} : void 0;
		const o = _a(n);
		this.statusCode = o.statusCode, this.headers = o.headers, this.body = o.body;
	}
};
var gc = class extends wc {
	constructor(e, t) {
		super("passwordless_start_error", e, t), this.name = "PasswordlessStartError";
	}
};
var vc = class extends wc {
	constructor(e, t) {
		super("passwordless_verify_error", e, t), this.name = "PasswordlessVerifyError";
	}
};
var bc = class extends wc {
	constructor(e, t) {
		super("passwordless_db_get_token_error", e, t), this.name = "PasswordlessDbGetTokenError";
	}
};
var _c = class extends wc {
	constructor(e, t, n, o, i) {
		super("passwordless_challenge_error", e, n), h(this, "statusCode", void 0), h(this, "validationErrors", void 0), this.name = "PasswordlessChallengeError", this.statusCode = t, this.validationErrors = o, this.headers = null != i ? i : this.headers;
	}
};
function kc(e) {
	return /^\+[1-9]\d{1,14}$/.test(e);
}
async function Sc(e, t, n) {
	if (e.useMtls) return {};
	if (e.clientAssertionSigningKey) {
		var o;
		const i = null !== (o = e.clientAssertionSigningAlg) && void 0 !== o ? o : "RS256", r = e.clientAssertionSigningKey instanceof CryptoKey ? e.clientAssertionSigningKey : await bs(e.clientAssertionSigningKey, i);
		return {
			client_assertion: await new $r({}).setProtectedHeader({ alg: i }).setIssuer(t).setSubject(t).setAudience("https://".concat(n, "/")).setJti(crypto.randomUUID()).setIssuedAt().setExpirationTime("".concat(120, "s")).sign(r),
			client_assertion_type: "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
		};
	}
	if (e.clientSecret) return { client_secret: e.clientSecret };
	throw new La();
}
var Tc = (Ls = /* @__PURE__ */ new WeakMap(), Ks = /* @__PURE__ */ new WeakMap(), zs = /* @__PURE__ */ new WeakMap(), Js = /* @__PURE__ */ new WeakMap(), Ds = /* @__PURE__ */ new WeakMap(), Hs = /* @__PURE__ */ new WeakMap(), Zs = /* @__PURE__ */ new WeakMap(), Fs = /* @__PURE__ */ new WeakSet(), class {
	constructor(e) {
		var t, n;
		d(this, Fs), u(this, Ls, void 0), u(this, Ks, void 0), u(this, zs, void 0), u(this, Js, void 0), u(this, Ds, void 0), u(this, Hs, void 0), u(this, Zs, void 0), l(Ks, this, e.domain), l(Ls, this, "https://".concat(e.domain)), l(zs, this, e.clientId), l(Js, this, null !== (t = e.customFetch) && void 0 !== t ? t : function() {
			return fetch(...arguments);
		}), l(Ds, this, null !== (n = e.telemetryConfig) && void 0 !== n ? n : nc()), l(Hs, this, {
			clientSecret: e.clientSecret,
			clientAssertionSigningKey: e.clientAssertionSigningKey,
			clientAssertionSigningAlg: e.clientAssertionSigningAlg,
			useMtls: e.useMtls
		}), l(Zs, this, e.grantRequest);
	}
	async sendEmail(e, t) {
		const n = await r(Fs, this, Cc).call(this, function(e) {
			var t;
			const n = null !== (t = e.send) && void 0 !== t ? t : "code", o = {
				email: e.email,
				connection: "email",
				send: n
			};
			return "link" === n && e.authParams && (o.authParams = e.authParams), o;
		}(e), "Failed to send passwordless email", e.language, t);
		if (e.fullResponse) return {
			data: void 0,
			response: n
		};
	}
	async sendSms(e, t) {
		if (!kc(e.phoneNumber)) throw new gc("Phone number must be in E.164 format (e.g. +14155550100).");
		const n = await r(Fs, this, Cc).call(this, function(e) {
			return {
				phone_number: e.phoneNumber,
				connection: "sms"
			};
		}(e), "Failed to send passwordless SMS", e.language, t);
		if (e.fullResponse) return {
			data: void 0,
			response: n
		};
	}
	async challengeWithEmail(e, t) {
		const n = function(e) {
			var t;
			return {
				email: e.email,
				connection: e.connection,
				allow_signup: null !== (t = e.allowSignup) && void 0 !== t && t
			};
		}(e);
		return r(Fs, this, Ec).call(this, n, "Failed to request email OTP challenge", t);
	}
	async challengeWithPhoneNumber(e, t) {
		if (!kc(e.phoneNumber)) throw new _c("Phone number must be in E.164 format (e.g. +14155550100).", 0, void 0, void 0);
		const n = function(e) {
			var t;
			const n = {
				phone_number: e.phoneNumber,
				connection: e.connection,
				allow_signup: null !== (t = e.allowSignup) && void 0 !== t && t
			};
			return e.deliveryMethod && (n.delivery_method = e.deliveryMethod), n;
		}(e);
		return r(Fs, this, Ec).call(this, n, "Failed to request phone OTP challenge", t);
	}
	async getTokenByPasswordlessDbConnection(e, t) {
		const n = new URLSearchParams({
			auth_session: e.authSession,
			otp: e.otp
		});
		if (e.scope && n.append("scope", e.scope), e.audience && n.append("audience", e.audience), !c(Zs, this)) throw new bc("Missing grant request delegate.", ka(/* @__PURE__ */ new Error("missing grantRequest")));
		try {
			return await c(Zs, this).call(this, "http://auth0.com/oauth/grant-type/passwordless/otp", n, t, e.fullResponse);
		} catch (e) {
			if (e instanceof za) throw e;
			const t = new bc("There was an error while trying to request a token.", ka(e)), n = e;
			throw t.statusCode = n._statusCode, t.headers = n._headers, t;
		}
	}
});
function Pc(e) {
	return ic(c(Js, this), e, c(Ds, this));
}
async function Cc(e, t, n, o) {
	var i;
	const s = await Sc(c(Hs, this), c(zs, this), c(Ks, this)), a = f(f({ client_id: c(zs, this) }, e), s);
	let u;
	try {
		u = await r(Fs, this, Pc).call(this, o)("".concat(c(Ls, this), "/passwordless/start"), {
			method: "POST",
			headers: f({ "Content-Type": "application/json" }, n ? { "x-request-language": n } : {}),
			body: JSON.stringify(a)
		});
	} catch (e) {
		throw new gc("".concat(t, ": a network error occurred."));
	}
	if (u.ok) return u;
	const l = await u.clone().text();
	let d;
	if (204 !== u.status) try {
		d = JSON.parse(l);
	} catch (e) {
		d = void 0;
	}
	const h = new gc((null === (i = d) || void 0 === i ? void 0 : i.error_description) || t, d);
	throw h.statusCode = u.status, h.headers = Da(u.headers), h.body = l, h;
}
async function Ec(e, t, n) {
	var o, i;
	const s = await Sc(c(Hs, this), c(zs, this), c(Ks, this)), a = f(f({ client_id: c(zs, this) }, e), s);
	let u;
	try {
		u = await r(Fs, this, Pc).call(this, n)("".concat(c(Ls, this), "/otp/challenge"), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(a)
		});
	} catch (e) {
		throw new _c("challenge error: a network error occurred.", 0, void 0, void 0);
	}
	if (u.ok) {
		let e;
		try {
			e = await u.json();
		} catch (e) {
			throw new _c("".concat(t, ": could not parse the response body."), u.status, void 0, void 0, Da(u.headers));
		}
		return { authSession: e.auth_session };
	}
	const l = await u.clone().text();
	let d;
	try {
		d = JSON.parse(l);
	} catch (e) {
		d = void 0;
	}
	const h = d ? f(f({}, d), {}, {
		statusCode: u.status,
		headers: u.headers,
		body: l
	}) : {
		error: "",
		error_description: "",
		statusCode: u.status,
		headers: u.headers,
		body: l
	};
	throw new _c((null === (o = d) || void 0 === o ? void 0 : o.error_description) || t, u.status, h, null === (i = d) || void 0 === i ? void 0 : i.validation_errors, Da(u.headers));
}
var Rc = class extends Error {
	constructor(e, t, n) {
		super(t), h(this, "cause", void 0), h(this, "code", void 0), h(this, "statusCode", void 0), h(this, "headers", void 0), h(this, "body", void 0), Object.setPrototypeOf(this, new.target.prototype), this.code = e, this.cause = n && {
			error: n.error,
			error_description: n.error_description,
			message: n.message
		};
		const o = _a(n);
		this.statusCode = o.statusCode, this.headers = o.headers, this.body = o.body;
	}
};
var Ac = class extends Rc {
	constructor(e, t) {
		super("signup_error", e, t), this.name = "SignUpError";
	}
};
var xc = class extends Rc {
	constructor(e, t) {
		super("change_password_error", e, t), this.name = "ChangePasswordError";
	}
};
function Ic(e, t, n) {
	for (const o of t) if (null === e[o] || void 0 === e[o] || "" === e[o]) throw new n("Required parameter \"".concat(String(o), "\" was null, undefined, or empty."));
}
function Oc(e) {
	var t, n;
	return {
		id: null !== (t = null !== (n = e._id) && void 0 !== n ? n : e.user_id) && void 0 !== t ? t : e.id,
		email: "string" == typeof e.email ? e.email : "",
		emailVerified: Boolean(e.email_verified),
		username: e.username,
		givenName: e.given_name,
		familyName: e.family_name,
		name: e.name,
		nickname: e.nickname,
		picture: e.picture,
		userMetadata: e.user_metadata
	};
}
var jc = (Vs = /* @__PURE__ */ new WeakMap(), Xs = /* @__PURE__ */ new WeakMap(), Gs = /* @__PURE__ */ new WeakMap(), qs = /* @__PURE__ */ new WeakMap(), Ys = /* @__PURE__ */ new WeakSet(), class {
	constructor(e) {
		var t, n;
		d(this, Ys), u(this, Vs, void 0), u(this, Xs, void 0), u(this, Gs, void 0), u(this, qs, void 0), l(Vs, this, "https://".concat(e.domain)), l(Xs, this, e.clientId), l(Gs, this, null !== (t = e.customFetch) && void 0 !== t ? t : function() {
			return fetch(...arguments);
		}), l(qs, this, null !== (n = e.telemetryConfig) && void 0 !== n ? n : nc());
	}
	async signUp(e, t) {
		var n;
		Ic(e, [
			"email",
			"password",
			"connection"
		], Ac);
		const o = f({ client_id: null !== (n = e.clientId) && void 0 !== n ? n : c(Xs, this) }, function(e) {
			const t = {
				email: e.email,
				password: e.password,
				connection: e.connection
			};
			return void 0 !== e.username && (t.username = e.username), void 0 !== e.givenName && (t.given_name = e.givenName), void 0 !== e.familyName && (t.family_name = e.familyName), void 0 !== e.name && (t.name = e.name), void 0 !== e.nickname && (t.nickname = e.nickname), void 0 !== e.picture && (t.picture = e.picture), void 0 !== e.userMetadata && (t.user_metadata = e.userMetadata), t;
		}(e)), i = await r(Ys, this, Wc).call(this, "/dbconnections/signup", o, Ac, "Failed to sign up", t);
		if (e.fullResponse) {
			const e = i.clone();
			return {
				data: Oc(await i.json()),
				response: e
			};
		}
		return Oc(await i.json());
	}
	async changePassword(e, t) {
		var n;
		if (Ic(e, ["connection"], xc), !e.email && !e.username) throw new xc("Either \"email\" or \"username\" is required.");
		const o = f({ client_id: null !== (n = e.clientId) && void 0 !== n ? n : c(Xs, this) }, function(e) {
			const t = { connection: e.connection };
			return void 0 !== e.email && (t.email = e.email), void 0 !== e.username && (t.username = e.username), void 0 !== e.organization && (t.organization = e.organization), t;
		}(e)), i = await r(Ys, this, Wc).call(this, "/dbconnections/change_password", o, xc, "Failed to request a password change", t);
		if (e.fullResponse) {
			const e = i.clone();
			return {
				data: await i.text(),
				response: e
			};
		}
		return i.text();
	}
});
async function Wc(e, t, n, o, i) {
	const r = ic(c(Gs, this), i, c(qs, this));
	let s;
	try {
		s = await r("".concat(c(Vs, this)).concat(e), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(t)
		});
	} catch (e) {
		throw new n("".concat(o, ": a network error occurred."));
	}
	if (s.ok) return s;
	const a = await s.clone().text(), u = await async function(e) {
		let t;
		try {
			t = await e.json();
		} catch (e) {
			return;
		}
		return "string" == typeof t.error ? t : "string" == typeof t.code ? {
			error: t.code,
			error_description: "string" == typeof t.description ? t.description : ""
		} : void 0;
	}(s.clone()), l = new n((null == u ? void 0 : u.error_description) || o, null != u ? u : {
		error: "unknown_error",
		error_description: o
	});
	throw l.statusCode = s.status, l.headers = Da(s.headers), l.body = a, l;
}
var Nc = class extends Error {
	constructor(e, t, n) {
		super(t), h(this, "code", void 0), h(this, "cause", void 0), this.name = "AnonymousSessionError", this.code = e, this.cause = n && {
			error: n.error,
			error_description: n.error_description,
			message: n.message
		};
	}
};
async function Mc(e, t, n) {
	if (e.useMtls) return {};
	if (e.clientAssertionSigningKey) {
		var o;
		const i = null !== (o = e.clientAssertionSigningAlg) && void 0 !== o ? o : "RS256", r = e.clientAssertionSigningKey instanceof CryptoKey ? e.clientAssertionSigningKey : await bs(e.clientAssertionSigningKey, i);
		return {
			client_assertion: await new $r({}).setProtectedHeader({ alg: i }).setIssuer(t).setSubject(t).setAudience("https://".concat(n, "/")).setJti(crypto.randomUUID()).setIssuedAt().setExpirationTime("".concat(120, "s")).sign(r),
			client_assertion_type: "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
		};
	}
	return e.clientSecret ? { client_secret: e.clientSecret } : {};
}
async function Uc(e) {
	const t = "Request failed with status ".concat(e.status);
	let n = {};
	try {
		n = await e.json();
	} catch (e) {}
	return {
		error: "string" == typeof n.error ? n.error : "server_error",
		error_description: "string" == typeof n.error_description ? n.error_description : t
	};
}
var Lc = (Bs = /* @__PURE__ */ new WeakMap(), Qs = /* @__PURE__ */ new WeakMap(), $s = /* @__PURE__ */ new WeakMap(), ea = /* @__PURE__ */ new WeakMap(), ta = /* @__PURE__ */ new WeakMap(), na = /* @__PURE__ */ new WeakMap(), oa = /* @__PURE__ */ new WeakMap(), ia = /* @__PURE__ */ new WeakMap(), ra = /* @__PURE__ */ new WeakSet(), class {
	constructor(e) {
		var t;
		d(this, ra), u(this, Bs, void 0), u(this, Qs, void 0), u(this, $s, void 0), u(this, ea, void 0), u(this, ta, void 0), u(this, na, void 0), u(this, oa, void 0), u(this, ia, void 0), l(Bs, this, e.domain), l(Qs, this, "https://".concat(e.domain)), l($s, this, e.clientId), l(ea, this, e.clientSecret), l(ta, this, e.clientAssertionSigningKey), l(na, this, e.clientAssertionSigningAlg), l(oa, this, e.useMtls), l(ia, this, null !== (t = e.customFetch) && void 0 !== t ? t : function() {
			return fetch(...arguments);
		});
	}
	async createSession(e) {
		const t = { client_id: c($s, this) };
		null != e && e.audience && (t.audience = e.audience), null != e && e.scope && (t.scope = e.scope), null != e && e.metadata && (t.metadata = e.metadata);
		const n = await r(ra, this, zc).call(this, t);
		if (!n.sessionToken) throw new Nc("server_error", "session_token missing from create session response");
		return {
			sessionToken: n.sessionToken,
			accessToken: n.accessToken,
			expiresAt: n.expiresAt,
			sessionTokenExpiresAt: n.sessionTokenExpiresAt,
			scope: n.scope
		};
	}
	async getAccessToken(e) {
		return null != e && e.sessionToken ? r(ra, this, Kc).call(this, e.sessionToken, e) : this.createSession({
			audience: null == e ? void 0 : e.audience,
			scope: null == e ? void 0 : e.scope
		});
	}
	async logout() {
		const e = "".concat(c(Qs, this), "/anonymous/logout"), t = { client_id: c($s, this) }, n = await c(ia, this).call(this, e, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			credentials: "include",
			redirect: "error",
			body: JSON.stringify(t)
		});
		if (!n.ok) {
			const e = await Uc(n);
			throw new Nc(e.error, e.error_description || "Failed to end anonymous session", e);
		}
	}
	async mintTransferToken(e) {
		const t = "".concat(c(Qs, this), "/anonymous/token"), n = {
			client_id: c($s, this),
			session_token: e,
			audience: "urn:auth0:anon_transfer"
		};
		try {
			const e = await Mc({
				clientSecret: c(ea, this),
				clientAssertionSigningKey: c(ta, this),
				clientAssertionSigningAlg: c(na, this),
				useMtls: c(oa, this)
			}, c($s, this), c(Bs, this));
			Object.assign(n, e);
			const o = await c(ia, this).call(this, t, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				redirect: "error",
				body: JSON.stringify(n)
			});
			if (!o.ok) return null;
			const i = await o.json();
			return "string" == typeof i.anon_transfer_token ? i.anon_transfer_token : null;
		} catch (e) {
			return null;
		}
	}
});
async function Kc(e, t) {
	const n = {
		client_id: c($s, this),
		session_token: e
	};
	null != t && t.audience && (n.audience = t.audience), null != t && t.scope && (n.scope = t.scope);
	const o = await r(ra, this, zc).call(this, n);
	return {
		sessionToken: e,
		accessToken: o.accessToken,
		expiresAt: o.expiresAt,
		sessionTokenExpiresAt: o.sessionTokenExpiresAt,
		scope: o.scope
	};
}
async function zc(e) {
	const t = "".concat(c(Qs, this), "/anonymous/token"), n = await Mc({
		clientSecret: c(ea, this),
		clientAssertionSigningKey: c(ta, this),
		clientAssertionSigningAlg: c(na, this),
		useMtls: c(oa, this)
	}, c($s, this), c(Bs, this));
	Object.assign(e, n);
	const o = await c(ia, this).call(this, t, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		credentials: "include",
		redirect: "error",
		body: JSON.stringify(e)
	});
	if (!o.ok) {
		const e = await Uc(o);
		throw new Nc(e.error, e.error_description || "Anonymous token request failed", e);
	}
	let i;
	try {
		i = await o.json();
	} catch (e) {
		throw new Nc("server_error", "Invalid response from anonymous token endpoint");
	}
	return function(e) {
		const t = Math.floor(Date.now() / 1e3);
		if ("string" != typeof e.access_token || !e.access_token) throw new Nc("server_error", "access_token missing or invalid in anonymous token response");
		const n = e.expires_in;
		if ("number" != typeof n || !Number.isFinite(n)) throw new Nc("server_error", "expires_in missing or invalid in anonymous token response");
		return {
			accessToken: e.access_token,
			expiresAt: t + n,
			scope: e.scope,
			sessionToken: e.session_token,
			sessionTokenExpiresAt: "number" == typeof e.session_expires_in && Number.isFinite(e.session_expires_in) ? t + e.session_expires_in : void 0
		};
	}(i);
}
var Jc = (sa = /* @__PURE__ */ new WeakMap(), aa = /* @__PURE__ */ new WeakMap(), ca = /* @__PURE__ */ new WeakMap(), class {
	constructor(e, t) {
		u(this, sa, /* @__PURE__ */ new Map()), u(this, aa, void 0), u(this, ca, void 0), l(ca, this, Math.max(1, Math.floor(e))), l(aa, this, Math.max(0, Math.floor(t)));
	}
	get(e) {
		const t = c(sa, this).get(e);
		if (t) {
			if (!(Date.now() >= t.expiresAt)) return c(sa, this).delete(e), c(sa, this).set(e, t), t.value;
			c(sa, this).delete(e);
		}
	}
	set(e, t, n) {
		c(sa, this).has(e) && c(sa, this).delete(e);
		const o = null != n && Number.isFinite(n) && n > 0 ? n : c(aa, this);
		for (c(sa, this).set(e, {
			value: t,
			expiresAt: Date.now() + o
		}); c(sa, this).size > c(ca, this);) {
			const e = c(sa, this).keys().next().value;
			if (void 0 === e) break;
			c(sa, this).delete(e);
		}
	}
});
var Dc = /* @__PURE__ */ new Map();
function Hc(e) {
	return {
		ttlMs: 1e3 * ("number" == typeof (null == e ? void 0 : e.ttl) ? e.ttl : 600),
		maxEntries: "number" == typeof (null == e ? void 0 : e.maxEntries) && e.maxEntries > 0 ? e.maxEntries : 100
	};
}
var Zc = class {
	static createDiscoveryCache(e) {
		const t = (n = e.maxEntries, o = e.ttlMs, "".concat(n, ":").concat(o));
		var n, o;
		let i = (r = t, Dc.get(r));
		var r;
		return i || (i = new Jc(e.maxEntries, e.ttlMs), Dc.set(t, i)), i;
	}
	static createJwksCache() {
		return {};
	}
};
var Fc = "openid profile email offline_access";
var Vc = Object.freeze(/* @__PURE__ */ new Set([
	"grant_type",
	"client_id",
	"client_secret",
	"client_assertion",
	"client_assertion_type",
	"subject_token",
	"subject_token_type",
	"requested_token_type",
	"actor_token",
	"actor_token_type",
	"audience",
	"aud",
	"resource",
	"resources",
	"resource_indicator",
	"scope",
	"connection",
	"login_hint",
	"organization",
	"assertion"
]));
function Xc(e) {
	if (null == e) throw new xa("subject_token is required");
	if ("string" != typeof e) throw new xa("subject_token must be a string");
	if (0 === e.trim().length) throw new xa("subject_token cannot be blank or whitespace");
	if (e !== e.trim()) throw new xa("subject_token must not include leading or trailing whitespace");
	if (/^bearer\s+/i.test(e)) throw new xa("subject_token must not include the 'Bearer ' prefix");
}
function Gc(e, t) {
	if (t) for (const o of Object.entries(t)) {
		var n = y(o, 2);
		const t = n[0], i = n[1];
		if (!Vc.has(t)) if (Array.isArray(i)) {
			if (i.length > 20) throw new xa("Parameter '".concat(t, "' exceeds maximum array size of ").concat(20));
			i.forEach((n) => {
				e.append(t, n);
			});
		} else e.append(t, i);
	}
}
var qc = "urn:auth0:params:oauth:grant-type:token-exchange:federated-connection-access-token";
var Yc = "urn:ietf:params:oauth:grant-type:token-exchange";
var Bc = "urn:ietf:params:oauth:token-type:access_token";
function Qc(e, t) {
	return (n, o) => {
		const i = null == o ? void 0 : o.body;
		if (t !== pc || !(i instanceof URLSearchParams)) return e(n, o);
		const r = {};
		for (const e of i) {
			var s = y(e, 2);
			const t = s[0], n = s[1];
			r[t] = "authn_response" === t || "verification" === t ? JSON.parse(n) : n;
		}
		const a = new Headers(null == o ? void 0 : o.headers);
		return a.set("Content-Type", "application/json"), e(n, f(f({}, o), {}, {
			headers: a,
			body: JSON.stringify(r)
		}));
	};
}
var $c = (ua = /* @__PURE__ */ new WeakMap(), la = /* @__PURE__ */ new WeakMap(), da = /* @__PURE__ */ new WeakMap(), ha = /* @__PURE__ */ new WeakMap(), pa = /* @__PURE__ */ new WeakMap(), fa = /* @__PURE__ */ new WeakMap(), ma = /* @__PURE__ */ new WeakMap(), ya = /* @__PURE__ */ new WeakMap(), wa = /* @__PURE__ */ new WeakMap(), ga = /* @__PURE__ */ new WeakMap(), va = /* @__PURE__ */ new WeakMap(), ba = /* @__PURE__ */ new WeakSet(), class {
	constructor(e) {
		var t;
		if (d(this, ba), u(this, ua, void 0), u(this, la, void 0), u(this, da, void 0), u(this, ha, void 0), u(this, pa, void 0), u(this, fa, void 0), u(this, ma, void 0), u(this, ya, void 0), u(this, wa, void 0), u(this, ga, void 0), u(this, va, void 0), h(this, "mfa", void 0), h(this, "passkey", void 0), h(this, "passwordless", void 0), h(this, "database", void 0), h(this, "anonymous", void 0), l(pa, this, e), e.useMtls && !e.customFetch) throw new Sa("mtls_without_custom_fetch_not_supported", "Using mTLS without a custom fetch implementation is not supported");
		l(ma, this, nc(e.telemetry)), l(fa, this, tc(null !== (t = e.customFetch) && void 0 !== t ? t : function() {
			return fetch(...arguments);
		}, c(ma, this)));
		const n = Hc(e.discoveryCache);
		l(wa, this, Zc.createDiscoveryCache(n)), l(ga, this, /* @__PURE__ */ new Map()), l(va, this, Zc.createJwksCache()), this.mfa = new sc({
			domain: c(pa, this).domain,
			clientId: c(pa, this).clientId,
			clientSecret: c(pa, this).clientSecret,
			customFetch: c(fa, this),
			telemetryConfig: c(ma, this),
			getConfiguration: async (e) => (await r(ba, this, ou).call(this, e)).configuration,
			createCaptureConfiguration: async (e) => {
				const t = (await r(ba, this, iu).call(this)).serverMetadata;
				return r(ba, this, tu).call(this, t, e);
			}
		}), this.passkey = new fc({
			domain: c(pa, this).domain,
			clientId: c(pa, this).clientId,
			clientSecret: c(pa, this).clientSecret,
			useMtls: c(pa, this).useMtls,
			customFetch: c(fa, this),
			telemetryConfig: c(ma, this),
			grantRequest: async (e, t, n, o) => {
				const i = (await r(ba, this, iu).call(this)).serverMetadata, s = r(ba, this, nu).call(this, n);
				if (o) {
					const n = oc(s), o = await r(ba, this, tu).call(this, i, n);
					o[Xi] = Qc(n, e);
					const a = await _r(o, e, t), c = ec.fromTokenEndpointResponse(a), u = n.getCapturedResponse();
					if (!u) throw new za();
					return {
						data: c,
						response: u
					};
				}
				const a = await r(ba, this, tu).call(this, i);
				a[Xi] = Qc(s, e);
				const c = await _r(a, e, t);
				return ec.fromTokenEndpointResponse(c);
			}
		}), this.passwordless = new Tc({
			domain: c(pa, this).domain,
			clientId: c(pa, this).clientId,
			customFetch: c(fa, this),
			telemetryConfig: c(ma, this),
			clientSecret: c(pa, this).clientSecret,
			clientAssertionSigningKey: c(pa, this).clientAssertionSigningKey,
			clientAssertionSigningAlg: c(pa, this).clientAssertionSigningAlg,
			useMtls: c(pa, this).useMtls,
			grantRequest: async (e, t, n, o) => {
				const i = (await r(ba, this, ou).call(this, n)).configuration;
				if (o) {
					var s;
					const n = oc(null !== (s = i[Xi]) && void 0 !== s ? s : c(fa, this)), a = await _r(await r(ba, this, tu).call(this, i.serverMetadata(), n), e, t), u = ec.fromTokenEndpointResponse(a), l = n.getCapturedResponse();
					if (!l) throw new za();
					return {
						data: u,
						response: l
					};
				}
				try {
					const n = await _r(i, e, t);
					return ec.fromTokenEndpointResponse(n);
				} catch (e) {
					const t = e, n = {};
					throw Ha(n, e), t._statusCode = n.statusCode, t._headers = n.headers, e;
				}
			}
		}), this.database = new jc({
			domain: c(pa, this).domain,
			clientId: c(pa, this).clientId,
			customFetch: c(fa, this),
			telemetryConfig: c(ma, this)
		}), this.anonymous = new Lc({
			domain: c(pa, this).domain,
			clientId: c(pa, this).clientId,
			clientSecret: c(pa, this).clientSecret,
			clientAssertionSigningKey: c(pa, this).clientAssertionSigningKey,
			clientAssertionSigningAlg: c(pa, this).clientAssertionSigningAlg,
			useMtls: c(pa, this).useMtls,
			customFetch: c(fa, this)
		});
	}
	async getServerMetadata() {
		return (await r(ba, this, iu).call(this)).serverMetadata;
	}
	async buildAuthorizationUrl(e) {
		const t = (await r(ba, this, iu).call(this)).serverMetadata;
		if (null != e && e.pushedAuthorizationRequests && !t.pushed_authorization_request_endpoint) throw new Sa("par_not_supported_error", "The Auth0 tenant does not have pushed authorization requests enabled. Learn how to enable it here: https://auth0.com/docs/get-started/applications/configure-par");
		try {
			return await r(ba, this, du).call(this, e);
		} catch (e) {
			throw new Na(e);
		}
	}
	async buildLinkUserUrl(e) {
		try {
			const t = await r(ba, this, du).call(this, { authorizationParams: f(f({}, e.authorizationParams), {}, {
				requested_connection: e.connection,
				requested_connection_scope: e.connectionScope,
				scope: "openid link_account offline_access",
				id_token_hint: e.idToken
			}) });
			return {
				linkUserUrl: t.authorizationUrl,
				codeVerifier: t.codeVerifier
			};
		} catch (e) {
			throw new Ma(e);
		}
	}
	async buildUnlinkUserUrl(e) {
		try {
			const t = await r(ba, this, du).call(this, { authorizationParams: f(f({}, e.authorizationParams), {}, {
				requested_connection: e.connection,
				scope: "openid unlink_account",
				id_token_hint: e.idToken
			}) });
			return {
				unlinkUserUrl: t.authorizationUrl,
				codeVerifier: t.codeVerifier
			};
		} catch (e) {
			throw new Ua(e);
		}
	}
	async backchannelAuthentication(e, t) {
		var n;
		const o = await r(ba, this, ou).call(this, t), i = o.configuration, s = o.serverMetadata, a = Za(f(f({}, c(pa, this).authorizationParams), null == e ? void 0 : e.authorizationParams)), u = new URLSearchParams(f(f({ scope: Fc }, a), {}, {
			client_id: c(pa, this).clientId,
			binding_message: e.bindingMessage,
			login_hint: JSON.stringify({
				format: "iss_sub",
				iss: s.issuer,
				sub: e.loginHint.sub
			})
		}));
		if (e.requestedExpiry && u.append("requested_expiry", e.requestedExpiry.toString()), e.authorizationDetails && u.append("authorization_details", JSON.stringify(e.authorizationDetails)), e.fullResponse) {
			var l;
			const e = oc(null !== (l = i[Xi]) && void 0 !== l ? l : c(fa, this)), t = await r(ba, this, tu).call(this, i.serverMetadata(), e);
			try {
				const o = await ur(t, await cr(i, u)), r = e.getCapturedResponse();
				if (!r) throw new za();
				return {
					data: ec.fromTokenEndpointResponse(o),
					response: r
				};
			} catch (t) {
				if (t instanceof za) throw t;
				const n = new Wa(t);
				throw Ha(n, t, e.getCapturedResponse()), n;
			}
		}
		const d = oc(null !== (n = i[Xi]) && void 0 !== n ? n : c(fa, this)), h = await r(ba, this, tu).call(this, i.serverMetadata(), d);
		try {
			const t = await ur(h, await cr(i, u));
			return ec.fromTokenEndpointResponse(t);
		} catch (e) {
			const t = new Wa(e);
			throw Ha(t, e, d.getCapturedResponse()), t;
		}
	}
	async initiateBackchannelAuthentication(e, t) {
		var n;
		const o = await r(ba, this, ou).call(this, t), i = o.configuration, s = o.serverMetadata, a = Za(f(f({}, c(pa, this).authorizationParams), null == e ? void 0 : e.authorizationParams)), u = new URLSearchParams(f(f({ scope: Fc }, a), {}, {
			client_id: c(pa, this).clientId,
			binding_message: e.bindingMessage,
			login_hint: JSON.stringify({
				format: "iss_sub",
				iss: s.issuer,
				sub: e.loginHint.sub
			})
		}));
		e.requestedExpiry && u.append("requested_expiry", e.requestedExpiry.toString()), e.authorizationDetails && u.append("authorization_details", JSON.stringify(e.authorizationDetails));
		const l = oc(null !== (n = i[Xi]) && void 0 !== n ? n : c(fa, this)), d = await r(ba, this, tu).call(this, i.serverMetadata(), l);
		try {
			const e = await cr(d, u);
			return {
				authReqId: e.auth_req_id,
				expiresIn: e.expires_in,
				interval: e.interval
			};
		} catch (e) {
			const t = new Wa(e), n = l.getCapturedResponse();
			throw t.statusCode = null == n ? void 0 : n.status, t.headers = n ? Da(n.headers) : void 0, t;
		}
	}
	async backchannelAuthenticationGrant(e, t) {
		var n;
		let o = e.authReqId;
		const i = (await r(ba, this, ou).call(this, t)).configuration, s = new URLSearchParams({ auth_req_id: o }), a = oc(null !== (n = i[Xi]) && void 0 !== n ? n : c(fa, this)), u = await r(ba, this, tu).call(this, i.serverMetadata(), a);
		try {
			const e = await _r(u, "urn:openid:params:grant-type:ciba", s);
			return ec.fromTokenEndpointResponse(e);
		} catch (e) {
			const t = new Wa(e), n = a.getCapturedResponse();
			throw t.statusCode = null == n ? void 0 : n.status, t.headers = n ? Da(n.headers) : void 0, t;
		}
	}
	async getTokenForConnection(e, t) {
		var n;
		if (e.refreshToken && e.accessToken) throw new Aa("Either a refresh or access token should be specified, but not both.");
		const o = null !== (n = e.accessToken) && void 0 !== n ? n : e.refreshToken;
		if (!o) throw new Aa("Either a refresh or access token must be specified.");
		try {
			return await this.exchangeToken(f({
				connection: e.connection,
				subjectToken: o,
				subjectTokenType: e.accessToken ? Bc : "urn:ietf:params:oauth:token-type:refresh_token",
				loginHint: e.loginHint
			}, e.fullResponse ? { fullResponse: !0 } : {}), t);
		} catch (e) {
			if (e instanceof xa) {
				const t = new Aa(e.message, e.cause);
				throw t.statusCode = e.statusCode, t.headers = e.headers, t;
			}
			throw e;
		}
	}
	async exchangeToken(e, t) {
		return e.fullResponse ? "connection" in e ? r(ba, this, su).call(this, e, t, !0) : r(ba, this, cu).call(this, e, t, !0) : "connection" in e ? r(ba, this, su).call(this, e, t) : r(ba, this, cu).call(this, e, t);
	}
	async getTokenByCode(e, t, n) {
		var o;
		const i = (await r(ba, this, ou).call(this, n)).configuration;
		if (void 0 !== t.organization && Fa(t.organization), t.fullResponse) {
			var s;
			const n = oc(null !== (s = i[Xi]) && void 0 !== s ? s : c(fa, this)), o = await r(ba, this, tu).call(this, i.serverMetadata(), n);
			let a, u;
			try {
				const i = await dr(o, e, { pkceCodeVerifier: t.codeVerifier });
				if (a = ec.fromTokenEndpointResponse(i), u = n.getCapturedResponse(), !u) throw new za();
			} catch (e) {
				if (e instanceof za) throw e;
				const t = new Pa("There was an error while trying to request a token.", ka(e)), o = n.getCapturedResponse();
				throw t.statusCode = null == o ? void 0 : o.status, t.headers = o ? Da(o.headers) : void 0, t;
			}
			return t.organization && Va(a.claims, t.organization), {
				data: a,
				response: u
			};
		}
		const a = oc(null !== (o = i[Xi]) && void 0 !== o ? o : c(fa, this)), u = await r(ba, this, tu).call(this, i.serverMetadata(), a);
		let l;
		try {
			const n = await dr(u, e, { pkceCodeVerifier: t.codeVerifier });
			l = ec.fromTokenEndpointResponse(n);
		} catch (e) {
			const t = new Pa("There was an error while trying to request a token.", ka(e)), n = a.getCapturedResponse();
			throw t.statusCode = null == n ? void 0 : n.status, t.headers = n ? Da(n.headers) : void 0, t;
		}
		return t.organization && Va(l.claims, t.organization), l;
	}
	async getTokenByMagicLinkCode(e, t, n) {
		var o;
		const i = (await r(ba, this, ou).call(this, n)).configuration;
		if (null != t && t.fullResponse) {
			var s;
			const n = oc(null !== (s = i[Xi]) && void 0 !== s ? s : c(fa, this)), o = await r(ba, this, tu).call(this, i.serverMetadata(), n);
			try {
				const i = await dr(o, e, { expectedState: null == t ? void 0 : t.expectedState }), r = ec.fromTokenEndpointResponse(i), s = n.getCapturedResponse();
				if (!s) throw new za();
				return {
					data: r,
					response: s
				};
			} catch (e) {
				if (e instanceof za) throw e;
				const o = new Pa(e instanceof Error && e.message ? e.message : "There was an error while trying to request a token.", e), i = n.getCapturedResponse();
				throw o.statusCode = null == i ? void 0 : i.status, o.headers = i ? Da(i.headers) : void 0, o;
			}
		}
		const a = oc(null !== (o = i[Xi]) && void 0 !== o ? o : c(fa, this)), u = await r(ba, this, tu).call(this, i.serverMetadata(), a);
		try {
			const n = await dr(u, e, { expectedState: null == t ? void 0 : t.expectedState });
			return ec.fromTokenEndpointResponse(n);
		} catch (e) {
			const n = new Pa(e instanceof Error && e.message ? e.message : "There was an error while trying to request a token.", e), o = a.getCapturedResponse();
			throw n.statusCode = null == o ? void 0 : o.status, n.headers = o ? Da(o.headers) : void 0, n;
		}
	}
	async getTokenByRefreshToken(e, t) {
		var n;
		const o = (await r(ba, this, ou).call(this, t)).configuration, i = new URLSearchParams();
		if (e.audience && i.append("audience", e.audience), e.scope && i.append("scope", e.scope), e.fullResponse) {
			var s;
			const t = oc(null !== (s = o[Xi]) && void 0 !== s ? s : c(fa, this)), n = await r(ba, this, tu).call(this, o.serverMetadata(), t);
			try {
				const o = await hr(n, e.refreshToken, i), r = ec.fromTokenEndpointResponse(o), s = t.getCapturedResponse();
				if (!s) throw new za();
				return {
					data: r,
					response: s
				};
			} catch (e) {
				if (e instanceof za) throw e;
				const n = new Ea("The access token has expired and there was an error while trying to refresh it.", ka(e)), o = t.getCapturedResponse();
				throw n.statusCode = null == o ? void 0 : o.status, n.headers = o ? Da(o.headers) : void 0, n;
			}
		}
		const a = oc(null !== (n = o[Xi]) && void 0 !== n ? n : c(fa, this)), u = await r(ba, this, tu).call(this, o.serverMetadata(), a);
		try {
			const t = await hr(u, e.refreshToken, i);
			return ec.fromTokenEndpointResponse(t);
		} catch (e) {
			const t = new Ea("The access token has expired and there was an error while trying to refresh it.", ka(e)), n = a.getCapturedResponse();
			throw t.statusCode = null == n ? void 0 : n.status, t.headers = n ? Da(n.headers) : void 0, t;
		}
	}
	async revokeToken(e, t) {
		var n;
		const o = (await r(ba, this, ou).call(this, t)).configuration, i = {};
		e.tokenTypeHint && (i.token_type_hint = e.tokenTypeHint);
		const s = oc(null !== (n = o[Xi]) && void 0 !== n ? n : c(fa, this)), a = await r(ba, this, tu).call(this, o.serverMetadata(), s);
		try {
			await kr(a, e.token, i);
		} catch (e) {
			const t = new Ia("An error occurred while trying to revoke the token.", ka(e)), n = s.getCapturedResponse();
			throw t.statusCode = null == n ? void 0 : n.status, t.headers = n ? Da(n.headers) : void 0, t;
		}
	}
	async getUserInfo(e, t) {
		const n = (await r(ba, this, ou).call(this, t, !0)).configuration;
		try {
			var o;
			return await gr(n, e.accessToken, null !== (o = e.expectedSubject) && void 0 !== o ? o : Vi);
		} catch (e) {
			throw new Oa("There was an error while trying to retrieve the user info.", ka(e));
		}
	}
	async getTokenByPassword(e, t) {
		var n;
		const o = (await r(ba, this, ou).call(this, t)).configuration, i = new URLSearchParams({
			username: e.username,
			password: e.password
		});
		e.audience && i.append("audience", e.audience), e.scope && i.append("scope", e.scope), e.realm && i.append("realm", e.realm);
		let s = o;
		if (e.auth0ForwardedFor) {
			const t = await r(ba, this, lu).call(this);
			s = new ir(o.serverMetadata(), c(pa, this).clientId, {
				client_secret: c(pa, this).clientSecret,
				use_mtls_endpoint_aliases: c(pa, this).useMtls
			}, t);
			const n = o[Xi];
			s[Xi] = (t, o) => n(t, f(f({}, o), {}, { headers: f(f({}, o.headers), {}, { "auth0-forwarded-for": e.auth0ForwardedFor }) }));
		}
		if (e.fullResponse) {
			var a;
			const e = oc(null !== (a = s[Xi]) && void 0 !== a ? a : c(fa, this)), t = await r(ba, this, tu).call(this, s.serverMetadata(), e);
			try {
				const n = await _r(t, "password", i), o = ec.fromTokenEndpointResponse(n), r = e.getCapturedResponse();
				if (!r) throw new za();
				return {
					data: o,
					response: r
				};
			} catch (t) {
				if (t instanceof za) throw t;
				const n = new Ra("There was an error while trying to request a token.", ka(t)), o = e.getCapturedResponse();
				throw n.statusCode = null == o ? void 0 : o.status, n.headers = o ? Da(o.headers) : void 0, n;
			}
		}
		const u = oc(null !== (n = s[Xi]) && void 0 !== n ? n : c(fa, this)), l = await r(ba, this, tu).call(this, s.serverMetadata(), u);
		try {
			const e = await _r(l, "password", i);
			return ec.fromTokenEndpointResponse(e);
		} catch (e) {
			const t = new Ra("There was an error while trying to request a token.", ka(e)), n = u.getCapturedResponse();
			throw t.statusCode = null == n ? void 0 : n.status, t.headers = n ? Da(n.headers) : void 0, t;
		}
	}
	async getTokenByPasswordlessEmail(e, t) {
		const n = new URLSearchParams({
			username: e.email,
			otp: e.code,
			realm: "email"
		});
		return e.audience && n.append("audience", e.audience), e.scope && n.append("scope", e.scope), r(ba, this, uu).call(this, n, t, e.fullResponse);
	}
	async getTokenByPasswordlessSms(e, t) {
		if (!kc(e.phoneNumber)) throw new vc("Phone number must be in E.164 format (e.g. +14155550100).");
		const n = new URLSearchParams({
			username: e.phoneNumber,
			otp: e.code,
			realm: "sms"
		});
		return e.audience && n.append("audience", e.audience), e.scope && n.append("scope", e.scope), r(ba, this, uu).call(this, n, t, e.fullResponse);
	}
	async getTokenByClientCredentials(e, t) {
		var n;
		const o = function(e) {
			if (null == e) return;
			const t = "string" == typeof e ? e.split(/\s+/).filter(Boolean) : [];
			if (0 === t.length) throw new Ja();
			return t.join(" ");
		}(e.scope), i = (await r(ba, this, ou).call(this, t)).configuration;
		if (e.fullResponse) {
			var s;
			const t = oc(null !== (s = i[Xi]) && void 0 !== s ? s : c(fa, this)), n = await r(ba, this, tu).call(this, i.serverMetadata(), t), a = new URLSearchParams({ audience: e.audience });
			e.organization && a.append("organization", e.organization), void 0 !== o && a.append("scope", o);
			try {
				const e = await pr(n, a), o = ec.fromTokenEndpointResponse(e), i = t.getCapturedResponse();
				if (!i) throw new za();
				return {
					data: o,
					response: i
				};
			} catch (e) {
				if (e instanceof za) throw e;
				const n = new Ca("There was an error while trying to request a token.", ka(e)), o = t.getCapturedResponse();
				throw n.statusCode = null == o ? void 0 : o.status, n.headers = o ? Da(o.headers) : void 0, n;
			}
		}
		const a = oc(null !== (n = i[Xi]) && void 0 !== n ? n : c(fa, this)), u = await r(ba, this, tu).call(this, i.serverMetadata(), a);
		try {
			const t = new URLSearchParams({ audience: e.audience });
			e.organization && t.append("organization", e.organization), void 0 !== o && t.append("scope", o);
			const n = await pr(u, t);
			return ec.fromTokenEndpointResponse(n);
		} catch (e) {
			const t = new Ca("There was an error while trying to request a token.", ka(e)), n = a.getCapturedResponse();
			throw t.statusCode = null == n ? void 0 : n.status, t.headers = n ? Da(n.headers) : void 0, t;
		}
	}
	async buildLogoutUrl(e) {
		const t = await r(ba, this, iu).call(this), n = t.configuration;
		if (!t.serverMetadata.end_session_endpoint) {
			const t = new URL("https://".concat(c(pa, this).domain, "/v2/logout"));
			return t.searchParams.set("returnTo", e.returnTo), t.searchParams.set("client_id", c(pa, this).clientId), e.federated && t.searchParams.set("federated", ""), t;
		}
		const o = { post_logout_redirect_uri: e.returnTo };
		return e.federated && (o.federated = ""), function(e, t) {
			yr(e);
			const n = Di(e), o = n.as, i = n.c, r = En(o, "end_session_endpoint", !1, n.tlsOnly);
			(t = new URLSearchParams(t)).has("client_id") || t.set("client_id", i.client_id);
			for (const e of t.entries()) {
				var s = y(e, 2);
				const t = s[0], n = s[1];
				r.searchParams.append(t, n);
			}
			return r;
		}(n, o);
	}
	async verifyLogoutToken(e) {
		const t = (await r(ba, this, iu).call(this)).serverMetadata, n = Hc(c(pa, this).discoveryCache), o = t.jwks_uri;
		c(ya, this) || l(ya, this, vs(new URL(o), {
			cacheMaxAge: n.ttlMs,
			[ms]: c(fa, this),
			[ys]: c(va, this)
		}));
		const i = (await qr(e.logoutToken, c(ya, this), {
			issuer: t.issuer,
			audience: c(pa, this).clientId,
			algorithms: ["RS256"],
			requiredClaims: ["iat"]
		})).payload;
		if (!("sid" in i) && !("sub" in i)) throw new ja("either \"sid\" or \"sub\" (or both) claims must be present");
		if ("sid" in i && "string" != typeof i.sid) throw new ja("\"sid\" claim must be a string");
		if ("sub" in i && "string" != typeof i.sub) throw new ja("\"sub\" claim must be a string");
		if ("nonce" in i) throw new ja("\"nonce\" claim is prohibited");
		if (!("events" in i)) throw new ja("\"events\" claim is missing");
		if ("object" != typeof i.events || null === i.events) throw new ja("\"events\" claim must be an object");
		if (!("http://schemas.openid.net/event/backchannel-logout" in i.events)) throw new ja("\"http://schemas.openid.net/event/backchannel-logout\" member is missing in the \"events\" claim");
		if ("object" != typeof i.events["http://schemas.openid.net/event/backchannel-logout"]) throw new ja("\"http://schemas.openid.net/event/backchannel-logout\" member in the \"events\" claim must be an object");
		return {
			sid: i.sid,
			sub: i.sub
		};
	}
});
function eu() {
	const e = c(pa, this).domain.toLowerCase();
	return "".concat(e, "|mtls:").concat(c(pa, this).useMtls ? "1" : "0");
}
async function tu(e, t) {
	let n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
	const o = await r(ba, this, lu).call(this, n), i = new ir(e, c(pa, this).clientId, {
		client_secret: c(pa, this).clientSecret,
		use_mtls_endpoint_aliases: c(pa, this).useMtls
	}, o);
	return i[Xi] = null != t ? t : c(fa, this), i;
}
function nu(e) {
	return ic(c(fa, this), e, c(ma, this));
}
async function ou(e) {
	let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
	const n = await r(ba, this, iu).call(this, t), o = n.configuration, i = n.serverMetadata;
	if (!e) return {
		configuration: o,
		serverMetadata: i
	};
	const s = r(ba, this, nu).call(this, e);
	return {
		configuration: await r(ba, this, tu).call(this, i, s, t),
		serverMetadata: i
	};
}
async function iu() {
	let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
	const t = c(e ? la : ua, this);
	if (t && c(da, this)) return {
		configuration: t,
		serverMetadata: c(da, this)
	};
	const n = r(ba, this, eu).call(this);
	e || await r(ba, this, lu).call(this, !1);
	const o = c(wa, this).get(n);
	if (o) return r(ba, this, ru).call(this, o.serverMetadata, e);
	const i = c(ga, this).get(n);
	if (i) {
		const t = await i;
		return r(ba, this, ru).call(this, t.serverMetadata, e);
	}
	const s = (async () => {
		const e = (await nr(new URL("https://".concat(c(pa, this).domain)), c(pa, this).clientId, { use_mtls_endpoint_aliases: c(pa, this).useMtls }, (e, t, n, o) => {
			n.set("client_id", t.client_id);
		}, { [Xi]: c(fa, this) })).serverMetadata();
		return c(wa, this).set(n, { serverMetadata: e }), { serverMetadata: e };
	})();
	s.catch(() => {}), c(ga, this).set(n, s);
	try {
		const t = (await s).serverMetadata;
		return r(ba, this, ru).call(this, t, e);
	} finally {
		c(ga, this).delete(n);
	}
}
async function ru(e, t) {
	const n = await r(ba, this, tu).call(this, e, void 0, t);
	return l(da, this, e), l(t ? la : ua, this, n), {
		configuration: n,
		serverMetadata: e
	};
}
async function su(e, t, n) {
	var o, i, s;
	const a = (await r(ba, this, ou).call(this, t)).configuration;
	if ("audience" in e || "resource" in e) throw new xa("audience and resource parameters are not supported for Token Vault exchanges");
	Xc(e.subjectToken);
	const u = new URLSearchParams({
		connection: e.connection,
		subject_token: e.subjectToken,
		subject_token_type: null !== (o = e.subjectTokenType) && void 0 !== o ? o : Bc,
		requested_token_type: null !== (i = e.requestedTokenType) && void 0 !== i ? i : "http://auth0.com/oauth/token-type/federated-connection-access-token"
	});
	if (e.loginHint && u.append("login_hint", e.loginHint), e.scope && u.append("scope", e.scope), Gc(u, e.extra), n) {
		var l;
		const t = oc(null !== (l = a[Xi]) && void 0 !== l ? l : c(fa, this)), n = await r(ba, this, tu).call(this, a.serverMetadata(), t);
		try {
			const e = await _r(n, qc, u), o = ec.fromTokenEndpointResponse(e), i = t.getCapturedResponse();
			if (!i) throw new za();
			return {
				data: o,
				response: i
			};
		} catch (n) {
			if (n instanceof za) throw n;
			const o = new xa("Failed to exchange token for connection '".concat(e.connection, "'."), ka(n)), i = t.getCapturedResponse();
			throw o.statusCode = null == i ? void 0 : i.status, o.headers = i ? Da(i.headers) : void 0, o;
		}
	}
	const d = oc(null !== (s = a[Xi]) && void 0 !== s ? s : c(fa, this)), h = await r(ba, this, tu).call(this, a.serverMetadata(), d);
	try {
		const e = await _r(h, qc, u);
		return ec.fromTokenEndpointResponse(e);
	} catch (t) {
		const n = new xa("Failed to exchange token for connection '".concat(e.connection, "'."), ka(t)), o = d.getCapturedResponse();
		throw n.statusCode = null == o ? void 0 : o.status, n.headers = o ? Da(o.headers) : void 0, n;
	}
}
function au(e, t, n) {
	var o;
	if (n.organization && Va(e.claims, n.organization), n.actorToken) if (null !== (o = e.claims) && void 0 !== o && o.act) e.act = e.claims.act;
	else try {
		e.act = function(e) {
			if ("string" != typeof e) throw new Qo("JWTs must use Compact JWS serialization, JWT must be a string");
			const t = e.split("."), n = t[1], o = t.length;
			if (5 === o) throw new Qo("Only JWTs using Compact JWS serialization can be decoded");
			if (3 !== o) throw new Qo("Invalid JWT");
			if (!n) throw new Qo("JWTs must contain a payload");
			let i, r;
			try {
				i = ii(n);
			} catch (e) {
				throw new Qo("Failed to base64url decode the payload", { cause: e });
			}
			try {
				r = JSON.parse(Jo.decode(i));
			} catch (e) {
				throw new Qo("Failed to parse the decoded payload as JSON", { cause: e });
			}
			if (!si(r)) throw new Qo("Invalid JWT Claims Set");
			return r;
		}(t.access_token).act;
	} catch (e) {}
	return e;
}
async function cu(e, t, n) {
	var o;
	const i = (await r(ba, this, ou).call(this, t)).configuration;
	if (Xc(e.subjectToken), void 0 !== e.organization && Fa(e.organization), void 0 !== e.actorToken && void 0 === e.actorTokenType) throw new xa("actorTokenType is required when actorToken is provided");
	const s = new URLSearchParams({
		subject_token_type: e.subjectTokenType,
		subject_token: e.subjectToken
	});
	if (e.audience && s.append("audience", e.audience), e.scope && s.append("scope", e.scope), e.requestedTokenType && s.append("requested_token_type", e.requestedTokenType), e.organization && s.append("organization", e.organization), e.actorToken && s.append("actor_token", e.actorToken), e.actorTokenType && s.append("actor_token_type", e.actorTokenType), Gc(s, e.extra), n) {
		var a;
		const t = oc(null !== (a = i[Xi]) && void 0 !== a ? a : c(fa, this)), n = await r(ba, this, tu).call(this, i.serverMetadata(), t);
		let o, u, l;
		try {
			if (u = await _r(n, Yc, s), o = ec.fromTokenEndpointResponse(u), l = t.getCapturedResponse(), !l) throw new za();
		} catch (n) {
			if (n instanceof za) throw n;
			const o = new xa("Failed to exchange token of type '".concat(e.subjectTokenType, "'").concat(e.audience ? " for audience '".concat(e.audience, "'") : "", "."), ka(n)), i = t.getCapturedResponse();
			throw o.statusCode = null == i ? void 0 : i.status, o.headers = i ? Da(i.headers) : void 0, o;
		}
		return r(ba, this, au).call(this, o, u, e), {
			data: o,
			response: l
		};
	}
	const u = oc(null !== (o = i[Xi]) && void 0 !== o ? o : c(fa, this)), l = await r(ba, this, tu).call(this, i.serverMetadata(), u);
	let d, h;
	try {
		h = await _r(l, Yc, s), d = ec.fromTokenEndpointResponse(h);
	} catch (t) {
		const n = new xa("Failed to exchange token of type '".concat(e.subjectTokenType, "'").concat(e.audience ? " for audience '".concat(e.audience, "'") : "", "."), ka(t)), o = u.getCapturedResponse();
		throw n.statusCode = null == o ? void 0 : o.status, n.headers = o ? Da(o.headers) : void 0, n;
	}
	return r(ba, this, au).call(this, d, h, e), d;
}
async function uu(e, t, n) {
	var o;
	const i = (await r(ba, this, ou).call(this, t)).configuration;
	if (n) {
		var s;
		const t = oc(null !== (s = i[Xi]) && void 0 !== s ? s : c(fa, this)), n = await r(ba, this, tu).call(this, i.serverMetadata(), t);
		try {
			const o = await _r(n, "http://auth0.com/oauth/grant-type/passwordless/otp", e), i = ec.fromTokenEndpointResponse(o), r = t.getCapturedResponse();
			if (!r) throw new za();
			return {
				data: i,
				response: r
			};
		} catch (e) {
			if (e instanceof za) throw e;
			const n = new vc("There was an error while trying to request a token.", ka(e)), o = t.getCapturedResponse();
			throw n.statusCode = null == o ? void 0 : o.status, n.headers = o ? Da(o.headers) : void 0, n;
		}
	}
	const a = oc(null !== (o = i[Xi]) && void 0 !== o ? o : c(fa, this)), u = await r(ba, this, tu).call(this, i.serverMetadata(), a);
	try {
		const t = await _r(u, "http://auth0.com/oauth/grant-type/passwordless/otp", e);
		return ec.fromTokenEndpointResponse(t);
	} catch (e) {
		const t = new vc("There was an error while trying to request a token.", ka(e)), n = a.getCapturedResponse();
		throw t.statusCode = null == n ? void 0 : n.status, t.headers = n ? Da(n.headers) : void 0, t;
	}
}
async function lu() {
	let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
	const t = !!c(pa, this).clientSecret || !!c(pa, this).clientAssertionSigningKey || !!c(pa, this).useMtls;
	return e && !t ? (e, t, n, o) => {
		n.set("client_id", t.client_id);
	} : (c(ha, this) || l(ha, this, (async () => {
		if (!c(pa, this).clientSecret && !c(pa, this).clientAssertionSigningKey && !c(pa, this).useMtls) throw new La();
		if (c(pa, this).useMtls) return (e, t, n, o) => {
			n.set("client_id", t.client_id);
		};
		let e = c(pa, this).clientAssertionSigningKey;
		return !e || e instanceof CryptoKey || (e = await bs(e, c(pa, this).clientAssertionSigningAlg || "RS256")), e ? function(e, t) {
			return Sn(e, t);
		}(e) : Fi(c(pa, this).clientSecret);
	})().catch((e) => {
		throw l(ha, this, void 0), e;
	})), c(ha, this));
}
async function du(e) {
	const t = (await r(ba, this, iu).call(this)).configuration, n = Qi(), o = await Bi(n), i = Za(f(f({}, c(pa, this).authorizationParams), null == e ? void 0 : e.authorizationParams)), s = new URLSearchParams(f(f({ scope: Fc }, i), {}, {
		client_id: c(pa, this).clientId,
		code_challenge: o,
		code_challenge_method: "S256"
	}));
	return {
		authorizationUrl: null != e && e.pushedAuthorizationRequests ? await mr(t, s) : await fr(t, s),
		codeVerifier: n
	};
}
var hu = new Jc(1e3, 6e4);
var pu = class pu extends E {
	constructor(e, t) {
		super(e, t), Object.setPrototypeOf(this, pu.prototype);
	}
	static fromPayload(e) {
		let t = e.error, n = e.error_description;
		return new pu(t, n);
	}
};
var fu = class fu extends pu {
	constructor(e, t) {
		super(e, t), Object.setPrototypeOf(this, fu.prototype);
	}
};
var mu = class mu extends pu {
	constructor(e, t) {
		super(e, t), Object.setPrototypeOf(this, mu.prototype);
	}
};
var yu = class yu extends pu {
	constructor(e, t) {
		super(e, t), Object.setPrototypeOf(this, yu.prototype);
	}
};
var wu = class wu extends pu {
	constructor(e, t) {
		super(e, t), Object.setPrototypeOf(this, wu.prototype);
	}
};
var gu = class gu extends pu {
	constructor(e, t) {
		super(e, t), Object.setPrototypeOf(this, gu.prototype);
	}
};
var vu = class {
	constructor() {
		let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 6e5;
		this.contexts = /* @__PURE__ */ new Map(), this.ttlMs = e;
	}
	set(e, t) {
		this.cleanup(), this.contexts.set(e, Object.assign(Object.assign({}, t), { createdAt: Date.now() }));
	}
	get(e) {
		const t = this.contexts.get(e);
		if (t) {
			if (!(Date.now() - t.createdAt > this.ttlMs)) return t;
			this.contexts.delete(e);
		}
	}
	remove(e) {
		this.contexts.delete(e);
	}
	cleanup() {
		const e = Date.now();
		for (const n of this.contexts) {
			var t = y(n, 2);
			const o = t[0];
			e - t[1].createdAt > this.ttlMs && this.contexts.delete(o);
		}
	}
	get size() {
		return this.contexts.size;
	}
};
var bu = class {
	constructor(e, t) {
		this.authJsMfaClient = e, this.auth0Client = t, this.contextManager = new vu();
	}
	setMFAAuthDetails(e, t, n, o) {
		this.contextManager.set(e, {
			scope: t,
			audience: n,
			mfaRequirements: o
		});
	}
	async getAuthenticators(e) {
		var t, n, o;
		const i = this.contextManager.get(e);
		if (!i) throw new fu("invalid_request", "MFA context not found for this MFA token");
		const r = null === (n = null === (t = i.mfaRequirements) || void 0 === t ? void 0 : t.challenge) || void 0 === n ? void 0 : n.map((e) => e.type);
		try {
			const t = await this.authJsMfaClient.listAuthenticators({ mfaToken: e });
			return r && 0 !== r.length ? t.filter((e) => !!e.type && r.includes(e.type)) : t;
		} catch (e) {
			if (e instanceof Ga) throw new fu(null === (o = e.cause) || void 0 === o ? void 0 : o.error, e.message);
			throw e;
		}
	}
	async enroll(e) {
		var t;
		const n = function(e) {
			const t = jt[e.factorType];
			return Object.assign(Object.assign(Object.assign({
				mfaToken: e.mfaToken,
				authenticatorTypes: t.authenticatorTypes
			}, t.oobChannels && { oobChannels: t.oobChannels }), "phoneNumber" in e && { phoneNumber: e.phoneNumber }), "email" in e && { email: e.email });
		}(e);
		try {
			return await this.authJsMfaClient.enrollAuthenticator(n);
		} catch (e) {
			if (e instanceof qa) throw new mu(null === (t = e.cause) || void 0 === t ? void 0 : t.error, e.message);
			throw e;
		}
	}
	async challenge(e) {
		var t;
		try {
			const t = {
				challengeType: e.challengeType,
				mfaToken: e.mfaToken
			};
			return e.authenticatorId && (t.authenticatorId = e.authenticatorId), await this.authJsMfaClient.challengeAuthenticator(t);
		} catch (e) {
			if (e instanceof Ba) throw new yu(null === (t = e.cause) || void 0 === t ? void 0 : t.error, e.message);
			throw e;
		}
	}
	async getEnrollmentFactors(e) {
		const t = this.contextManager.get(e);
		if (!t || !t.mfaRequirements) throw new gu("mfa_context_not_found", "MFA context not found for this MFA token. Please retry the original request to get a new MFA token.");
		return t.mfaRequirements.enroll && 0 !== t.mfaRequirements.enroll.length ? t.mfaRequirements.enroll : [];
	}
	async verify(e) {
		const t = this.contextManager.get(e.mfaToken);
		if (!t) throw new wu("mfa_context_not_found", "MFA context not found for this MFA token. Please retry the original request to get a new MFA token.");
		const n = function(e) {
			return "otp" in e && e.otp ? Wt : "oobCode" in e && e.oobCode ? Nt : "recoveryCode" in e && e.recoveryCode ? Mt : void 0;
		}(e);
		if (!n) throw new wu("invalid_request", "Unable to determine grant type. Provide one of: otp, oobCode, or recoveryCode.");
		const o = t.scope, i = t.audience;
		try {
			const t = await this.auth0Client._requestTokenForMfa({
				grant_type: n,
				mfaToken: e.mfaToken,
				scope: o,
				audience: i,
				otp: e.otp,
				oob_code: e.oobCode,
				binding_code: e.bindingCode,
				recovery_code: e.recoveryCode
			});
			return this.contextManager.remove(e.mfaToken), t;
		} catch (e) {
			if (e instanceof wu) throw new wu(e.error, e.error_description);
			throw e;
		}
	}
};
var _u = class _u extends Error {
	constructor(e, t, n) {
		super(t), this.name = "PasskeyError", this.code = e, this.cause = n, Object.setPrototypeOf(this, _u.prototype);
	}
};
var ku;
var Su;
var Tu;
var Pu = class {
	constructor(e, t) {
		ku.set(this, void 0), Su.set(this, void 0), Tu.set(this, null), n(this, ku, e, "f"), n(this, Su, t, "f");
	}
	async signup(o) {
		if (!window.PublicKeyCredential) throw new _u("passkey_not_supported", "WebAuthn is not supported in this browser.");
		n(this, Tu, null, "f");
		const i = o.scope, r = o.audience, s = e(o, ["scope", "audience"]), a = await t(this, ku, "f").register(s);
		if (a.verificationRequired && a.verificationRequired.length > 0) throw n(this, Tu, {
			authSession: a.authSession,
			publicKey: Ru(a.authnParamsPublicKey),
			verificationRequired: a.verificationRequired,
			realm: s.realm,
			organization: s.organization,
			scope: i,
			audience: r
		}, "f"), new M(a.verificationRequired);
		const c = Ru(a.authnParamsPublicKey), u = await navigator.credentials.create({ publicKey: c });
		if (!u) throw new _u("passkey_cancelled", "Passkey creation was cancelled or no credential was returned.");
		const l = xu(u);
		return t(this, Su, "f")._requestTokenForPasskey({
			authSession: a.authSession,
			credential: l,
			realm: s.realm,
			organization: s.organization,
			scope: i,
			audience: r
		});
	}
	async login(n) {
		if (!window.PublicKeyCredential) throw new _u("passkey_not_supported", "WebAuthn is not supported in this browser.");
		const o = n || {}, i = o.scope, r = o.audience, s = e(o, ["scope", "audience"]), a = await t(this, ku, "f").challenge(Object.keys(s).length > 0 ? s : void 0), c = Au(a.authnParamsPublicKey), u = await navigator.credentials.get({ publicKey: c });
		if (!u) throw new _u("passkey_cancelled", "Passkey authentication was cancelled or no credential was returned.");
		const l = Iu(u);
		return t(this, Su, "f")._requestTokenForPasskey({
			authSession: a.authSession,
			credential: l,
			realm: s.realm,
			organization: s.organization,
			scope: i,
			audience: r
		});
	}
	async getSignupChallenge(e) {
		if (!window.PublicKeyCredential) throw new _u("passkey_not_supported", "WebAuthn is not supported in this browser.");
		const n = await t(this, ku, "f").register(e);
		return Object.assign({
			authSession: n.authSession,
			publicKey: Ru(n.authnParamsPublicKey)
		}, n.verificationRequired && { verificationRequired: n.verificationRequired });
	}
	async getLoginChallenge(e) {
		if (!window.PublicKeyCredential) throw new _u("passkey_not_supported", "WebAuthn is not supported in this browser.");
		const n = await t(this, ku, "f").challenge(e);
		return {
			authSession: n.authSession,
			publicKey: Au(n.authnParamsPublicKey)
		};
	}
	async getTokenWithPasskey(e) {
		if (!window.PublicKeyCredential) throw new _u("passkey_not_supported", "WebAuthn is not supported in this browser.");
		const n = e.authSession, o = e.credential, i = e.realm, r = e.organization, s = e.scope, a = e.audience, c = e.verification, u = null != c ? c : {};
		if (Object.keys(u).some((e) => "" === u[e])) throw new _u("missing_verification_code", "OTP codes in verification must not be empty.");
		const l = o.response;
		let d;
		if (l instanceof AuthenticatorAttestationResponse) d = xu(o);
		else {
			if (!(l instanceof AuthenticatorAssertionResponse)) throw new _u("passkey_invalid_credential", "The provided credential is not a valid attestation or assertion response.");
			d = Iu(o);
		}
		return t(this, Su, "f")._requestTokenForPasskey({
			authSession: n,
			credential: d,
			realm: i,
			organization: r,
			scope: s,
			audience: a,
			verification: c
		});
	}
	async continueSignup(e) {
		if (!t(this, Tu, "f")) throw new _u("no_pending_signup", "No pending signup found. Call signup() first and catch PasskeyVerificationRequiredError.");
		const o = t(this, Tu, "f").verificationRequired.filter((t) => !(null == e ? void 0 : e[t]));
		if (o.length > 0) throw new _u("missing_verification_code", "Missing OTP code for: ".concat(o.join(", "), ". Pass a code for each identifier in verificationRequired."));
		const i = t(this, Tu, "f");
		n(this, Tu, null, "f");
		const r = i.authSession, s = i.publicKey, a = i.realm, c = i.organization, u = i.scope, l = i.audience;
		let d = i.credential;
		if (!d) {
			let e;
			try {
				e = await navigator.credentials.create({ publicKey: s });
			} catch (e) {
				throw n(this, Tu, i, "f"), e;
			}
			if (!e) throw n(this, Tu, i, "f"), new _u("passkey_cancelled", "Passkey creation was cancelled or no credential was returned.");
			d = xu(e);
		}
		try {
			return await t(this, Su, "f")._requestTokenForPasskey({
				authSession: r,
				credential: d,
				realm: a,
				organization: c,
				scope: u,
				audience: l,
				verification: e
			});
		} catch (e) {
			throw e instanceof dc && e.isRetryable && n(this, Tu, Object.assign(Object.assign({}, i), {
				authSession: e.authSession,
				verificationRequired: e.verificationRequired,
				credential: d
			}), "f"), e;
		}
	}
};
function Cu(e) {
	const t = new Uint8Array(e), n = Array.from(t, (e) => String.fromCharCode(e)).join("");
	return btoa(n).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function Eu(e) {
	const t = e.replace(/-/g, "+").replace(/_/g, "/"), n = t + "=".repeat((4 - t.length % 4) % 4), o = atob(n), i = new Uint8Array(o.length);
	for (let e = 0; e < o.length; e++) i[e] = o.charCodeAt(e);
	return i.buffer;
}
function Ru(e) {
	return Object.assign(Object.assign({}, e), {
		challenge: Eu(e.challenge),
		user: Object.assign(Object.assign({}, e.user), { id: Eu(e.user.id) }),
		pubKeyCredParams: e.pubKeyCredParams,
		authenticatorSelection: e.authenticatorSelection
	});
}
function Au(e) {
	return Object.assign(Object.assign({}, e), { challenge: Eu(e.challenge) });
}
function xu(e) {
	var t;
	const n = e.response;
	return {
		id: e.id,
		rawId: Cu(e.rawId),
		type: e.type,
		authenticatorAttachment: null !== (t = e.authenticatorAttachment) && void 0 !== t ? t : void 0,
		response: {
			clientDataJSON: Cu(n.clientDataJSON),
			attestationObject: Cu(n.attestationObject)
		},
		clientExtensionResults: e.getClientExtensionResults()
	};
}
function Iu(e) {
	var t;
	const n = e.response;
	return {
		id: e.id,
		rawId: Cu(e.rawId),
		type: e.type,
		authenticatorAttachment: null !== (t = e.authenticatorAttachment) && void 0 !== t ? t : void 0,
		response: {
			clientDataJSON: Cu(n.clientDataJSON),
			authenticatorData: Cu(n.authenticatorData),
			signature: Cu(n.signature),
			userHandle: n.userHandle ? Cu(n.userHandle) : void 0
		},
		clientExtensionResults: e.getClientExtensionResults()
	};
}
ku = /* @__PURE__ */ new WeakMap(), Su = /* @__PURE__ */ new WeakMap(), Tu = /* @__PURE__ */ new WeakMap();
function Ou(e) {
	return {
		get() {
			try {
				const t = window.localStorage.getItem(e);
				return t ? JSON.parse(t) : null;
			} catch (e) {
				return null;
			}
		},
		set(t) {
			try {
				window.localStorage.setItem(e, JSON.stringify(t));
			} catch (e) {}
		},
		remove() {
			try {
				window.localStorage.removeItem(e);
			} catch (e) {}
		}
	};
}
function ju() {
	let e = null;
	return {
		get: () => e,
		set: (t) => {
			e = t;
		},
		remove: () => {
			e = null;
		}
	};
}
var Wu = class {
	constructor(e, t) {
		this.slots = /* @__PURE__ */ new Map(), this.baseKey = "".concat("@@auth0spajs@@", "::").concat(e, "::anonymous");
		try {
			this.useLocalStorage = "localStorage" === t && "undefined" != typeof window && !!window.localStorage;
		} catch (e) {
			this.useLocalStorage = !1;
		}
		this.sessionKey = "".concat(this.baseKey, "::").concat("session"), this.sessionStore = this.useLocalStorage ? Ou(this.sessionKey) : ju();
		const n = "".concat(this.baseKey, "::").concat("session_expired");
		this.expiredStore = this.useLocalStorage ? Ou(n) : ju();
	}
	getStore(e, t) {
		const n = "".concat(this.baseKey, "::").concat(JSON.stringify([null != e ? e : "", null != t ? t : ""]));
		return this.slots.has(n) || this.slots.set(n, this.useLocalStorage ? Ou(n) : ju()), this.slots.get(n);
	}
	getSessionToken() {
		return this.sessionStore.get();
	}
	setSessionToken(e) {
		this.sessionStore.set(e), this.expiredStore.remove();
	}
	isSessionExpired() {
		return !!this.expiredStore.get();
	}
	markSessionExpired() {
		this.expiredStore.set(!0);
	}
	removeAll() {
		if (this.sessionStore.remove(), this.expiredStore.remove(), this.slots.forEach((e) => e.remove()), this.slots.clear(), this.useLocalStorage) try {
			const e = this.baseKey + "::", t = [];
			for (let n = 0; n < window.localStorage.length; n++) {
				const o = window.localStorage.key(n);
				null != o && o.startsWith(e) && t.push(o);
			}
			t.forEach((e) => window.localStorage.removeItem(e));
		} catch (e) {}
	}
};
var Nu = class {
	constructor(e, t) {
		let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "localStorage", o = arguments.length > 3 ? arguments[3] : void 0;
		this.authJsClient = e, this.clientId = t, this.cache = new Wu(t, n), this.lockManager = null != o ? o : me();
	}
	async createSession(e) {
		const t = await this.authJsClient.createSession(e);
		return this.cache.setSessionToken(Object.assign({ sessionToken: t.sessionToken }, void 0 !== t.sessionTokenExpiresAt && { sessionTokenExpiresAt: t.sessionTokenExpiresAt })), this.cache.getStore(null == e ? void 0 : e.audience, null == e ? void 0 : e.scope).set(Object.assign({
			accessToken: t.accessToken,
			expiresAt: t.expiresAt
		}, void 0 !== t.scope && { scope: t.scope })), t;
	}
	async getTokenSilently(e) {
		const t = this.cache.getStore(null == e ? void 0 : e.audience, null == e ? void 0 : e.scope), n = t.get();
		return n && n.expiresAt - 60 > Date.now() / 1e3 ? n : this.lockManager.runWithLock("anonymous::".concat(this.clientId), 5e3, async () => {
			var n;
			if (this.cache.isSessionExpired()) throw new Nc("session_expired", "The anonymous session has expired. Call createSession() to start a new one.");
			const o = t.get();
			if (o && o.expiresAt - 60 > Date.now() / 1e3) return o;
			const i = null === (n = this.cache.getSessionToken()) || void 0 === n ? void 0 : n.sessionToken;
			let r;
			try {
				r = await this.authJsClient.getAccessToken(Object.assign(Object.assign({}, e), { sessionToken: i }));
			} catch (e) {
				throw e instanceof Nc && ("session_expired" === e.code || "invalid_session_token" === e.code) && (this.cache.removeAll(), this.cache.markSessionExpired()), e;
			}
			return this.cache.getStore(null == e ? void 0 : e.audience, null == e ? void 0 : e.scope).set(Object.assign({
				accessToken: r.accessToken,
				expiresAt: r.expiresAt
			}, void 0 !== r.scope && { scope: r.scope })), this.cache.getSessionToken() || this.cache.setSessionToken(Object.assign({ sessionToken: r.sessionToken }, void 0 !== r.sessionTokenExpiresAt && { sessionTokenExpiresAt: r.sessionTokenExpiresAt })), Object.assign({
				accessToken: r.accessToken,
				expiresAt: r.expiresAt
			}, void 0 !== r.scope && { scope: r.scope });
		});
	}
	async mintTransferToken() {
		const e = this.cache.getSessionToken();
		return (null == e ? void 0 : e.sessionToken) ? this.authJsClient.mintTransferToken(e.sessionToken) : null;
	}
	async logout() {
		await this.authJsClient.logout(), this.cache.removeAll();
	}
	hasSession() {
		var e;
		return !!(null === (e = this.cache.getSessionToken()) || void 0 === e ? void 0 : e.sessionToken);
	}
	getClaims() {
		return null;
	}
};
var Mu = class {
	resolveOnlineAccess(e) {
		if ("online" !== e.refreshTokenMode) return !1;
		if (!0 !== e.useRefreshTokens) throw new R("`refreshTokenMode: \"online\"` requires the refresh-token grant.", "Set `useRefreshTokens: true`.");
		if (!0 !== e.useDpop) throw new R("`refreshTokenMode: \"online\"` requires DPoP, which is missing or disabled.", "Set `useDpop: true` (DPoP is mandatory for online access).");
		return !0;
	}
	warnEnterpriseConnectConfig(e) {
		var t, n;
		if (!0 !== e.enterpriseConnect) return;
		const o = null === (t = e.authorizationParams) || void 0 === t ? void 0 : t.scope;
		(!0 === e.useRefreshTokens || "string" == typeof o && o.includes("offline_access")) && console.warn("Enterprise Connect issues no refresh token; `useRefreshTokens` and `offline_access` in `scope` have no effect."), null !== (n = e.authorizationParams) && void 0 !== n && n.organization && console.warn("Enterprise Connect resolves the organization from the email domain (Home Realm Discovery); a static `organization` breaks multi-customer setups.");
	}
	constructor(e) {
		let t, n;
		if (this.userCache = new Xe().enclosedCache, this.defaultOptions = {
			authorizationParams: { scope: "openid profile email" },
			useRefreshTokensFallback: !1,
			useFormData: !0,
			refreshTokenMode: "offline",
			anonymousSessionsCacheMode: "localStorage"
		}, this.onlineAccess = this.resolveOnlineAccess(e), this.warnEnterpriseConnectConfig(e), this.options = Object.assign(Object.assign(Object.assign({}, this.defaultOptions), e), { authorizationParams: Object.assign(Object.assign({}, this.defaultOptions.authorizationParams), e.authorizationParams) }), "undefined" != typeof window && (() => {
			if (!J()) throw new Error("For security reasons, `window.crypto` is required to run `auth0-spa-js`.");
			if (void 0 === J().subtle) throw new Error("\n      auth0-spa-js must run on a secure origin. See https://github.com/auth0/auth0-spa-js/blob/main/FAQ.md#why-do-i-get-auth0-spa-js-must-run-on-a-secure-origin for more information.\n    ");
		})(), this.lockManager = me(), e.cache && e.cacheLocation && console.warn("Both `cache` and `cacheLocation` options have been specified in the Auth0Client configuration; ignoring `cacheLocation` and using `cache`."), e.cache) n = e.cache;
		else {
			if (t = e.cacheLocation || _, !St(t)) throw new Error("Invalid cache location \"".concat(t, "\""));
			n = St(t)();
		}
		var o;
		this.httpTimeoutMs = e.httpTimeoutInSeconds ? 1e3 * e.httpTimeoutInSeconds : b, this.cookieStorage = !1 === e.legacySameSiteCookie ? at : ut, this.orgHintCookieName = (o = this.options.clientId, "auth0.".concat(o, ".organization_hint")), this.isAuthenticatedCookieName = ((e) => "auth0.".concat(e, ".is.authenticated"))(this.options.clientId), this.sessionCheckExpiryDays = e.sessionCheckExpiryDays || 1;
		const i = e.useCookiesForTransactions ? this.cookieStorage : lt;
		let r = "";
		var s;
		this.onlineAccess ? r = S : this.options.useRefreshTokens && (r = "offline_access"), this.scope = function(e, t) {
			for (var n = arguments.length, o = new Array(n > 2 ? n - 2 : 0), i = 2; i < n; i++) o[i - 2] = arguments[i];
			if ("object" != typeof e) return { [C]: Je(t, e, ...o) };
			let r = { [C]: Je(t, ...o) };
			return Object.keys(e).forEach((n) => {
				const i = e[n];
				r[n] = Je(t, i, ...o);
			}), r;
		}(this.options.authorizationParams.scope, "openid", r), this.transactionManager = new qe(i, this.options.clientId, this.options.cookieDomain), this.nowProvider = this.options.nowProvider || P, this.cacheManager = new Ge(n, n.allKeys ? void 0 : new bt(n, this.options.clientId), this.nowProvider), this.dpop = this.options.useDpop ? new Rt(this.options.clientId) : void 0, this.domainUrl = (s = this.options.domain, /^https?:\/\//.test(s) ? s : "https://".concat(s)), this.tokenIssuer = ((e, t) => e ? e.startsWith("https://") ? e : "https://".concat(e, "/") : "".concat(t, "/"))(this.options.issuer, this.domainUrl);
		const a = "".concat(this.domainUrl, "/me/"), c = this.createFetcher(Object.assign(Object.assign({}, this.options.useDpop && { dpopNonceId: "__auth0_my_account_api__" }), { getAccessToken: (e) => {
			var t;
			return this.getTokenSilently({
				authorizationParams: {
					scope: null === (t = null == e ? void 0 : e.scope) || void 0 === t ? void 0 : t.join(" "),
					audience: a
				},
				detailedResponse: !0
			});
		} }));
		this.myAccount = new It(c, a), this.authJsClient = new $c({
			domain: this.options.domain,
			clientId: this.options.clientId
		}), this.mfa = new bu(this.authJsClient.mfa, this), this.anonymous = new Nu(this.authJsClient.anonymous, this.options.clientId, this.options.anonymousSessionsCacheMode, this.lockManager), this.passkey = new Pu(this.authJsClient.passkey, this), "undefined" != typeof window && window.Worker && this.options.useRefreshTokens && t === _ && (this.options.workerUrl ? this.worker = new Worker(this.options.workerUrl) : this.worker = new vt(), this.worker.postMessage({
			type: "init",
			allowedBaseUrl: this.domainUrl
		}));
	}
	getConfiguration() {
		return Object.freeze({
			domain: this.options.domain,
			clientId: this.options.clientId
		});
	}
	_url(e) {
		const n = F(this.options.auth0Client || T, !0), o = encodeURIComponent(btoa(JSON.stringify(n)));
		return "".concat(this.domainUrl).concat(e, "&auth0Client=").concat(o);
	}
	_authorizeUrl(e) {
		return this._url("/authorize?".concat(V(e)));
	}
	async _verifyIdToken(e, t, n, o) {
		const i = await this.nowProvider();
		return Qe({
			iss: this.tokenIssuer,
			aud: this.options.clientId,
			id_token: e,
			nonce: t,
			organization: n,
			leeway: this.options.leeway,
			max_age: Y(null != o ? o : this.options.authorizationParams.max_age),
			now: i
		});
	}
	_processOrgHint(e) {
		e ? this.cookieStorage.save(this.orgHintCookieName, e, {
			daysUntilExpire: this.sessionCheckExpiryDays,
			cookieDomain: this.options.cookieDomain
		}) : this.cookieStorage.remove(this.orgHintCookieName, { cookieDomain: this.options.cookieDomain });
	}
	_extractSessionTransferToken(e) {
		return new URLSearchParams(window.location.search).get(e) || void 0;
	}
	_clearSessionTransferTokenFromUrl(e) {
		try {
			const t = new URL(window.location.href);
			t.searchParams.has(e) && (t.searchParams.delete(e), window.history.replaceState({}, "", t.toString()));
		} catch (e) {}
	}
	_applySessionTransferToken(e) {
		const t = this.options.sessionTransferTokenQueryParamName;
		if (!t || e.session_transfer_token) return e;
		const n = this._extractSessionTransferToken(t);
		return n ? (this._clearSessionTransferTokenFromUrl(t), Object.assign(Object.assign({}, e), { session_transfer_token: n })) : e;
	}
	async _applyAnonTransferToken(e) {
		const t = await this.anonymous.mintTransferToken();
		return t ? Object.assign(Object.assign({}, e), { anon_transfer_token: t }) : e;
	}
	async _prepareAuthorizeUrl(e, t, n) {
		var o;
		const i = H(D()), r = H(D()), s = D(), c = q(await X(s)), u = await (null === (o = this.dpop) || void 0 === o ? void 0 : o.calculateThumbprint()), l = ((e, t, n, o, i, r, s, a, c) => Object.assign(Object.assign(Object.assign({ client_id: e.clientId }, e.authorizationParams), n), {
			scope: De(t, n.scope, n.audience),
			response_type: "code",
			response_mode: a || "query",
			state: o,
			nonce: i,
			redirect_uri: s || e.authorizationParams.redirect_uri,
			code_challenge: r,
			code_challenge_method: "S256",
			dpop_jkt: c
		}))(this.options, this.scope, e, i, r, c, e.redirect_uri || this.options.authorizationParams.redirect_uri || n, null == t ? void 0 : t.response_mode, u), d = this._authorizeUrl(l);
		return {
			nonce: r,
			code_verifier: s,
			scope: l.scope,
			audience: l.audience || C,
			redirect_uri: l.redirect_uri,
			state: i,
			url: d,
			max_age: l.max_age
		};
	}
	async loginWithPopup(e, t) {
		var n;
		if (e = e || {}, !(t = t || {}).popup && (t.popup = ((e) => {
			const t = window.screenX + (window.innerWidth - 400) / 2, n = window.screenY + (window.innerHeight - 600) / 2;
			return window.open(e, "auth0:authorize:popup", "left=".concat(t, ",top=").concat(n, ",width=").concat(400, ",height=").concat(600, ",resizable,scrollbars=yes,status=1"));
		})(""), !t.popup)) throw new W();
		const o = await this._applyAnonTransferToken(this._applySessionTransferToken(e.authorizationParams || {})), i = await this._prepareAuthorizeUrl(o, { response_mode: "web_message" }, window.location.origin);
		t.popup.location.href = i.url;
		const r = await ((e, t) => new Promise((n, o) => {
			let i;
			const r = setInterval(() => {
				e.popup && e.popup.closed && (clearInterval(r), clearTimeout(s), window.removeEventListener("message", i, !1), o(new j(e.popup)));
			}, 1e3), s = setTimeout(() => {
				clearInterval(r), o(new O(e.popup)), window.removeEventListener("message", i, !1);
			}, 1e3 * (e.timeoutInSeconds || 60));
			i = function(a) {
				if (a.origin === t && a.data && "authorization_response" === a.data.type) {
					if (clearTimeout(s), clearInterval(r), window.removeEventListener("message", i, !1), !1 !== e.closePopup && e.popup.close(), a.data.response.error) return o(E.fromPayload(a.data.response));
					n(a.data.response);
				}
			}, window.addEventListener("message", i);
		}))(Object.assign(Object.assign({}, t), { timeoutInSeconds: t.timeoutInSeconds || this.options.authorizeTimeoutInSeconds || 60 }), new URL(i.url).origin);
		if (i.state !== r.state) throw new E("state_mismatch", "Invalid state");
		const s = (null === (n = e.authorizationParams) || void 0 === n ? void 0 : n.organization) || this.options.authorizationParams.organization;
		await this._requestToken({
			audience: i.audience,
			scope: i.scope,
			code_verifier: i.code_verifier,
			grant_type: "authorization_code",
			code: r.code,
			redirect_uri: i.redirect_uri
		}, {
			nonceIn: i.nonce,
			organization: s,
			max_age: i.max_age
		});
	}
	async getUser() {
		var e;
		if (await this._isSessionCeilingReached()) return;
		const t = await this._getIdTokenFromCache();
		return null === (e = null == t ? void 0 : t.decodedToken) || void 0 === e ? void 0 : e.user;
	}
	async getIdTokenClaims() {
		var e;
		if (await this._isSessionCeilingReached()) return;
		const t = await this._getIdTokenFromCache();
		return null === (e = null == t ? void 0 : t.decodedToken) || void 0 === e ? void 0 : e.claims;
	}
	async loginWithRedirect() {
		var t;
		const n = Tt(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}), o = n.openUrl, i = n.fragment, r = n.appState, s = e(n, [
			"openUrl",
			"fragment",
			"appState"
		]), a = (null === (t = s.authorizationParams) || void 0 === t ? void 0 : t.organization) || this.options.authorizationParams.organization, c = await this._applyAnonTransferToken(this._applySessionTransferToken(s.authorizationParams || {})), u = await this._prepareAuthorizeUrl(c), l = u.url, d = e(u, ["url"]);
		this.transactionManager.create(Object.assign(Object.assign(Object.assign({}, d), {
			appState: r,
			response_type: ht.Code
		}), a && { organization: a }));
		const h = i ? "".concat(l, "#").concat(i) : l;
		o ? await o(h) : window.location.assign(h);
	}
	async handleRedirectCallback() {
		const e = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : window.location.href).split("?").slice(1);
		if (0 === e.length) throw new Error("There are no query params available for parsing.");
		const t = this.transactionManager.get();
		if (!t) throw new E("missing_transaction", "Invalid state");
		this.transactionManager.remove();
		const n = ((e) => {
			e.indexOf("#") > -1 && (e = e.substring(0, e.indexOf("#")));
			const t = new URLSearchParams(e);
			return {
				state: t.get("state"),
				code: t.get("code") || void 0,
				connect_code: t.get("connect_code") || void 0,
				error: t.get("error") || void 0,
				error_description: t.get("error_description") || void 0
			};
		})(e.join(""));
		return t.response_type === ht.ConnectCode ? this._handleConnectAccountRedirectCallback(n, t) : this._handleLoginRedirectCallback(n, t);
	}
	async _handleLoginRedirectCallback(e, t) {
		const n = e.code, o = e.state, i = e.error, r = e.error_description;
		if (i) throw new A(i, r || i, o, t.appState);
		if (!t.code_verifier || t.state && t.state !== o) throw new E("state_mismatch", "Invalid state");
		const s = t.organization, a = t.nonce, c = t.redirect_uri;
		return await this._requestToken(Object.assign({
			audience: t.audience,
			scope: t.scope,
			code_verifier: t.code_verifier,
			grant_type: "authorization_code",
			code: n
		}, c ? { redirect_uri: c } : {}), {
			nonceIn: a,
			organization: s,
			max_age: t.max_age
		}), {
			appState: t.appState,
			response_type: ht.Code
		};
	}
	async _handleConnectAccountRedirectCallback(e, t) {
		const n = e.connect_code, o = e.state, i = e.error, r = e.error_description;
		if (i) throw new x(i, r || i, t.connection, o, t.appState);
		if (!n) throw new E("missing_connect_code", "Missing connect code");
		if (!(t.code_verifier && t.state && t.auth_session && t.redirect_uri && t.state === o)) throw new E("state_mismatch", "Invalid state");
		const s = await this.myAccount.completeAccount({
			auth_session: t.auth_session,
			connect_code: n,
			redirect_uri: t.redirect_uri,
			code_verifier: t.code_verifier
		});
		return Object.assign(Object.assign({}, s), {
			appState: t.appState,
			response_type: ht.ConnectCode
		});
	}
	async _maybeCreateAnonymousSession() {
		if (this.options.createAnonymousSessionOnFailedSilentAuth) {
			if (this.anonymous.hasSession()) return;
			try {
				await this.anonymous.getTokenSilently();
			} catch (e) {
				console.debug("[auth0-spa-js] Anonymous session creation failed", e);
			}
		}
	}
	async checkSession(e) {
		if (!this.cookieStorage.get(this.isAuthenticatedCookieName)) {
			if (!this.cookieStorage.get(_t)) return void await this._maybeCreateAnonymousSession();
			this.cookieStorage.save(this.isAuthenticatedCookieName, !0, {
				daysUntilExpire: this.sessionCheckExpiryDays,
				cookieDomain: this.options.cookieDomain
			}), this.cookieStorage.remove(_t);
		}
		try {
			await this.getTokenSilently(e);
		} catch (e) {
			e instanceof E && "login_required" === e.error && e.error_description !== k && await this._maybeCreateAnonymousSession();
		}
	}
	async getTokenSilently() {
		let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
		var t, n;
		const o = Object.assign(Object.assign({ cacheMode: "on" }, e), { authorizationParams: Object.assign(Object.assign(Object.assign({}, this.options.authorizationParams), e.authorizationParams), { scope: De(this.scope, null === (t = e.authorizationParams) || void 0 === t ? void 0 : t.scope, (null === (n = e.authorizationParams) || void 0 === n ? void 0 : n.audience) || this.options.authorizationParams.audience) }) }), i = await ((e, t) => {
			let n = ye[t];
			return n || (n = e().finally(() => {
				delete ye[t], n = null;
			}), ye[t] = n), n;
		})(() => this._getTokenSilently(o), "".concat(this.options.clientId, "::").concat(o.authorizationParams.audience, "::").concat(o.authorizationParams.scope, "::").concat(o.cacheMode));
		return e.detailedResponse ? i : null == i ? void 0 : i.access_token;
	}
	async _getTokenSilently(t) {
		const n = t.cacheMode, o = e(t, ["cacheMode"]);
		if (await this._isSessionCeilingReached()) return;
		if ("off" !== n) {
			const e = await this._getEntryFromCache({
				scope: o.authorizationParams.scope,
				audience: o.authorizationParams.audience || C,
				clientId: this.options.clientId,
				cacheMode: n
			});
			if (e) return e;
		}
		if ("cache-only" === n) return;
		const i = (r = this.options.clientId, s = o.authorizationParams.audience || "default", "".concat("auth0.lock.getTokenSilently", ".").concat(r, ".").concat(s));
		var r, s;
		try {
			return await this.lockManager.runWithLock(i, 5e3, async () => {
				if ("off" !== n) {
					const e = await this._getEntryFromCache({
						scope: o.authorizationParams.scope,
						audience: o.authorizationParams.audience || C,
						clientId: this.options.clientId
					});
					if (e) return e;
				}
				const e = this.options.useRefreshTokens ? await this._getTokenUsingRefreshToken(o) : await this._getTokenFromIFrame(o), t = e.id_token, i = e.token_type, r = e.access_token, s = e.oauthTokenScope, a = e.expires_in;
				return Object.assign(Object.assign({
					id_token: t,
					token_type: i,
					access_token: r
				}, s ? { scope: s } : null), { expires_in: a });
			});
		} catch (e) {
			if (this._isInteractiveError(e) && "popup" === this.options.interactiveErrorHandler) return await this._handleInteractiveErrorWithPopup(o);
			throw e;
		}
	}
	_isInteractiveError(e) {
		return e instanceof N || e instanceof E && this._isIframeMfaError(e);
	}
	_isIframeMfaError(e) {
		return "login_required" === e.error && e.error_description === k;
	}
	async _handleInteractiveErrorWithPopup(e) {
		try {
			await this.loginWithPopup({ authorizationParams: e.authorizationParams });
			const t = await this._getEntryFromCache({
				scope: e.authorizationParams.scope,
				audience: e.authorizationParams.audience || C,
				clientId: this.options.clientId
			});
			if (!t) throw new E("interactive_handler_cache_miss", "Token not found in cache after interactive authentication");
			return t;
		} catch (e) {
			throw e;
		}
	}
	async getTokenWithPopup() {
		let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
		var n, o;
		const i = Object.assign(Object.assign({}, e), { authorizationParams: Object.assign(Object.assign(Object.assign({}, this.options.authorizationParams), e.authorizationParams), { scope: De(this.scope, null === (n = e.authorizationParams) || void 0 === n ? void 0 : n.scope, (null === (o = e.authorizationParams) || void 0 === o ? void 0 : o.audience) || this.options.authorizationParams.audience) }) });
		t = Object.assign(Object.assign({}, v), t), await this.loginWithPopup(i, t);
		return (await this.cacheManager.get(new Fe({
			scope: i.authorizationParams.scope,
			audience: i.authorizationParams.audience || C,
			clientId: this.options.clientId
		}), void 0, this.options.useMrrt)).access_token;
	}
	async isAuthenticated() {
		return !!await this.getUser();
	}
	_buildLogoutUrl(t) {
		null !== t.clientId ? t.clientId = t.clientId || this.options.clientId : delete t.clientId;
		const n = t.logoutParams || {}, o = n.federated, i = e(n, ["federated"]), r = o ? "&federated" : "";
		return this._url("/v2/logout?".concat(V(Object.assign({ clientId: t.clientId }, i)))) + r;
	}
	async revokeRefreshToken() {
		let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
		if (!this.options.useRefreshTokens) return;
		const t = e.audience || this.options.authorizationParams.audience || C, n = await this.cacheManager.getRefreshTokensByAudience(t, this.options.clientId);
		await async function(e, t) {
			let n = e.baseUrl, o = e.timeout, i = e.auth0Client, r = e.useFormData, s = e.refreshTokens, a = e.audience, c = e.client_id, u = e.onRefreshTokenRevoked;
			const l = o || b, d = "refresh_token", h = "".concat(n, "/oauth/revoke"), p = {
				"Content-Type": r ? "application/x-www-form-urlencoded" : "application/json",
				"Auth0-Client": btoa(JSON.stringify(F(i || T)))
			};
			if (t) {
				const e = {
					client_id: c,
					token_type_hint: d
				}, n = r ? V(e) : JSON.stringify(e);
				try {
					return await Me({
						type: "revoke",
						timeout: l,
						fetchUrl: h,
						fetchOptions: {
							method: "POST",
							body: n,
							headers: p
						},
						useFormData: r,
						auth: { audience: null != a ? a : C }
					}, t);
				} catch (e) {
					throw new E("revoke_error", e.message);
				}
			}
			for (const e of s) {
				const t = {
					client_id: c,
					token_type_hint: d,
					token: e
				}, o = await Ue(h, {
					method: "POST",
					body: r ? V(t) : JSON.stringify(t),
					headers: p
				}, l);
				if (!o.ok) {
					let e, t;
					try {
						var f = JSON.parse(await o.text());
						e = f.error, t = f.error_description;
					} catch (e) {}
					throw new E(e || "revoke_error", t || "HTTP error ".concat(o.status));
				}
				await (null == u ? void 0 : u(e));
			}
		}({
			baseUrl: this.domainUrl,
			timeout: this.httpTimeoutMs,
			auth0Client: this.options.auth0Client,
			useFormData: this.options.useFormData,
			client_id: this.options.clientId,
			refreshTokens: n,
			audience: t,
			onRefreshTokenRevoked: (e) => this.cacheManager.stripRefreshToken(e)
		}, this.worker), this.onlineAccess && await this._clearLocalSession();
	}
	async logout() {
		let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
		var n;
		this.options.enterpriseConnect && !0 !== (null === (n = t.logoutParams) || void 0 === n ? void 0 : n.federated) && console.warn("Enterprise Connect logout without `federated: true` leaves the enterprise IdP session alive; the next login may silently reuse the previous user.");
		const o = Tt(t), i = o.openUrl, r = e(o, ["openUrl"]);
		await this._clearLocalSession(t.clientId);
		const s = this._buildLogoutUrl(r);
		i ? await i(s) : !1 !== i && window.location.assign(s);
	}
	async _getTokenFromIFrame(e) {
		const t = (n = this.options.clientId, "".concat("auth0.lock.getTokenFromIFrame", ".").concat(n));
		var n;
		try {
			return await this.lockManager.runWithLock(t, 5e3, async () => {
				const t = Object.assign(Object.assign({}, e.authorizationParams), { prompt: "none" }), n = this.cookieStorage.get(this.orgHintCookieName);
				n && !t.organization && (t.organization = n);
				const o = await this._prepareAuthorizeUrl(t, { response_mode: "web_message" }, window.location.origin), i = o.url, r = o.state, s = o.nonce, a = o.code_verifier, c = o.redirect_uri, u = o.scope, l = o.audience, d = o.max_age;
				if (window.crossOriginIsolated) throw new E("login_required", "The application is running in a Cross-Origin Isolated context, silently retrieving a token without refresh token is not possible.");
				const h = e.timeoutInSeconds || this.options.authorizeTimeoutInSeconds;
				let p;
				try {
					p = new URL(this.domainUrl).origin;
				} catch (e) {
					p = this.domainUrl;
				}
				const f = await function(e, t) {
					let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 60;
					return new Promise((o, i) => {
						const r = window.document.createElement("iframe");
						r.setAttribute("width", "0"), r.setAttribute("height", "0"), r.style.display = "none";
						const s = () => {
							window.document.body.contains(r) && (window.document.body.removeChild(r), window.removeEventListener("message", a, !1));
						};
						let a;
						const c = setTimeout(() => {
							i(new I()), s();
						}, 1e3 * n);
						a = function(e) {
							if (e.origin != t) return;
							if (!e.data || "authorization_response" !== e.data.type) return;
							const n = e.source;
							n && n.close(), e.data.response.error ? i(E.fromPayload(e.data.response)) : o(e.data.response), clearTimeout(c), window.removeEventListener("message", a, !1), setTimeout(s, 2e3);
						}, window.addEventListener("message", a, !1), window.document.body.appendChild(r), r.setAttribute("src", e);
					});
				}(i, p, h);
				if (r !== f.state) throw new E("state_mismatch", "Invalid state");
				const m = await this._requestToken(Object.assign(Object.assign({}, e.authorizationParams), {
					code_verifier: a,
					code: f.code,
					grant_type: "authorization_code",
					redirect_uri: c,
					timeout: e.authorizationParams.timeout || this.httpTimeoutMs
				}), {
					nonceIn: s,
					organization: t.organization,
					max_age: d
				});
				return Object.assign(Object.assign({}, m), {
					scope: u,
					oauthTokenScope: m.scope,
					audience: l
				});
			});
		} catch (e) {
			if ("login_required" === e.error) e instanceof E && this._isIframeMfaError(e) && "popup" === this.options.interactiveErrorHandler || this.logout({ openUrl: !1 });
			throw e;
		}
	}
	async _getTokenUsingRefreshToken(e) {
		const t = await this.cacheManager.get(new Fe({
			scope: e.authorizationParams.scope,
			audience: e.authorizationParams.audience || C,
			clientId: this.options.clientId
		}), void 0, this.options.useMrrt);
		if (!(t && t.refresh_token || this.worker)) {
			if (this.options.useRefreshTokensFallback) return await this._getTokenFromIFrame(e);
			throw new U(e.authorizationParams.audience || C, e.authorizationParams.scope);
		}
		const n = e.authorizationParams.redirect_uri || this.options.authorizationParams.redirect_uri || window.location.origin, o = "number" == typeof e.timeoutInSeconds ? 1e3 * e.timeoutInSeconds : null, i = ((e, t, n, o) => {
			var i;
			if (e && n && o) {
				if (t.audience !== n) return t.scope;
				const e = o.split(" "), r = (null === (i = t.scope) || void 0 === i ? void 0 : i.split(" ")) || [], s = r.every((t) => e.includes(t));
				return e.length >= r.length && s ? o : t.scope;
			}
			return t.scope;
		})(this.options.useMrrt, e.authorizationParams, null == t ? void 0 : t.audience, null == t ? void 0 : t.scope);
		try {
			const u = await this._requestToken(Object.assign(Object.assign(Object.assign({}, e.authorizationParams), {
				grant_type: "refresh_token",
				refresh_token: t && t.refresh_token,
				redirect_uri: n
			}), o && { timeout: o }), { scopesToRequest: i });
			if (await this._propagateRotatedRefreshToken(null == t ? void 0 : t.refresh_token, u.refresh_token), this.options.useMrrt) {
				if (r = null == t ? void 0 : t.audience, s = null == t ? void 0 : t.scope, a = e.authorizationParams.audience, c = e.authorizationParams.scope, r !== a || !((e, t) => {
					const n = (null == t ? void 0 : t.split(" ")) || [];
					return ((null == e ? void 0 : e.split(" ")) || []).every((e) => n.includes(e));
				})(c, s)) {
					const t = Pt(i, u.scope, this.onlineAccess);
					if (t) {
						if (this.options.useRefreshTokensFallback) return await this._getTokenFromIFrame(e);
						throw await this.cacheManager.remove(this.options.clientId, e.authorizationParams.audience || C, e.authorizationParams.scope), new L(e.authorizationParams.audience || "default", t);
					}
				}
			}
			return Object.assign(Object.assign({}, u), {
				scope: e.authorizationParams.scope,
				oauthTokenScope: u.scope,
				audience: e.authorizationParams.audience || C
			});
		} catch (t) {
			if (t.message) {
				if (t.message.includes("user is blocked")) throw await this.logout({ openUrl: !1 }), t;
				if ((t.message.includes("Missing Refresh Token") || t.message.includes("invalid refresh token")) && this.options.useRefreshTokensFallback) return await this._getTokenFromIFrame(e);
			}
			throw t;
		}
		var r, s, a, c;
	}
	async _propagateRotatedRefreshToken(e, t) {
		!this.onlineAccess && t && e && await this.cacheManager.updateEntry(e, t, this.options.clientId, this.options.useMrrt);
	}
	async _saveEntryInCache(t) {
		const n = t.decodedToken.claims, o = n.session_expiry, i = n.iat;
		if (void 0 !== o) {
			if ("number" != typeof o) throw new E("invalid_token", "Invalid session_expiry: value must be a number.");
			if (o >= 1e10) throw new E("invalid_token", "Invalid session_expiry: value appears to be in milliseconds; expected a Unix timestamp in seconds.");
			if (void 0 === i || o <= i) throw new E("invalid_token", "Invalid session_expiry: session ceiling is before or at the token issue time.");
		}
		const r = t.id_token, s = t.decodedToken, a = e(t, ["id_token", "decodedToken"]);
		this.userCache.set(Ze, {
			id_token: r,
			decodedToken: s
		}), await this.cacheManager.setIdToken(this.options.clientId, t.id_token, t.decodedToken), await this.cacheManager.set(a);
	}
	async _clearLocalSession() {
		let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.options.clientId;
		var t;
		null === e ? await this.cacheManager.clear() : await this.cacheManager.clear(e), this.cookieStorage.remove(this.orgHintCookieName, { cookieDomain: this.options.cookieDomain }), this.cookieStorage.remove(this.isAuthenticatedCookieName, { cookieDomain: this.options.cookieDomain }), this.userCache.remove(Ze);
		try {
			await (null === (t = this.dpop) || void 0 === t ? void 0 : t.clear());
		} catch (e) {}
		if (this.worker) try {
			await Me({ type: "clear" }, this.worker);
		} catch (e) {}
	}
	async _isSessionCeilingReached() {
		var e, t;
		const n = this.userCache.get(Ze), o = null != n ? n : await this.cacheManager.getIdToken(new Fe({ clientId: this.options.clientId })), i = null === (t = null === (e = null == o ? void 0 : o.decodedToken) || void 0 === e ? void 0 : e.claims) || void 0 === t ? void 0 : t.session_expiry;
		if (void 0 === i) return !1;
		const r = await this.nowProvider();
		return Math.floor(r / 1e3) >= i - 30 && (await this._clearLocalSession(), !0);
	}
	async _getIdTokenFromCache() {
		const e = this.options.authorizationParams.audience || C, t = this.scope[e], n = await this.cacheManager.getIdToken(new Fe({
			clientId: this.options.clientId,
			audience: e,
			scope: t
		})), o = this.userCache.get(Ze);
		return n && n.id_token === (null == o ? void 0 : o.id_token) ? o : (this.userCache.set(Ze, n), n);
	}
	async _getEntryFromCache(e) {
		let t = e.scope, n = e.audience, o = e.clientId, i = e.cacheMode;
		const r = await this.cacheManager.get(new Fe({
			scope: t,
			audience: n,
			clientId: o
		}), 60, this.options.useMrrt, i);
		if (r && r.access_token) {
			const e = r.token_type, t = r.access_token, n = r.oauthTokenScope, o = r.expires_in, i = await this._getIdTokenFromCache();
			return i && Object.assign(Object.assign({
				id_token: i.id_token,
				token_type: e || "Bearer",
				access_token: t
			}, n ? { scope: n } : null), { expires_in: o });
		}
	}
	_storeMfaContext(e, t, n) {
		e instanceof N && this.mfa.setMFAAuthDetails(e.mfa_token, t, n, e.mfa_requirements);
	}
	async _requestToken(e, t) {
		var n, o, i, r, s, a;
		const c = t || {}, u = c.nonceIn, l = c.organization, d = c.scopesToRequest, h = c.max_age;
		try {
			const t = await ze(Object.assign(Object.assign({
				baseUrl: this.domainUrl,
				client_id: this.options.clientId,
				auth0Client: this.options.auth0Client,
				useFormData: this.options.useFormData,
				timeout: this.httpTimeoutMs,
				useMrrt: this.options.useMrrt,
				dpop: this.dpop,
				preserveRefreshToken: this.onlineAccess
			}, e), { scope: d || e.scope }), this.worker);
			let c = await this._verifyIdToken(t.id_token, u, l, h);
			if ("authorization_code" === e.grant_type) {
				const e = await this._getIdTokenFromCache();
				null !== (o = null === (n = null == e ? void 0 : e.decodedToken) || void 0 === n ? void 0 : n.claims) && void 0 !== o && o.sub && e.decodedToken.claims.sub !== c.claims.sub && (await this.cacheManager.clear(this.options.clientId), this.userCache.remove(Ze));
			}
			if ("authorization_code" !== e.grant_type) {
				const e = await this._getIdTokenFromCache(), t = null === (r = null === (i = null == e ? void 0 : e.decodedToken) || void 0 === i ? void 0 : i.claims) || void 0 === r ? void 0 : r.session_expiry;
				void 0 !== t && (c = Object.assign(Object.assign({}, c), { claims: Object.assign(Object.assign({}, c.claims), { session_expiry: t }) }));
			}
			return !t.refresh_token && this.onlineAccess && (t.refresh_token = null !== (s = e.refresh_token) && void 0 !== s ? s : null === (a = await this.cacheManager.get(new Fe({
				scope: d || e.scope,
				audience: e.audience || C,
				clientId: this.options.clientId
			}), void 0, this.options.useMrrt)) || void 0 === a ? void 0 : a.refresh_token), await this._saveEntryInCache(Object.assign(Object.assign(Object.assign(Object.assign({}, t), {
				decodedToken: c,
				scope: e.scope,
				audience: e.audience || C
			}), t.scope ? { oauthTokenScope: t.scope } : null), { client_id: this.options.clientId })), this.cookieStorage.save(this.isAuthenticatedCookieName, !0, {
				daysUntilExpire: this.sessionCheckExpiryDays,
				cookieDomain: this.options.cookieDomain
			}), this._processOrgHint(l || c.claims.org_id), Object.assign(Object.assign({}, t), { decodedToken: c });
		} catch (t) {
			throw "authorization_code" !== e.grant_type && this._storeMfaContext(t, d || e.scope, e.audience), t;
		}
	}
	_buildTokenExchangeParams(e) {
		return Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, e), {
			grant_type: "urn:ietf:params:oauth:grant-type:token-exchange",
			subject_token: e.subject_token,
			subject_token_type: e.subject_token_type
		}), e.actor_token && { actor_token: e.actor_token }), e.actor_token_type && { actor_token_type: e.actor_token_type }), {
			scope: De(this.scope, e.scope, e.audience || this.options.authorizationParams.audience),
			audience: e.audience || this.options.authorizationParams.audience,
			organization: e.organization || this.options.authorizationParams.organization
		});
	}
	async loginWithCustomTokenExchange(e) {
		const t = this._buildTokenExchangeParams(e);
		return this._requestToken(t, { organization: t.organization });
	}
	async customTokenExchange(e) {
		const t = this._buildTokenExchangeParams(e);
		try {
			const n = await ze(Object.assign(Object.assign({}, t), {
				baseUrl: this.domainUrl,
				client_id: this.options.clientId,
				auth0Client: this.options.auth0Client,
				useFormData: this.options.useFormData,
				timeout: this.httpTimeoutMs,
				dpop: this.dpop
			}), this.worker, !0);
			return n.id_token && await this._verifyIdToken(n.id_token, void 0, e.organization), n;
		} catch (e) {
			throw this._storeMfaContext(e, t.scope, t.audience), e;
		}
	}
	async exchangeToken(e) {
		return this.loginWithCustomTokenExchange(e);
	}
	_assertDpop(e) {
		if (!e) throw new Error("`useDpop` option must be enabled before using DPoP.");
	}
	getDpopNonce(e) {
		return this._assertDpop(this.dpop), this.dpop.getNonce(e);
	}
	setDpopNonce(e, t) {
		return this._assertDpop(this.dpop), this.dpop.setNonce(e, t);
	}
	generateDpopProof(e) {
		return this._assertDpop(this.dpop), this.dpop.generateProof(e);
	}
	createFetcher() {
		let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
		return new xt(e, {
			isDpopEnabled: () => !!this.options.useDpop,
			getAccessToken: (e) => {
				var t;
				return this.getTokenSilently({
					authorizationParams: {
						scope: null === (t = null == e ? void 0 : e.scope) || void 0 === t ? void 0 : t.join(" "),
						audience: null == e ? void 0 : e.audience
					},
					detailedResponse: !0
				});
			},
			getDpopNonce: () => this.getDpopNonce(e.dpopNonceId),
			setDpopNonce: (t) => this.setDpopNonce(t, e.dpopNonceId),
			generateDpopProof: (e) => this.generateDpopProof(e)
		});
	}
	async connectAccountWithRedirect(e) {
		const t = e.openUrl, n = e.appState, o = e.connection, i = e.scopes, r = e.authorization_params, s = e.redirectUri, a = void 0 === s ? this.options.authorizationParams.redirect_uri || window.location.origin : s;
		if (!o) throw new Error("connection is required");
		const c = H(D()), u = D(), d = q(await X(u)), h = await this.myAccount.connectAccount({
			connection: o,
			scopes: i,
			redirect_uri: a,
			state: c,
			code_challenge: d,
			code_challenge_method: "S256",
			authorization_params: r
		}), p = h.connect_uri, f = h.connect_params, m = h.auth_session;
		this.transactionManager.create({
			state: c,
			code_verifier: u,
			auth_session: m,
			redirect_uri: a,
			appState: n,
			connection: o,
			response_type: ht.ConnectCode
		});
		const y = new URL(p);
		y.searchParams.set("ticket", f.ticket), t ? await t(y.toString()) : window.location.assign(y);
	}
	async _requestTokenForPasskey(e) {
		var t;
		const n = e.audience || this.options.authorizationParams.audience, o = e.organization || this.options.authorizationParams.organization, i = !!e.verification && Object.keys(e.verification).length > 0;
		try {
			return await this._requestToken(Object.assign(Object.assign(Object.assign(Object.assign({
				grant_type: "urn:okta:params:oauth:grant-type:webauthn",
				auth_session: e.authSession,
				authn_response: e.credential
			}, e.realm && { realm: e.realm }), o && { organization: o }), i && { verification: e.verification }), {
				scope: De(this.scope, e.scope, n),
				audience: n
			}));
		} catch (e) {
			if (e instanceof E && (null === (t = e.data) || void 0 === t ? void 0 : t.auth_session) && e.data.verification_required) throw new dc(e.error_description, {
				error: e.error,
				error_description: e.error_description,
				auth_session: e.data.auth_session,
				verification_required: e.data.verification_required
			});
			throw e;
		}
	}
	async _requestTokenForMfa(t, n) {
		const o = t.mfaToken, i = e(t, ["mfaToken"]), r = await this.cacheManager.get(new Fe({
			scope: i.scope,
			audience: i.audience || C,
			clientId: this.options.clientId
		}), void 0, this.options.useMrrt), s = await this._requestToken(Object.assign(Object.assign({}, i), { mfa_token: o }), n);
		return await this._propagateRotatedRefreshToken(null == r ? void 0 : r.refresh_token, s.refresh_token), s;
	}
};
function Uu(e, t, n) {
	var o;
	return async function(e, t, n) {
		const o = t.toLowerCase(), i = e.replace(/^https?:\/\//, ""), r = "".concat(i, "|").concat(o), s = hu.get(r);
		if (void 0 !== s) return s;
		try {
			var a;
			const e = new URL("https://".concat(i, "/.well-known/webfinger"));
			e.searchParams.set("resource", "urn:auth0:discovery:domain:".concat(o)), e.searchParams.set("rel", "http://openid.net/specs/connect/1.0/issuer");
			let t = null !== (a = null == n ? void 0 : n.customFetch) && void 0 !== a ? a : globalThis.fetch;
			null != n && n.telemetry && !1 !== n.telemetry.enabled && (t = tc(t, n.telemetry));
			const s = await t(e.toString());
			return s.ok ? (hu.set(r, !0), !0) : 404 === s.status ? (hu.set(r, !1, 15e3), !1) : 429 === s.status && (console.warn("[Auth0] isFederatedDomain: rate limit hit (429)"), !1);
		} catch (e) {
			return !1;
		}
	}(e.replace(/^https?:\/\//i, "").toLowerCase(), t.toLowerCase(), Object.assign(Object.assign({}, n), { telemetry: null !== (o = null == n ? void 0 : n.telemetry) && void 0 !== o ? o : T }));
}
// node_modules/@auth0/auth0-angular/fesm2022/auth0-auth0-angular.mjs
var useragent = {
	name: "@auth0/auth0-angular",
	version: "2.4.0"
};
var Auth0ClientFactory = class {
	static createClient(configFactory) {
		const config = configFactory.get();
		if (!config) throw new Error("Configuration must be specified either through AuthModule.forRoot or through AuthClientConfig.set");
		return new Mu({
			...config,
			auth0Client: {
				name: useragent.name,
				version: useragent.version,
				env: { "angular/core": VERSION.full }
			}
		});
	}
};
var Auth0ClientService = new InjectionToken("auth0.client");
/**
* A custom type guard to help identify route definitions that are actually HttpInterceptorRouteConfig types.
*
* @param def The route definition type
*/
function isHttpInterceptorRouteConfig(def) {
	return typeof def !== "string";
}
/**
* Injection token for accessing configuration.
*
* @usageNotes
*
* Use the `Inject` decorator to access the configuration from a service or component:
*
* ```
* class MyService(@Inject(AuthConfigService) config: AuthConfig) {}
* ```
*/
var AuthConfigService = new InjectionToken("auth0-angular.config");
/**
* Gets and sets configuration for the internal Auth0 client. This can be
* used to provide configuration outside of using AuthModule.forRoot, i.e. from
* a factory provided by APP_INITIALIZER.
*
* @usage
*
* ```js
* // app.module.ts
* // ---------------------------
* import { AuthModule, AuthClientConfig } from '@auth0/auth0-angular';
*
* // Provide an initializer function that returns a Promise
* function configInitializer(
*   http: HttpClient,
*   config: AuthClientConfig
* ) {
*   return () =>
*     http
*       .get('/config')
*       .toPromise()
*       .then((loadedConfig: any) => config.set(loadedConfig));   // Set the config that was loaded asynchronously here
* }
*
* // Provide APP_INITIALIZER with this function. Note that there is no config passed to AuthModule.forRoot
* imports: [
*   // other imports..
*
*   HttpClientModule,
*   AuthModule.forRoot(),   //<- don't pass any config here
* ],
* providers: [
*   {
*     provide: APP_INITIALIZER,
*     useFactory: configInitializer,    // <- pass your initializer function here
*     deps: [HttpClient, AuthClientConfig],
*     multi: true,
*   },
* ],
* ```
*
*/
var AuthClientConfig = class AuthClientConfig {
	constructor(config) {
		if (config) this.set(config);
	}
	/**
	* Sets configuration to be read by other consumers of the service (see usage notes)
	*
	* @param config The configuration to set
	*/
	set(config) {
		this.config = config;
	}
	/**
	* Gets the config that has been set by other consumers of the service
	*/
	get() {
		return this.config;
	}
	static {
		this.ɵfac = function AuthClientConfig_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || AuthClientConfig)(ɵɵinject(AuthConfigService, 8));
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
			token: AuthClientConfig,
			factory: AuthClientConfig.ɵfac,
			providedIn: "root"
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AuthClientConfig, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [{
		type: void 0,
		decorators: [{ type: Optional }, {
			type: Inject,
			args: [AuthConfigService]
		}]
	}], null);
})();
var AbstractNavigator = class AbstractNavigator {
	constructor(location, injector) {
		this.location = location;
		try {
			this.router = injector.get(Router);
		} catch {}
	}
	/**
	* Navigates to the specified url. The router will be used if one is available, otherwise it falls back
	* to `window.history.replaceState`.
	*
	* @param url The url to navigate to
	*/
	navigateByUrl(url) {
		if (this.router) {
			this.router.navigateByUrl(url);
			return;
		}
		this.location.replaceState(url);
	}
	static {
		this.ɵfac = function AbstractNavigator_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || AbstractNavigator)(ɵɵinject(Location), ɵɵinject(Injector));
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
			token: AbstractNavigator,
			factory: AbstractNavigator.ɵfac,
			providedIn: "root"
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AbstractNavigator, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [{ type: Location }, { type: Injector }], null);
})();
/**
* Tracks the Authentication State for the SDK
*/
var AuthState = class AuthState {
	constructor(auth0Client) {
		this.auth0Client = auth0Client;
		this.isLoadingSubject$ = new BehaviorSubject(true);
		this.refresh$ = new Subject();
		this.accessToken$ = new ReplaySubject(1);
		this.errorSubject$ = new ReplaySubject(1);
		/**
		* Emits boolean values indicating the loading state of the SDK.
		*/
		this.isLoading$ = this.isLoadingSubject$.asObservable();
		/**
		* Trigger used to pull User information from the Auth0Client.
		* Triggers when the access token has changed.
		*/
		this.accessTokenTrigger$ = this.accessToken$.pipe(scan((acc, current) => ({
			previous: acc.current,
			current
		}), {
			current: null,
			previous: null
		}), filter(({ previous, current }) => previous !== current));
		/**
		* Trigger used to pull User information from the Auth0Client.
		* Triggers when an event occurs that needs to retrigger the User Profile information.
		* Events: Login, Access Token change and Logout
		*/
		this.isAuthenticatedTrigger$ = this.isLoading$.pipe(filter((loading) => !loading), distinctUntilChanged(), switchMap(() => merge(defer(() => this.auth0Client.isAuthenticated()), this.accessTokenTrigger$.pipe(mergeMap(() => this.auth0Client.isAuthenticated())), this.refresh$.pipe(mergeMap(() => this.auth0Client.isAuthenticated())))));
		/**
		* Emits boolean values indicating the authentication state of the user. If `true`, it means a user has authenticated.
		* This depends on the value of `isLoading$`, so there is no need to manually check the loading state of the SDK.
		*/
		this.isAuthenticated$ = this.isAuthenticatedTrigger$.pipe(distinctUntilChanged(), shareReplay(1));
		/**
		* Emits details about the authenticated user, or null if not authenticated.
		*/
		this.user$ = this.isAuthenticatedTrigger$.pipe(concatMap((authenticated) => authenticated ? this.auth0Client.getUser() : of(null)), distinctUntilChanged());
		/**
		* Emits ID token claims when authenticated, or null if not authenticated.
		*/
		this.idTokenClaims$ = this.isAuthenticatedTrigger$.pipe(concatMap((authenticated) => authenticated ? this.auth0Client.getIdTokenClaims() : of(null)));
		/**
		* Emits errors that occur during login, or when checking for an active session on startup.
		*/
		this.error$ = this.errorSubject$.asObservable();
	}
	/**
	* Update the isLoading state using the provided value
	*
	* @param isLoading The new value for isLoading
	*/
	setIsLoading(isLoading) {
		this.isLoadingSubject$.next(isLoading);
	}
	/**
	* Refresh the state to ensure the `isAuthenticated`, `user$` and `idTokenClaims$`
	* reflect the most up-to-date values from  Auth0Client.
	*/
	refresh() {
		this.refresh$.next();
	}
	/**
	* Update the access token, doing so will also refresh the state.
	*
	* @param accessToken The new Access Token
	*/
	setAccessToken(accessToken) {
		this.accessToken$.next(accessToken);
	}
	/**
	* Emits the error in the `error$` observable.
	*
	* @param error The new error
	*/
	setError(error) {
		this.errorSubject$.next(error);
	}
	static {
		this.ɵfac = function AuthState_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || AuthState)(ɵɵinject(Auth0ClientService));
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
			token: AuthState,
			factory: AuthState.ɵfac,
			providedIn: "root"
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AuthState, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [{
		type: Mu,
		decorators: [{
			type: Inject,
			args: [Auth0ClientService]
		}]
	}], null);
})();
var AuthService = class AuthService {
	constructor(auth0Client, configFactory, navigator, authState) {
		this.auth0Client = auth0Client;
		this.configFactory = configFactory;
		this.navigator = navigator;
		this.authState = authState;
		this.appStateSubject$ = new ReplaySubject(1);
		this.ngUnsubscribe$ = new Subject();
		/**
		* Emits boolean values indicating the loading state of the SDK.
		*/
		this.isLoading$ = this.authState.isLoading$;
		/**
		* Emits boolean values indicating the authentication state of the user. If `true`, it means a user has authenticated.
		* This depends on the value of `isLoading$`, so there is no need to manually check the loading state of the SDK.
		*/
		this.isAuthenticated$ = this.authState.isAuthenticated$;
		/**
		* Emits details about the authenticated user, or null if not authenticated.
		*/
		this.user$ = this.authState.user$;
		/**
		* Emits ID token claims when authenticated, or null if not authenticated.
		*/
		this.idTokenClaims$ = this.authState.idTokenClaims$;
		/**
		* Emits errors that occur during login, or when checking for an active session on startup.
		*/
		this.error$ = this.authState.error$;
		/**
		* Emits the value (if any) that was passed to the `loginWithRedirect` method call
		* but only **after** `handleRedirectCallback` is first called
		*/
		this.appState$ = this.appStateSubject$.asObservable();
		/**
		* Provides MFA (Multi-Factor Authentication) operations as Observables.
		*
		* These methods are available after `getAccessTokenSilently` throws an `MfaRequiredError`.
		* Use the `mfa_token` from the error to call these methods.
		*/
		this.mfa = {
			getAuthenticators: (mfaToken) => from(this.auth0Client.mfa.getAuthenticators(mfaToken)),
			enroll: (params) => from(this.auth0Client.mfa.enroll(params)),
			challenge: (params) => from(this.auth0Client.mfa.challenge(params)),
			getEnrollmentFactors: (mfaToken) => from(this.auth0Client.mfa.getEnrollmentFactors(mfaToken)),
			verify: (params) => from(this.auth0Client.mfa.verify(params))
		};
		/**
		* Provides Passkey (WebAuthn) authentication as Observables.
		*
		* `signup`, `continueSignup` and `login` handle the full WebAuthn
		* challenge-response flow internally. `getSignupChallenge`,
		* `getLoginChallenge` and `getTokenWithPasskey` are granular APIs that let
		* the app run the WebAuthn ceremony itself.
		*
		* Methods that return tokens update the authentication state on success to
		* ensure consistency with the standard authentication flows. The challenge
		* methods do not change the authentication state.
		*/
		this.passkey = {
			signup: (options) => of(this.auth0Client).pipe(concatMap((client) => client.passkey.signup(options)), tap((tokenResponse) => {
				if (tokenResponse.access_token) this.authState.setAccessToken(tokenResponse.access_token);
			}), catchError((error) => {
				this.authState.setError(error);
				this.authState.refresh();
				return throwError(error);
			})),
			continueSignup: (verification) => of(this.auth0Client).pipe(concatMap((client) => client.passkey.continueSignup(verification)), tap((tokenResponse) => {
				if (tokenResponse.access_token) this.authState.setAccessToken(tokenResponse.access_token);
			}), catchError((error) => {
				this.authState.setError(error);
				this.authState.refresh();
				return throwError(error);
			})),
			login: (options) => of(this.auth0Client).pipe(concatMap((client) => client.passkey.login(options)), tap((tokenResponse) => {
				if (tokenResponse.access_token) this.authState.setAccessToken(tokenResponse.access_token);
			}), catchError((error) => {
				this.authState.setError(error);
				this.authState.refresh();
				return throwError(error);
			})),
			getSignupChallenge: (options) => of(this.auth0Client).pipe(concatMap((client) => client.passkey.getSignupChallenge(options)), catchError((error) => {
				this.authState.setError(error);
				return throwError(error);
			})),
			getLoginChallenge: (options) => of(this.auth0Client).pipe(concatMap((client) => client.passkey.getLoginChallenge(options)), catchError((error) => {
				this.authState.setError(error);
				return throwError(error);
			})),
			getTokenWithPasskey: (options) => of(this.auth0Client).pipe(concatMap((client) => client.passkey.getTokenWithPasskey(options)), tap((tokenResponse) => {
				if (tokenResponse.access_token) this.authState.setAccessToken(tokenResponse.access_token);
			}), catchError((error) => {
				this.authState.setError(error);
				this.authState.refresh();
				return throwError(error);
			}))
		};
		/**
		* Provides MyAccount API operations as Observables.
		*
		* Allows the authenticated user to list, enroll, update, and delete their
		* authentication methods, and to read and update their profile. Requires an
		* access token with the appropriate
		* `read/create/update/delete:me:authentication_methods` scopes, and
		* `read:me:profile` / `update:me:profile` for the profile methods.
		*/
		this.myAccount = {
			getFactors: () => from(this.auth0Client.myAccount.getFactors()),
			getAuthenticationMethods: (type) => from(this.auth0Client.myAccount.getAuthenticationMethods(type)),
			getAuthenticationMethod: (id) => from(this.auth0Client.myAccount.getAuthenticationMethod(id)),
			deleteAuthenticationMethod: (id) => from(this.auth0Client.myAccount.deleteAuthenticationMethod(id)),
			updateAuthenticationMethod: (id, data) => from(this.auth0Client.myAccount.updateAuthenticationMethod(id, data)),
			enrollmentChallenge: (options) => from(this.auth0Client.myAccount.enrollmentChallenge(options)),
			enrollmentVerify: (options) => from(this.auth0Client.myAccount.enrollmentVerify(options)),
			getUserProfile: (options) => from(this.auth0Client.myAccount.getUserProfile(options)),
			updateUserProfile: (data) => from(this.auth0Client.myAccount.updateUserProfile(data))
		};
		const checkSessionOrCallback$ = (isCallback) => iif(() => isCallback, this.handleRedirectCallback(), defer(() => this.auth0Client.checkSession()));
		this.shouldHandleCallback().pipe(switchMap((isCallback) => checkSessionOrCallback$(isCallback).pipe(catchError((error) => {
			const config = this.configFactory.get();
			this.navigator.navigateByUrl(config.errorPath || "/");
			this.authState.setError(error);
			return of(void 0);
		}))), tap(() => {
			this.authState.setIsLoading(false);
		}), takeUntil(this.ngUnsubscribe$)).subscribe();
	}
	/**
	* Called when the service is destroyed
	*/
	ngOnDestroy() {
		this.ngUnsubscribe$.next();
		this.ngUnsubscribe$.complete();
	}
	/**
	* ```js
	* loginWithRedirect(options);
	* ```
	*
	* Performs a redirect to `/authorize` using the parameters
	* provided as arguments. Random and secure `state` and `nonce`
	* parameters will be auto-generated.
	*
	* @param options The login options
	*/
	loginWithRedirect(options) {
		return from(this.auth0Client.loginWithRedirect(options));
	}
	/**
	* ```js
	* connectAccountWithRedirect({
	*   connection: 'google-oauth2',
	*   scopes: ['openid', 'profile', 'email', 'https://www.googleapis.com/auth/drive.readonly'],
	*   authorization_params: {
	*     // additional authorization params to forward to the authorization server
	*   }
	* });
	* ```
	*
	* Redirects to the `/connect` URL using the parameters
	* provided as arguments. This then redirects to the connection's login page
	* where the user can authenticate and authorize the account to be connected.
	*
	* If connecting the account is successful, `handleRedirectCallback` will be called
	* with the details of the connected account.
	*
	* @param options The connect account options
	*/
	connectAccountWithRedirect(options) {
		return from(this.auth0Client.connectAccountWithRedirect(options));
	}
	/**
	* ```js
	* await loginWithPopup(options);
	* ```
	*
	* Opens a popup with the `/authorize` URL using the parameters
	* provided as arguments. Random and secure `state` and `nonce`
	* parameters will be auto-generated. If the response is successful,
	* results will be valid according to their expiration times.
	*
	* IMPORTANT: This method has to be called from an event handler
	* that was started by the user like a button click, for example,
	* otherwise the popup will be blocked in most browsers.
	*
	* @param options The login options
	* @param config Configuration for the popup window
	*/
	loginWithPopup(options, config) {
		return from(this.auth0Client.loginWithPopup(options, config).then(() => {
			this.authState.refresh();
		}));
	}
	/**
	* ```js
	* logout();
	* ```
	*
	* Clears the application session and performs a redirect to `/v2/logout`, using
	* the parameters provided as arguments, to clear the Auth0 session.
	* If the `federated` option is specified it also clears the Identity Provider session.
	* If the `openUrl` option is set to false, it only clears the application session.
	* It is invalid to set both the `federated` to true and `openUrl` to `false`,
	* and an error will be thrown if you do.
	* [Read more about how Logout works at Auth0](https://auth0.com/docs/logout).
	*
	* @param options The logout options
	*/
	logout(options) {
		return from(this.auth0Client.logout(options).then(() => {
			if (options?.openUrl === false || options?.openUrl) this.authState.refresh();
		}));
	}
	/**
	* ```js
	* revokeRefreshToken(options).subscribe(() => ...)
	* ```
	*
	* Revokes the refresh token using the `/oauth/revoke` endpoint, so it can no
	* longer be used to obtain new access tokens. With the default (offline)
	* refresh tokens, the cached access token is kept and remains valid until it
	* expires.
	*
	* If `useRefreshTokens` is not enabled, this is a no-op.
	*
	* When using Multi-Resource Refresh Tokens (MRRT), a single refresh token may
	* cover multiple audiences, so revoking it affects all of them.
	*
	* When `refreshTokenMode` is `RefreshTokenMode.Online`, revoking the Online Refresh
	* Token also terminates the Auth0 session and clears the local cache, so
	* `isAuthenticated$` emits `false` and `user$` emits `null`.
	*
	* To terminate the user's session with a redirect, use `logout` instead.
	*
	* @param options Identifies which refresh token to revoke. Defaults to the audience configured in `authorizationParams`.
	*/
	revokeRefreshToken(options) {
		return of(this.auth0Client).pipe(concatMap((client) => client.revokeRefreshToken(options)), tap(() => {
			this.authState.refresh();
		}), catchError((error) => {
			this.authState.setError(error);
			this.authState.refresh();
			return throwError(error);
		}));
	}
	/**
	* ```js
	* getAccessTokenSilently(options).subscribe(token => ...)
	* ```
	*
	* If there's a valid token stored, return it. Otherwise, opens an
	* iframe with the `/authorize` URL using the parameters provided
	* as arguments. Random and secure `state` and `nonce` parameters
	* will be auto-generated. If the response is successful, results
	* will be valid according to their expiration times.
	*
	* If refresh tokens are used, the token endpoint is called directly with the
	* 'refresh_token' grant. If no refresh token is available to make this call,
	* the SDK falls back to using an iframe to the '/authorize' URL.
	*
	* This method may use a web worker to perform the token call if the in-memory
	* cache is used.
	*
	* If an `audience` value is given to this function, the SDK always falls
	* back to using an iframe to make the token exchange.
	*
	* Note that in all cases, falling back to an iframe requires access to
	* the `auth0` cookie, and thus will not work in browsers that block third-party
	* cookies by default (Safari, Brave, etc).
	*
	* @param options The options for configuring the token fetch.
	*/
	getAccessTokenSilently(options = {}) {
		return of(this.auth0Client).pipe(concatMap((client) => options.detailedResponse === true ? client.getTokenSilently({
			...options,
			detailedResponse: true
		}) : client.getTokenSilently(options)), tap((token) => {
			if (token) this.authState.setAccessToken(typeof token === "string" ? token : token.access_token);
			else this.authState.refresh();
		}), catchError((error) => {
			this.authState.setError(error);
			this.authState.refresh();
			return throwError(error);
		}));
	}
	/**
	* ```js
	* getTokenWithPopup(options).subscribe(token => ...)
	* ```
	*
	* Get an access token interactively.
	*
	* Opens a popup with the `/authorize` URL using the parameters
	* provided as arguments. Random and secure `state` and `nonce`
	* parameters will be auto-generated. If the response is successful,
	* results will be valid according to their expiration times.
	*/
	getAccessTokenWithPopup(options) {
		return of(this.auth0Client).pipe(concatMap((client) => client.getTokenWithPopup(options)), tap((token) => {
			if (token) this.authState.setAccessToken(token);
		}), catchError((error) => {
			this.authState.setError(error);
			this.authState.refresh();
			return throwError(error);
		}));
	}
	/**
	* ```js
	* loginWithCustomTokenExchange(options).subscribe(tokenResponse => ...)
	* ```
	*
	* Exchanges an external subject token for Auth0 tokens and establishes an authenticated session.
	*
	* This method implements the token exchange grant as specified in RFC 8693.
	* It performs a token exchange by sending a request to the `/oauth/token` endpoint
	* with the external token and returns Auth0 tokens (access token, ID token, etc.).
	*
	* The request includes the following parameters:
	* - `grant_type`: Hard-coded to "urn:ietf:params:oauth:grant-type:token-exchange"
	* - `subject_token`: The external token to be exchanged
	* - `subject_token_type`: A namespaced URI identifying the token type (must be under your organization's control)
	* - `audience`: The target audience (falls back to the SDK's default audience if not provided)
	* - `scope`: Space-separated list of scopes (merged with the SDK's default scopes)
	*
	* After a successful token exchange, this method updates the authentication state
	* to ensure consistency with the standard authentication flows.
	*
	* @param options The options required to perform the token exchange
	* @returns An Observable that emits the token endpoint response containing Auth0 tokens
	*/
	loginWithCustomTokenExchange(options) {
		return of(this.auth0Client).pipe(concatMap((client) => client.loginWithCustomTokenExchange(options)), tap((tokenResponse) => {
			if (tokenResponse.access_token) this.authState.setAccessToken(tokenResponse.access_token);
		}), catchError((error) => {
			this.authState.setError(error);
			this.authState.refresh();
			return throwError(error);
		}));
	}
	/**
	* ```js
	* handleRedirectCallback(url).subscribe(result => ...)
	* ```
	*
	* After the browser redirects back to the callback page,
	* call `handleRedirectCallback` to handle success and error
	* responses from Auth0. If the response is successful, results
	* will be valid according to their expiration times.
	*
	* Calling this method also refreshes the authentication and user states.
	*
	* @param url The URL to that should be used to retrieve the `state` and `code` values. Defaults to `window.location.href` if not given.
	*/
	handleRedirectCallback(url) {
		return defer(() => this.auth0Client.handleRedirectCallback(url)).pipe(withLatestFrom(this.authState.isLoading$), tap(([result, isLoading]) => {
			if (!isLoading) this.authState.refresh();
			const { appState, response_type, ...rest } = result;
			const target = appState?.target ?? "/";
			if (response_type === ht.ConnectCode) this.appStateSubject$.next({
				...appState ?? {},
				response_type,
				connectedAccount: rest
			});
			else if (appState) this.appStateSubject$.next(appState);
			this.navigator.navigateByUrl(target);
		}), map(([result]) => result));
	}
	/**
	* ```js
	* getDpopNonce(id).subscribe(nonce => ...)
	* ```
	*
	* Gets the DPoP nonce for the specified domain or the default domain.
	* The nonce is used in DPoP proof generation for token binding.
	*
	* @param id Optional identifier for the domain. If not provided, uses the default domain.
	* @returns An Observable that emits the DPoP nonce string or undefined if not available.
	*/
	getDpopNonce(id) {
		return from(this.auth0Client.getDpopNonce(id));
	}
	/**
	* ```js
	* setDpopNonce(nonce, id).subscribe(() => ...)
	* ```
	*
	* Sets the DPoP nonce for the specified domain or the default domain.
	* This is typically used after receiving a new nonce from the authorization server.
	*
	* @param nonce The DPoP nonce value to set.
	* @param id Optional identifier for the domain. If not provided, uses the default domain.
	* @returns An Observable that completes when the nonce is set.
	*/
	setDpopNonce(nonce, id) {
		return from(this.auth0Client.setDpopNonce(nonce, id));
	}
	/**
	* ```js
	* generateDpopProof(params).subscribe(proof => ...)
	* ```
	*
	* Generates a DPoP (Demonstrating Proof-of-Possession) proof JWT.
	* This proof is used to bind access tokens to a specific client, providing
	* an additional layer of security for token usage.
	*
	* @param params Configuration for generating the DPoP proof
	* @param params.url The URL of the resource server endpoint
	* @param params.method The HTTP method (e.g., 'GET', 'POST')
	* @param params.nonce Optional DPoP nonce from the authorization server
	* @param params.accessToken The access token to bind to the proof
	* @returns An Observable that emits the generated DPoP proof as a JWT string.
	*/
	generateDpopProof(params) {
		return from(this.auth0Client.generateDpopProof(params));
	}
	/**
	* ```js
	* const fetcher = createFetcher(config);
	* ```
	*
	* Creates a custom fetcher instance that can be used to make authenticated
	* HTTP requests. The fetcher automatically handles token refresh and can
	* be configured with custom request/response handling.
	*
	* @param config Optional configuration for the fetcher
	* @returns A Fetcher instance configured with the Auth0 client.
	*/
	createFetcher(config) {
		return this.auth0Client.createFetcher(config);
	}
	shouldHandleCallback() {
		return of(location.search).pipe(map((search) => {
			const searchParams = new URLSearchParams(search);
			return (searchParams.has("code") || searchParams.has("connect_code") || searchParams.has("error")) && searchParams.has("state") && !this.configFactory.get().skipRedirectCallback;
		}));
	}
	static {
		this.ɵfac = function AuthService_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || AuthService)(ɵɵinject(Auth0ClientService), ɵɵinject(AuthClientConfig), ɵɵinject(AbstractNavigator), ɵɵinject(AuthState));
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
			token: AuthService,
			factory: AuthService.ɵfac,
			providedIn: "root"
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AuthService, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [
		{
			type: Mu,
			decorators: [{
				type: Inject,
				args: [Auth0ClientService]
			}]
		},
		{ type: AuthClientConfig },
		{ type: AbstractNavigator },
		{ type: AuthState }
	], null);
})();
var AuthGuard = class AuthGuard {
	constructor(auth) {
		this.auth = auth;
	}
	canLoad(route, segments) {
		return this.auth.isAuthenticated$.pipe(take(1));
	}
	canActivate(next, state) {
		return this.redirectIfUnauthenticated(state);
	}
	canActivateChild(childRoute, state) {
		return this.redirectIfUnauthenticated(state);
	}
	redirectIfUnauthenticated(state) {
		return this.auth.isAuthenticated$.pipe(switchMap((loggedIn) => {
			if (!loggedIn) return this.auth.loginWithRedirect({ appState: { target: state.url } }).pipe(map(() => false));
			return of(true);
		}));
	}
	static {
		this.ɵfac = function AuthGuard_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || AuthGuard)(ɵɵinject(AuthService));
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
			token: AuthGuard,
			factory: AuthGuard.ɵfac,
			providedIn: "root"
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AuthGuard, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [{ type: AuthService }], null);
})();
var AuthModule = class AuthModule {
	/**
	* Initialize the authentication module system. Configuration can either be specified here,
	* or by calling AuthClientConfig.set (perhaps from an APP_INITIALIZER factory function).
	*
	* @param config The optional configuration for the SDK.
	*/
	static forRoot(config) {
		return {
			ngModule: AuthModule,
			providers: [
				AuthService,
				AuthGuard,
				{
					provide: AuthConfigService,
					useValue: config
				},
				{
					provide: Auth0ClientService,
					useFactory: Auth0ClientFactory.createClient,
					deps: [AuthClientConfig]
				}
			]
		};
	}
	static {
		this.ɵfac = function AuthModule_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || AuthModule)();
		};
	}
	static {
		this.ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({ type: AuthModule });
	}
	static {
		this.ɵinj = /*@__PURE__*/ ɵɵdefineInjector({});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AuthModule, [{ type: NgModule }], null, null);
})();
var waitUntil = (signal$) => (source$) => source$.pipe(mergeMap((value) => signal$.pipe(first(), mapTo(value))));
var AuthHttpInterceptor = class AuthHttpInterceptor {
	constructor(configFactory, auth0Client, authState, authService) {
		this.configFactory = configFactory;
		this.auth0Client = auth0Client;
		this.authState = authState;
		this.authService = authService;
	}
	intercept(req, next) {
		const config = this.configFactory.get();
		if (!config.httpInterceptor?.allowedList) return next.handle(req);
		const isLoaded$ = this.authService.isLoading$.pipe(filter((isLoading) => !isLoading));
		return this.findMatchingRoute(req, config.httpInterceptor).pipe(concatMap((route) => iif(() => route !== null, of(route).pipe(waitUntil(isLoaded$), pluck("tokenOptions"), concatMap((options) => this.getAccessTokenSilently(options).pipe(catchError((err) => {
			if (this.allowAnonymous(route, err)) return of("");
			this.authState.setError(err);
			return throwError(err);
		}))), switchMap((token) => {
			const clone = token ? req.clone({ headers: req.headers.set("Authorization", `Bearer ${token}`) }) : req;
			return next.handle(clone);
		})), next.handle(req))));
	}
	/**
	* Duplicate of AuthService.getAccessTokenSilently, but with a slightly different error handling.
	* Only used internally in the interceptor.
	*
	* @param options The options for configuring the token fetch.
	*/
	getAccessTokenSilently(options) {
		return of(this.auth0Client).pipe(concatMap((client) => client.getTokenSilently(options)), map((tokenOrResponse) => {
			if (!tokenOrResponse) throw { error: "missing_token" };
			if (typeof tokenOrResponse === "string") return tokenOrResponse;
			return tokenOrResponse.access_token;
		}), tap((token) => this.authState.setAccessToken(token)), catchError((error) => {
			this.authState.refresh();
			return throwError(error);
		}));
	}
	/**
	* Strips the query and fragment from the given uri
	*
	* @param uri The uri to remove the query and fragment from
	*/
	stripQueryFrom(uri) {
		if (uri.indexOf("?") > -1) uri = uri.substr(0, uri.indexOf("?"));
		if (uri.indexOf("#") > -1) uri = uri.substr(0, uri.indexOf("#"));
		return uri;
	}
	/**
	* Determines whether the specified route can have an access token attached to it, based on matching the HTTP request against
	* the interceptor route configuration.
	*
	* @param route The route to test
	* @param request The HTTP request
	*/
	canAttachToken(route, request) {
		const testPrimitive = (value) => {
			if (!value) return false;
			if (value === this.stripQueryFrom(request.url)) return true;
			return value.indexOf("*") === value.length - 1 && request.url.startsWith(value.substr(0, value.length - 1));
		};
		if (isHttpInterceptorRouteConfig(route)) {
			if (route.httpMethod && route.httpMethod !== request.method) return false;
			/* istanbul ignore if */
			if (!route.uri && !route.uriMatcher) console.warn("Either a uri or uriMatcher is required when configuring the HTTP interceptor.");
			return route.uriMatcher ? route.uriMatcher(request.url) : testPrimitive(route.uri);
		}
		return testPrimitive(route);
	}
	/**
	* Tries to match a route from the SDK configuration to the HTTP request.
	* If a match is found, the route configuration is returned.
	*
	* @param request The Http request
	* @param config HttpInterceptorConfig
	*/
	findMatchingRoute(request, config) {
		return from(config.allowedList).pipe(first((route) => this.canAttachToken(route, request), null));
	}
	allowAnonymous(route, err) {
		return !!route && isHttpInterceptorRouteConfig(route) && !!route.allowAnonymous && [
			"login_required",
			"consent_required",
			"missing_refresh_token",
			"interaction_required",
			"missing_token"
		].includes(err.error);
	}
	static {
		this.ɵfac = function AuthHttpInterceptor_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || AuthHttpInterceptor)(ɵɵinject(AuthClientConfig), ɵɵinject(Auth0ClientService), ɵɵinject(AuthState), ɵɵinject(AuthService));
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
			token: AuthHttpInterceptor,
			factory: AuthHttpInterceptor.ɵfac
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AuthHttpInterceptor, [{ type: Injectable }], () => [
		{ type: AuthClientConfig },
		{
			type: Mu,
			decorators: [{
				type: Inject,
				args: [Auth0ClientService]
			}]
		},
		{ type: AuthState },
		{ type: AuthService }
	], null);
})();
/**
* Initialize the authentication system. Configuration can either be specified here,
* or by calling AuthClientConfig.set (perhaps from an APP_INITIALIZER factory function).
*
* Note: Should only be used as of Angular 15. This function returns `EnvironmentProviders`
* which ensures it can only be used at the application/environment level and cannot be
* added to a component's providers array (this will result in a compile-time error).
*
* @param config The optional configuration for the SDK.
*
* @example
* bootstrapApplication(AppComponent, {
*   providers: [
*     provideAuth0(),
*   ],
* });
*/
function provideAuth0(config) {
	return makeEnvironmentProviders([
		AuthService,
		AuthHttpInterceptor,
		AuthGuard,
		{
			provide: AuthConfigService,
			useValue: config
		},
		{
			provide: Auth0ClientService,
			useFactory: Auth0ClientFactory.createClient,
			deps: [AuthClientConfig]
		}
	]);
}
/**
* Functional AuthGuard to ensure routes can only be accessed when authenticated.
*
* Note: Should only be used as of Angular 15
*
* @param route Contains the information about a route associated with a component loaded in an outlet at a particular moment in time.
* @param state Represents the state of the router at a moment in time.
* @returns An Observable, indicating if the route can be accessed or not
*/
var authGuardFn = (route, state) => inject(AuthGuard).canActivate(route, state);
/**
* Functional AuthHttpInterceptor to include the access token in matching requests.
*
* Note: Should only be used as of Angular 15
*
* @param req An outgoing HTTP request with an optional typed body.
* @param handle Represents the next interceptor in an interceptor chain, or the real backend if there are no
* further interceptors.
* @returns An Observable representing the intercepted HttpRequest
*/
var authHttpInterceptorFn = (req, handle) => inject(AuthHttpInterceptor).intercept(req, { handle });
export { AbstractNavigator, Auth0ClientFactory, Auth0ClientService, AuthClientConfig, AuthConfigService, AuthGuard, AuthHttpInterceptor, AuthModule, AuthService, AuthState, A as AuthenticationError, x as ConnectError, E as GenericError, Xe as InMemoryCache, R as InvalidConfigurationError, Ve as LocalStorageCache, yu as MfaChallengeError, mu as MfaEnrollmentError, gu as MfaEnrollmentFactorsError, pu as MfaError, fu as MfaListAuthenticatorsError, N as MfaRequiredError, wu as MfaVerifyError, U as MissingRefreshTokenError, L as MissingScopesError, Ot as MyAccountApiError, lc as PasskeyChallengeError, _u as PasskeyError, dc as PasskeyGetTokenError, uc as PasskeyRegisterError, M as PasskeyVerificationRequiredError, j as PopupCancelledError, W as PopupOpenError, O as PopupTimeoutError, dt as RefreshTokenMode, ht as ResponseType, I as TimeoutError, K as UseDpopNonceError, pt as User, authGuardFn, authHttpInterceptorFn, Uu as isFederatedDomain, isHttpInterceptorRouteConfig, provideAuth0 };
