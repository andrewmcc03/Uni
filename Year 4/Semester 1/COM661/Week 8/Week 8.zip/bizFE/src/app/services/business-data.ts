import { Service, inject } from '@angular/core';
import jsonData from '../../assets/businesses.json';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Service()
export class BusinessData {

    pageSize: number = 3;
    http = inject(HttpClient);

    getBusinesses(page: number) {
        let pageStart = (page - 1) * this.pageSize;
        let pageEnd = pageStart + this.pageSize;
        return jsonData.slice(pageStart, pageEnd);
    }

    getLastPageNumber() {
        return Math.ceil( jsonData.length / this.pageSize );
    }

    getBusiness(id: any) {
        let dataToReturn: any = [];
        jsonData.forEach( function(business) {
            if (business._id.$oid == id) {
                dataToReturn.push( business );
            }
        })
        return dataToReturn;
    }

    getLoremIpsum(paragraphs: number): Observable <any> {
        let API_key = 'HGYmXTbB9osVxZTdQJD7Okx995BosPrj89Ls2qip';   // API Ninja API key
        return this.http.get<any>(
            'https://api.api-ninjas.com/v1/loremipsum?paragraphs=' + paragraphs,
                { headers: { 'X-Api-Key': API_key } }
        )
    }

    getCurrentWeather(lat: number, lon: number) {
        let API_key = '3284e26d9582d5c15733dce3e9f3e2d1';   // OpenWeather API key
        return this.http.get<any>(
            'https://api.openweathermap.org/data/2.5/weather?lat=' + lat + '&lon=' + lon + '&units=metric&appid=' +
                API_key);
    }

    getTemperatureColour(temp: number) {
      if (temp <= 5) return "#0000ff";
      else if (temp <= 12) return "#00ff00";
      else if (temp <= 17) return "#ffff00";
      else if (temp <= 25) return "#fff700";
      else return "#ff0000";
    }
}
